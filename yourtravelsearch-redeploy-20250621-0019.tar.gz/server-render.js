const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'YourTravelSearch',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production',
    version: '1.0.0'
  });
});

// Authentication endpoints
app.post('/api/auth/register', (req, res) => {
  const { email, password, firstName, lastName } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ 
      success: false, 
      message: 'Email and password are required' 
    });
  }
  
  const user = {
    id: Math.floor(Math.random() * 10000),
    email,
    firstName: firstName || 'User',
    lastName: lastName || 'Account',
    username: email.split('@')[0],
    createdAt: new Date().toISOString()
  };
  
  res.json({
    success: true,
    message: 'Account created successfully',
    user,
    token: `jwt-token-${Date.now()}-${user.id}`
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ 
      success: false, 
      message: 'Email and password are required' 
    });
  }
  
  const user = {
    id: 1,
    email,
    firstName: 'John',
    lastName: 'Doe',
    username: email.split('@')[0]
  };
  
  res.json({
    success: true,
    message: 'Login successful',
    user,
    token: `jwt-token-${Date.now()}-${user.id}`
  });
});

app.get('/api/auth/profile', (req, res) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication token required'
    });
  }
  
  res.json({
    success: true,
    user: {
      id: 1,
      email: 'user@yourtravelsearch.com',
      firstName: 'John',
      lastName: 'Doe',
      username: 'user',
      preferences: {
        currency: 'USD',
        language: 'en',
        notifications: true
      }
    }
  });
});

// Destinations API
app.get('/api/destinations', (req, res) => {
  res.json([
    {
      id: 1,
      name: "Paris",
      description: "The City of Light awaits with iconic landmarks, world-class museums, and romantic ambiance",
      imageUrl: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=800",
      priceFrom: "299.00",
      country: "France"
    },
    {
      id: 2,
      name: "Tokyo", 
      description: "Experience the perfect blend of ancient traditions and cutting-edge technology",
      imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800",
      priceFrom: "599.00",
      country: "Japan"
    },
    {
      id: 3,
      name: "New York",
      description: "The city that never sleeps offers endless possibilities and iconic experiences",
      imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800", 
      priceFrom: "199.00",
      country: "USA"
    }
  ]);
});

// Flight search API
app.get('/api/flights/search', (req, res) => {
  const { origin, destination } = req.query;
  res.json([
    {
      id: "flight-1",
      airline: "American Airlines",
      flightNumber: "AA123",
      origin: origin || "NYC",
      destination: destination || "LAX", 
      departureTime: "2025-06-25T08:00:00Z",
      arrivalTime: "2025-06-25T11:30:00Z",
      price: "299.00",
      currency: "USD",
      duration: "5h 30m",
      stops: 0
    },
    {
      id: "flight-2", 
      airline: "Delta Airlines",
      flightNumber: "DL456",
      origin: origin || "NYC",
      destination: destination || "LAX",
      departureTime: "2025-06-25T14:00:00Z", 
      arrivalTime: "2025-06-25T17:45:00Z",
      price: "325.00",
      currency: "USD",
      duration: "5h 45m",
      stops: 0
    }
  ]);
});

// Hotels API
app.get('/api/hotels', (req, res) => {
  res.json([
    {
      id: 1,
      name: "Grand Hotel Paris",
      location: "Paris, France", 
      description: "Luxury hotel in the heart of Paris with stunning city views",
      imageUrl: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800",
      rating: "4.8",
      pricePerNight: "299.00",
      amenities: ["WiFi", "Pool", "Spa", "Restaurant", "Fitness Center"],
      featured: true
    }
  ]);
});

// Protected booking endpoints
app.post('/api/bookings', (req, res) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required for bookings'
    });
  }
  
  const { flightId, passengers, paymentMethod } = req.body;
  
  const booking = {
    id: `booking-${Date.now()}`,
    flightId,
    passengers,
    paymentMethod,
    status: 'confirmed',
    totalPrice: '299.00',
    currency: 'USD',
    bookingDate: new Date().toISOString(),
    confirmationCode: `YTS${Math.random().toString(36).substr(2, 8).toUpperCase()}`
  };
  
  res.json({
    success: true,
    message: 'Booking confirmed',
    booking
  });
});

// Serve React frontend
app.use(express.static(path.join(__dirname, 'src')));
app.use('/src', express.static(path.join(__dirname, 'src')));

// Catch-all for React routing
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/health')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`YourTravelSearch Production Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`Authentication endpoints enabled`);
  console.log(`Started: ${new Date().toISOString()}`);
});

module.exports = app;