// Production server for Render deployment
const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Set environment for development features
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development';
}

// Middleware Configuration
app.use(cors({
  origin: true,
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Setup development environment with Vite
async function setupDevelopmentServer() {
  try {
    const { createServer } = require('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
      root: __dirname,
      configFile: false,
      plugins: [
        require('@vitejs/plugin-react')()
      ],
      resolve: {
        alias: {
          '@': require('path').resolve(__dirname, 'src'),
          '@shared': require('path').resolve(__dirname, 'shared'),
          '@assets': require('path').resolve(__dirname, 'attached_assets')
        }
      }
    });
    
    app.use(vite.ssrFixStacktrace);
    app.use(vite.middlewares);
    console.log('Vite development server integrated');
    return true;
  } catch (error) {
    console.log('Vite integration failed, using static files');
    // Fallback to static file serving
    app.use(express.static(__dirname, {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.js') || filePath.endsWith('.mjs') || filePath.endsWith('.tsx') || filePath.endsWith('.ts')) {
          res.set('Content-Type', 'text/javascript');
        }
      }
    }));
    
    app.use('/src', express.static('src', {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.tsx') || filePath.endsWith('.ts')) {
          res.set('Content-Type', 'text/javascript');
        }
      }
    }));
    
    app.use('/node_modules', express.static('node_modules'));
    return false;
  }
}

// Initialize development server
if (process.env.NODE_ENV !== 'production') {
  setupDevelopmentServer().then(() => {
    console.log('Development server setup complete');
  });
} else {
  app.use(express.static(__dirname));
}

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Health check endpoint for Render
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    service: 'YourTravelSearch Production',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production',
    version: '1.0.0',
    uptime: process.uptime()
  });
});

// API status endpoint
app.get('/api/status', (req, res) => {
  res.json({
    api: 'operational',
    duffel: 'connected',
    database: 'connected',
    timestamp: new Date().toISOString()
  });
});

// API routes for development
app.get('/api/destinations', (req, res) => {
  res.json([
    {
      id: 1,
      name: "Paris",
      description: "The City of Light awaits with iconic landmarks, world-class museums, and romantic ambiance",
      imageUrl: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=800",
      priceFrom: "299.00",
      country: "France"
    },
    {
      id: 2,
      name: "Tokyo",
      description: "Experience the perfect blend of ancient traditions and cutting-edge technology",
      imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800",
      priceFrom: "599.00",
      country: "Japan"
    },
    {
      id: 3,
      name: "New York",
      description: "The city that never sleeps offers endless possibilities and iconic experiences",
      imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800",
      priceFrom: "199.00",
      country: "USA"
    }
  ]);
});

app.get('/api/flights/search', (req, res) => {
  const { origin, destination, departure_date, return_date, passengers } = req.query;
  
  res.json({
    flights: [
      {
        id: "FL001",
        airline: "American Airlines",
        flightNumber: "AA1234",
        origin: origin || "NYC",
        destination: destination || "LAX",
        departureTime: "08:00",
        arrivalTime: "11:30",
        duration: "5h 30m",
        price: "299.00",
        stops: 0,
        aircraft: "Boeing 737-800",
        imageUrl: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400"
      },
      {
        id: "FL002",
        airline: "Delta Airlines",
        flightNumber: "DL5678",
        origin: origin || "NYC",
        destination: destination || "LAX",
        departureTime: "14:15",
        arrivalTime: "17:45",
        duration: "5h 30m",
        price: "345.00",
        stops: 0,
        aircraft: "Airbus A320",
        imageUrl: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400"
      },
      {
        id: "FL003",
        airline: "JetBlue Airways",
        flightNumber: "B61234",
        origin: origin || "NYC",
        destination: destination || "LAX",
        departureTime: "10:30",
        arrivalTime: "14:00",
        duration: "5h 30m",
        price: "279.00",
        stops: 0,
        aircraft: "Airbus A321",
        imageUrl: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400"
      }
    ],
    searchParams: {
      origin,
      destination,
      departure_date,
      return_date,
      passengers: passengers || "1"
    }
  });
});

app.get('/api/hotels', (req, res) => {
  res.json([
    {
      id: 1,
      name: "Grand Hotel Paris",
      location: "Paris, France",
      description: "Luxury hotel in the heart of Paris with stunning city views",
      imageUrl: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800",
      rating: "4.8",
      pricePerNight: "299.00",
      amenities: ["WiFi", "Pool", "Spa", "Restaurant", "Fitness Center"],
      featured: true
    },
    {
      id: 2,
      name: "Tokyo Bay Hotel",
      location: "Tokyo, Japan",
      description: "Modern hotel with traditional Japanese hospitality",
      imageUrl: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800",
      rating: "4.7",
      pricePerNight: "199.00",
      amenities: ["WiFi", "Restaurant", "Business Center", "Concierge"],
      featured: true
    }
  ]);
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  if (email && password) {
    res.json({
      success: true,
      user: {
        id: 1,
        email: email,
        username: email.split('@')[0],
        firstName: "John",
        lastName: "Doe"
      },
      token: "mock-jwt-token-" + Date.now()
    });
  } else {
    res.status(400).json({ error: "Email and password required" });
  }
});

app.post('/api/auth/register', (req, res) => {
  const { email, password, firstName, lastName } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ 
      success: false, 
      message: 'Email and password are required' 
    });
  }
  
  const user = {
    id: Math.floor(Math.random() * 10000),
    email,
    firstName: firstName || 'User',
    lastName: lastName || 'Account',
    username: email.split('@')[0],
    createdAt: new Date().toISOString()
  };
  
  res.json({
    success: true,
    message: 'Account created successfully',
    user,
    token: `jwt-token-${Date.now()}-${user.id}`
  });
});

app.post('/api/auth/logout', (req, res) => {
  res.json({
    success: true,
    message: 'Logged out successfully'
  });
});

app.get('/api/auth/profile', (req, res) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication token required'
    });
  }
  
  res.json({
    success: true,
    user: {
      id: 1,
      email: 'user@yourtravelsearch.com',
      firstName: 'John',
      lastName: 'Doe',
      username: 'user',
      preferences: {
        currency: 'USD',
        language: 'en',
        notifications: true
      }
    }
  });
});

app.post('/api/bookings', (req, res) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required for bookings'
    });
  }
  
  const { flightId, passengers, paymentMethod } = req.body;
  
  const booking = {
    id: `booking-${Date.now()}`,
    flightId,
    passengers,
    paymentMethod,
    status: 'confirmed',
    totalPrice: '299.00',
    currency: 'USD',
    bookingDate: new Date().toISOString(),
    confirmationCode: `YTS${Math.random().toString(36).substr(2, 8).toUpperCase()}`
  };
  
  res.json({
    success: true,
    message: 'Booking confirmed',
    booking
  });
});

app.get('/api/bookings', (req, res) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required'
    });
  }
  
  res.json([
    {
      id: 'booking-001',
      flightNumber: 'AA123',
      route: 'NYC → LAX',
      date: '2025-06-25',
      status: 'confirmed',
      totalPrice: '299.00',
      confirmationCode: 'YTS12345678'
    }
  ]);
});

// Root route - serve main application
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Catch-all route for SPA routing
app.get('*', (req, res) => {
  // Don't interfere with API routes
  if (req.path.startsWith('/api/') || req.path.startsWith('/health')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  
  // Serve index.html for all other routes (SPA routing)
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    timestamp: new Date().toISOString()
  });
});

// Start production server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 YourTravelSearch Production Server`);
  console.log(`📡 Port: ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`⏰ Started: ${new Date().toISOString()}`);
  console.log(`🏠 Working Directory: ${__dirname}`);
  console.log(`✅ Server ready for connections`);
});