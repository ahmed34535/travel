// Minimal PostCSS config to avoid loading issues
export default {}
