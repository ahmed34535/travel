// Path helper to resolve client template path without import.meta.dirname
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const currentDir = dirname(fileURLToPath(import.meta.url));
export const getClientTemplatePath = () => resolve(currentDir, '..', 'client', 'index.html');
export const getPublicPath = () => resolve(currentDir, 'public');
export const getServerDir = () => currentDir;