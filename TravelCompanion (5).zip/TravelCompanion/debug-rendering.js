/**
 * Debug Rendering Issue - Test React component state
 */

const puppeteer = require('puppeteer');

async function debugRendering() {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  
  try {
    console.log("Debugging hotel page rendering...\n");
    
    // Navigate to hotels page
    await page.goto('http://localhost:5000/hotels', { waitUntil: 'networkidle0' });
    
    // Check page content
    const pageContent = await page.content();
    console.log("1. Page loads successfully:", pageContent.length > 1000);
    
    // Check if React is running
    const reactExists = await page.evaluate(() => {
      return window.React !== undefined || document.querySelector('[data-reactroot]') !== null;
    });
    console.log("2. React detected:", reactExists);
    
    // Check for specific elements
    const elements = {
      'Page title': await page.$eval('title', el => el.textContent).catch(() => null),
      'Main content div': await page.$('.min-h-screen') !== null,
      'Search form': await page.$('form') !== null,
      'Hotel cards': await page.$$('.hover\\:shadow-lg').then(els => els.length),
      'Input fields': await page.$$('input').then(els => els.length),
      'Buttons': await page.$$('button').then(els => els.length)
    };
    
    console.log("\n3. Element check:");
    Object.entries(elements).forEach(([name, result]) => {
      console.log(`   ${name}: ${result}`);
    });
    
    // Check console errors
    const consoleMessages = [];
    page.on('console', msg => consoleMessages.push(msg.text()));
    
    await page.reload({ waitUntil: 'networkidle0' });
    
    console.log("\n4. Console messages:");
    consoleMessages.forEach(msg => {
      if (msg.includes('Error') || msg.includes('error')) {
        console.log(`   ERROR: ${msg}`);
      }
    });
    
    // Check if the component is mounted
    const componentMounted = await page.evaluate(() => {
      return document.querySelector('.min-h-screen') !== null;
    });
    console.log("\n5. Component mounted:", componentMounted);
    
    // Get actual rendered HTML
    const bodyHTML = await page.$eval('body', el => el.innerHTML);
    const hasHotelContent = bodyHTML.includes('Find Your Perfect Hotel') || 
                           bodyHTML.includes('Grand Plaza') ||
                           bodyHTML.includes('Hotel Search');
    
    console.log("6. Hotel content in DOM:", hasHotelContent);
    
    if (!hasHotelContent) {
      console.log("7. Current DOM structure:");
      const mainContent = await page.$eval('body', el => 
        el.innerHTML.substring(0, 500) + '...'
      );
      console.log(mainContent);
    }
    
  } catch (error) {
    console.log(`Rendering debug error: ${error.message}`);
  } finally {
    await browser.close();
  }
}

debugRendering().catch(console.error);