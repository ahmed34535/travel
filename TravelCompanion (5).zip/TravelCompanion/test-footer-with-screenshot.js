/**
 * Footer Testing with Screenshots
 * Direct examination of the website to verify footer functionality
 */

import puppeteer from 'puppeteer';

async function testFooterWithScreenshot() {
  console.log("Testing footer functionality with visual verification...\n");

  let browser;
  try {
    // Try launching with no-sandbox for Replit environment
    browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
        '--disable-gpu'
      ],
      defaultViewport: { width: 1280, height: 720 }
    });

    const page = await browser.newPage();
    
    console.log("1. Loading homepage...");
    await page.goto('http://localhost:5000', { 
      waitUntil: 'networkidle0',
      timeout: 30000 
    });
    
    // Wait for React to fully render
    await page.waitForTimeout(3000);
    
    console.log("2. Taking full page screenshot...");
    await page.screenshot({ 
      path: 'homepage-full.png', 
      fullPage: true 
    });
    
    console.log("3. Checking footer visibility...");
    
    // Scroll to bottom to ensure footer is visible
    await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
    await page.waitForTimeout(1000);
    
    // Check if footer exists
    const footerExists = await page.$('footer');
    console.log(`   Footer element found: ${!!footerExists}`);
    
    if (footerExists) {
      // Get footer info
      const footerInfo = await page.evaluate(() => {
        const footer = document.querySelector('footer');
        if (!footer) return null;
        
        const rect = footer.getBoundingClientRect();
        const text = footer.textContent;
        const links = Array.from(footer.querySelectorAll('a')).map(a => ({
          text: a.textContent.trim(),
          href: a.getAttribute('href'),
          visible: a.offsetHeight > 0
        }));
        
        return {
          visible: rect.height > 0,
          height: rect.height,
          width: rect.width,
          hasTravalSearch: text.includes('TravalSearch'),
          linkCount: links.length,
          workingLinks: links.filter(l => l.href && l.href !== '#').length,
          links: links
        };
      });
      
      console.log(`   Footer visible: ${footerInfo.visible}`);
      console.log(`   Footer dimensions: ${footerInfo.width}x${footerInfo.height}`);
      console.log(`   Contains TravalSearch: ${footerInfo.hasTravalSearch}`);
      console.log(`   Total links: ${footerInfo.linkCount}`);
      console.log(`   Working links: ${footerInfo.workingLinks}`);
      
      // Take footer screenshot
      await page.screenshot({ 
        path: 'footer-section.png',
        clip: await page.evaluate(() => {
          const footer = document.querySelector('footer');
          const rect = footer.getBoundingClientRect();
          return {
            x: 0,
            y: rect.top,
            width: rect.width,
            height: rect.height
          };
        })
      });
      
      console.log("\n4. Testing footer navigation...");
      
      const importantLinks = footerInfo.links.filter(link => 
        link.href && link.href.match(/\/(about|privacy|terms|support)/)
      );
      
      for (const link of importantLinks) {
        if (link.href && link.href !== '#') {
          console.log(`\n   Testing ${link.text} (${link.href})...`);
          
          try {
            // Click the link
            await page.click(`footer a[href="${link.href}"]`);
            await page.waitForTimeout(2000);
            
            const currentUrl = page.url();
            const expectedUrl = `http://localhost:5000${link.href}`;
            
            if (currentUrl === expectedUrl) {
              console.log(`   ✓ Navigation successful`);
              
              // Take screenshot of the page
              await page.screenshot({ 
                path: `page-${link.href.replace('/', '')}.png`,
                fullPage: true 
              });
              
              // Check page content
              const pageContent = await page.evaluate(() => ({
                title: document.title,
                hasContent: document.body.textContent.length > 1000,
                hasTravalSearch: document.body.textContent.includes('TravalSearch')
              }));
              
              console.log(`   ✓ Page title: "${pageContent.title}"`);
              console.log(`   ✓ Has substantial content: ${pageContent.hasContent}`);
              console.log(`   ✓ Contains TravalSearch branding: ${pageContent.hasTravalSearch}`);
              
              // Go back to homepage
              await page.goto('http://localhost:5000', { waitUntil: 'networkidle0' });
              await page.waitForTimeout(1000);
              
              // Scroll back to footer
              await page.evaluate(() => {
                window.scrollTo(0, document.body.scrollHeight);
              });
              await page.waitForTimeout(500);
              
            } else {
              console.log(`   ❌ Navigation failed. Expected: ${expectedUrl}, Got: ${currentUrl}`);
            }
          } catch (error) {
            console.log(`   ❌ Error testing ${link.text}: ${error.message}`);
          }
        }
      }
      
      console.log("\n5. Testing responsive footer...");
      
      // Test mobile view
      await page.setViewport({ width: 375, height: 667 });
      await page.goto('http://localhost:5000', { waitUntil: 'networkidle0' });
      await page.waitForTimeout(2000);
      
      await page.evaluate(() => {
        window.scrollTo(0, document.body.scrollHeight);
      });
      await page.waitForTimeout(1000);
      
      await page.screenshot({ 
        path: 'footer-mobile.png',
        fullPage: true 
      });
      
      const mobileFooter = await page.evaluate(() => {
        const footer = document.querySelector('footer');
        if (!footer) return null;
        const rect = footer.getBoundingClientRect();
        return {
          visible: rect.height > 0,
          height: rect.height,
          width: rect.width
        };
      });
      
      console.log(`   Mobile footer visible: ${mobileFooter?.visible}`);
      console.log(`   Mobile footer size: ${mobileFooter?.width}x${mobileFooter?.height}`);
      
    } else {
      console.log("❌ Footer not found!");
      
      // Debug what's actually on the page
      const debugInfo = await page.evaluate(() => {
        const root = document.getElementById('root');
        return {
          rootExists: !!root,
          rootContent: root ? root.innerHTML.length : 0,
          bodyContent: document.body.innerHTML.length,
          hasFooterClass: document.body.innerHTML.includes('bg-gray-900'),
          hasTravalSearch: document.body.innerHTML.includes('TravalSearch')
        };
      });
      
      console.log(`   Root element exists: ${debugInfo.rootExists}`);
      console.log(`   Root content length: ${debugInfo.rootContent}`);
      console.log(`   Page has footer styling: ${debugInfo.hasFooterClass}`);
      console.log(`   Page mentions TravalSearch: ${debugInfo.hasTravalSearch}`);
    }
    
  } catch (error) {
    console.error("Test failed:", error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }

  console.log("\n=== FOOTER TEST COMPLETE ===");
  console.log("Screenshots saved:");
  console.log("- homepage-full.png (complete homepage)");
  console.log("- footer-section.png (footer close-up)");
  console.log("- page-about.png, page-privacy.png, etc. (footer link pages)");
  console.log("- footer-mobile.png (mobile view)");
}

testFooterWithScreenshot().catch(console.error);