/**
 * Real User Forgot Password Test
 * Tests the complete forgot password workflow like a human user
 */

import puppeteer from 'puppeteer';

async function testForgotPasswordAsHuman() {
  console.log('Starting forgot password test as a real user...');
  
  const browser = await puppeteer.launch({
    headless: false,
    defaultViewport: { width: 1280, height: 720 },
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    
    // Step 1: Navigate to login page
    console.log('1. Opening TravalSearch login page...');
    await page.goto('http://localhost:5000/login', { waitUntil: 'networkidle0' });
    await page.waitForTimeout(2000);
    
    // Take initial screenshot
    await page.screenshot({ path: 'step1-login-page.png', fullPage: true });
    console.log('   Screenshot saved: step1-login-page.png');
    
    // Step 2: Look for and click forgot password button
    console.log('2. Looking for "Forgot password?" button...');
    
    // Find all buttons and look for the one with "Forgot" text
    const buttons = await page.$$('button');
    let forgotButton = null;
    
    for (let button of buttons) {
      const text = await button.evaluate(el => el.textContent);
      if (text && text.toLowerCase().includes('forgot')) {
        forgotButton = button;
        console.log('   Found forgot password button');
        break;
      }
    }
    
    if (!forgotButton) {
      console.log('   ERROR: Could not find forgot password button');
      return;
    }
    
    // Click the forgot password button
    console.log('3. Clicking "Forgot password?" button...');
    await forgotButton.click();
    await page.waitForTimeout(1500);
    
    // Take screenshot after clicking
    await page.screenshot({ path: 'step2-modal-opened.png', fullPage: true });
    console.log('   Screenshot saved: step2-modal-opened.png');
    
    // Step 3: Check if modal opened
    console.log('4. Checking if forgot password modal opened...');
    
    // Look for modal dialog
    const modalExists = await page.evaluate(() => {
      // Check for various modal indicators
      const dialog = document.querySelector('[role="dialog"]');
      const modal = document.querySelector('.modal');
      const dialogElement = document.querySelector('dialog');
      const resetTitle = document.querySelector('*').innerText?.includes('Reset Password');
      
      return !!(dialog || modal || dialogElement || resetTitle);
    });
    
    if (!modalExists) {
      console.log('   ERROR: Forgot password modal did not open');
      return;
    }
    
    console.log('   SUCCESS: Forgot password modal opened');
    
    // Step 4: Enter email address
    console.log('5. Entering email address...');
    
    const emailInput = await page.$('input[type="email"]');
    if (!emailInput) {
      console.log('   ERROR: Could not find email input field');
      return;
    }
    
    // Type email like a human user would
    await emailInput.click();
    await page.waitForTimeout(500);
    await emailInput.type('john.doe@example.com', { delay: 100 });
    console.log('   Entered email: john.doe@example.com');
    
    await page.waitForTimeout(1000);
    await page.screenshot({ path: 'step3-email-entered.png', fullPage: true });
    console.log('   Screenshot saved: step3-email-entered.png');
    
    // Step 5: Click submit button
    console.log('6. Clicking "Send Reset Link" button...');
    
    const submitButton = await page.$('button[type="submit"]');
    if (!submitButton) {
      console.log('   ERROR: Could not find submit button');
      return;
    }
    
    await submitButton.click();
    console.log('   Clicked send reset link button');
    
    // Wait for API response
    await page.waitForTimeout(3000);
    
    // Step 6: Check for success message
    console.log('7. Checking for success confirmation...');
    
    const successExists = await page.evaluate(() => {
      const text = document.body.innerText;
      return text.includes('Check your email') || 
             text.includes('Reset email sent') || 
             text.includes('sent a password reset');
    });
    
    await page.screenshot({ path: 'step4-final-result.png', fullPage: true });
    console.log('   Screenshot saved: step4-final-result.png');
    
    if (successExists) {
      console.log('   SUCCESS: Password reset email confirmation displayed');
      console.log('\n✅ FORGOT PASSWORD TEST COMPLETED SUCCESSFULLY');
      console.log('   - Modal opened correctly');
      console.log('   - Email input worked');
      console.log('   - Submit button functioned');
      console.log('   - Success message displayed');
    } else {
      console.log('   WARNING: Could not confirm success message');
    }
    
    // Step 7: Test closing modal
    console.log('8. Testing modal close functionality...');
    
    const backButton = await page.$('button');
    if (backButton) {
      const buttonText = await backButton.evaluate(el => el.textContent);
      if (buttonText && buttonText.includes('Back')) {
        await backButton.click();
        await page.waitForTimeout(1000);
        console.log('   Modal closed successfully');
      }
    }
    
  } catch (error) {
    console.error('ERROR during forgot password test:', error.message);
    await page.screenshot({ path: 'error-screenshot.png', fullPage: true });
  } finally {
    await browser.close();
    console.log('\nTest completed. Screenshots saved for review.');
  }
}

// Check if server is running first
async function checkServer() {
  try {
    const response = await fetch('http://localhost:5000/login');
    return response.ok;
  } catch (error) {
    return false;
  }
}

async function runTest() {
  const serverRunning = await checkServer();
  if (!serverRunning) {
    console.log('ERROR: Server not running on localhost:5000');
    console.log('Please make sure the application is started');
    return;
  }
  
  await testForgotPasswordAsHuman();
}

runTest();