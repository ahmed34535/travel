/**
 * Activate Duffel Stays with Live Hotel Photos
 * Test the real Duffel Stays API to get authentic hotel images
 */

// Use built-in fetch (Node.js 18+)

async function activateDuffelStays() {
  console.log("Activating Duffel Stays API for authentic hotel photos...\n");

  // Check if we have the Duffel API token
  const apiToken = process.env.DUFFEL_API_TOKEN;
  if (!apiToken) {
    console.log("❌ No Duffel API token found");
    console.log("Need DUFFEL_API_TOKEN environment variable");
    return;
  }

  console.log("✓ Duffel API token found");
  console.log(`Token: ${apiToken.substring(0, 20)}...`);

  // Test Duffel Stays search endpoint
  console.log("\n1. Testing Duffel Stays API...");
  
  const searchRequest = {
    data: {
      rooms: 1,
      location: {
        radius: 5,
        geographic_coordinates: {
          longitude: -0.1276,
          latitude: 51.5074
        }
      },
      check_in_date: "2025-06-20",
      check_out_date: "2025-06-22", 
      guests: [
        { type: "adult" },
        { type: "adult" }
      ]
    }
  };

  try {
    const response = await fetch('https://api.duffel.com/stays/search', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiToken}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Accept-Encoding': 'gzip',
        'Duffel-Version': 'v2'
      },
      body: JSON.stringify(searchRequest)
    });

    console.log(`API Response Status: ${response.status}`);
    
    if (response.ok) {
      const staysData = await response.json();
      console.log("✓ Duffel Stays API working!");
      
      if (staysData.data && staysData.data.length > 0) {
        console.log(`\n✓ Found ${staysData.data.length} real hotels in London`);
        
        // Show first 3 hotels with authentic photos
        staysData.data.slice(0, 3).forEach((result, index) => {
          const hotel = result.accommodation;
          console.log(`\nHotel ${index + 1}:`);
          console.log(`  Name: ${hotel.name}`);
          console.log(`  Location: ${hotel.location.city}, ${hotel.location.country_code}`);
          console.log(`  Price: ${hotel.cheapest_rate_total_currency} ${hotel.cheapest_rate_total_amount}`);
          console.log(`  Star Rating: ${hotel.star_rating || 'Not rated'}`);
          
          if (hotel.images && hotel.images.length > 0) {
            console.log(`  ✓ Authentic Photos: ${hotel.images.length} images available`);
            console.log(`    Primary Image: ${hotel.images[0].url}`);
            if (hotel.images[0].caption) {
              console.log(`    Caption: ${hotel.images[0].caption}`);
            }
          } else {
            console.log(`  ❌ No photos available`);
          }
          
          if (hotel.amenities && hotel.amenities.length > 0) {
            console.log(`  Amenities: ${hotel.amenities.slice(0, 3).join(', ')}${hotel.amenities.length > 3 ? '...' : ''}`);
          }
        });
        
        console.log("\n=== DUFFEL STAYS INTEGRATION READY ===");
        console.log("✓ Live hotel data with authentic photos");
        console.log("✓ Real pricing and availability");
        console.log("✓ Actual hotel descriptions and amenities");
        console.log("✓ Ready to replace mock data");
        
      } else {
        console.log("❌ No hotels found in search results");
      }
      
    } else {
      const errorText = await response.text();
      console.log(`❌ API Error: ${response.status}`);
      console.log(`Error details: ${errorText}`);
    }
    
  } catch (error) {
    console.log(`❌ Network Error: ${error.message}`);
  }
}

activateDuffelStays().catch(console.error);