/**
 * Test Complete Frontend Flow - Verify frontend displays live flight data
 */

async function testFrontendFlow() {
  console.log("Testing complete frontend flow like a real user...");
  
  try {
    // Step 1: Test homepage loads properly
    console.log("\n1. Testing homepage...");
    const homeResponse = await fetch('http://localhost:5000/');
    console.log(`Homepage status: ${homeResponse.status}`);
    
    if (!homeResponse.ok) {
      console.log("Homepage failed to load");
      return;
    }
    
    // Step 2: Test flight results page (what user sees after search)
    console.log("\n2. Testing flight results page (user experience)...");
    const resultsUrl = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
    const resultsResponse = await fetch(resultsUrl);
    console.log(`Results page status: ${resultsResponse.status}`);
    
    const resultsHtml = await resultsResponse.text();
    
    // What the user sees on the page
    const userView = {
      pageLoads: resultsResponse.status === 200,
      hasReactApp: resultsHtml.includes('id="root"'),
      pageSize: resultsHtml.length,
      hasViteClient: resultsHtml.includes('/@vite/client'),
      containsFlightResults: resultsHtml.includes('Flight Results'),
      containsBookButton: resultsHtml.includes('Book Flight'),
      containsPrice: resultsHtml.includes('USD') || resultsHtml.includes('$'),
      containsNoFlights: resultsHtml.includes('No flights found'),
      containsSearching: resultsHtml.includes('Searching flights'),
      containsError: resultsHtml.includes('Search failed')
    };
    
    console.log("User sees:", userView);
    
    // Step 3: Test the API that React calls (backend functionality)
    console.log("\n3. Testing API that frontend calls...");
    const apiResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    console.log(`API response status: ${apiResponse.status}`);
    
    if (apiResponse.ok) {
      const apiData = await apiResponse.json();
      const flightCount = apiData.data?.length || 0;
      console.log(`API returned ${flightCount} flights`);
      
      if (flightCount > 0) {
        const sampleFlight = apiData.data[0];
        console.log(`Sample flight: ${sampleFlight.owner?.name || 'Unknown'} - ${sampleFlight.total_currency} ${sampleFlight.total_amount}`);
        console.log(`Route: ${sampleFlight.slices?.[0]?.origin?.iata_code} → ${sampleFlight.slices?.[0]?.destination?.iata_code}`);
      }
    } else {
      console.log("API call failed");
    }
    
    // Step 4: Test different route to verify consistency
    console.log("\n4. Testing different route...");
    const miaLaxResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'MIA',
        destination: 'LAX',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    if (miaLaxResponse.ok) {
      const miaData = await miaLaxResponse.json();
      console.log(`MIA→LAX: ${miaData.data?.length || 0} flights available`);
      if (miaData.data?.length > 0) {
        console.log(`Price: ${miaData.data[0].total_currency} ${miaData.data[0].total_amount}`);
      }
    }
    
    // Step 5: Final assessment
    console.log("\n5. REAL USER EXPERIENCE ASSESSMENT:");
    console.log("===================================");
    
    console.log(`✓ Website loads: ${userView.pageLoads}`);
    console.log(`✓ React app works: ${userView.hasReactApp}`);
    console.log(`✓ API functioning: ${apiResponse.ok}`);
    console.log(`✓ Live flight data: ${apiResponse.ok && apiData?.data?.length > 0}`);
    
    // Determine what user actually experiences
    if (userView.containsBookButton && userView.containsPrice) {
      console.log("\n🎉 SUCCESS: User can see flights and book them!");
      console.log("The platform is working for real customers.");
    } else if (userView.containsSearching) {
      console.log("\n⏳ User sees loading state");
      console.log("They need to wait for results to appear.");
    } else if (userView.containsNoFlights) {
      console.log("\n❌ PROBLEM: User sees 'No flights found'");
      console.log("Despite API working, frontend isn't displaying results.");
    } else if (userView.containsError) {
      console.log("\n❌ PROBLEM: User sees error message");
    } else {
      console.log("\n❓ UNCLEAR: Unknown user experience");
      console.log("Need to investigate React component rendering.");
    }
    
    return {
      websiteWorks: userView.pageLoads && userView.hasReactApp,
      apiWorks: apiResponse.ok,
      hasFlightData: apiResponse.ok && apiData?.data?.length > 0,
      userCanBook: userView.containsBookButton && userView.containsPrice
    };
    
  } catch (error) {
    console.error("Frontend flow test failed:", error.message);
    return null;
  }
}

// Run the test
testFrontendFlow().then(result => {
  if (result) {
    console.log("\n=== SUMMARY ===");
    console.log(`Website functionality: ${result.websiteWorks ? 'Working' : 'Broken'}`);
    console.log(`API functionality: ${result.apiWorks ? 'Working' : 'Broken'}`);
    console.log(`Flight data available: ${result.hasFlightData ? 'Yes' : 'No'}`);
    console.log(`User can book flights: ${result.userCanBook ? 'Yes' : 'No'}`);
    
    if (result.websiteWorks && result.apiWorks && result.hasFlightData && result.userCanBook) {
      console.log("\n✅ PLATFORM READY: Real users can search and book flights!");
    } else if (result.websiteWorks && result.apiWorks && result.hasFlightData && !result.userCanBook) {
      console.log("\n⚠️ FRONTEND ISSUE: API works but user interface isn't showing results properly");
    } else {
      console.log("\n❌ ISSUES DETECTED: Platform needs fixes before users can use it");
    }
  }
}).catch(console.error);