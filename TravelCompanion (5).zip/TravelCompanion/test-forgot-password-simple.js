/**
 * Simple Forgot Password Test
 * Tests the forgot password API and frontend functionality
 */

// Test the forgot password API endpoint
async function testForgotPasswordAPI() {
  console.log('Testing forgot password API endpoint...');
  
  try {
    const response = await fetch('http://localhost:5000/api/auth/forgot-password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: 'test@example.com'
      })
    });
    
    const data = await response.json();
    
    console.log('API Response Status:', response.status);
    console.log('API Response:', data);
    
    if (response.ok) {
      console.log('✅ Forgot password API working correctly');
      console.log('✅ Email would be sent to:', data.email);
      return true;
    } else {
      console.log('❌ API returned error:', data.message);
      return false;
    }
  } catch (error) {
    console.log('❌ API call failed:', error.message);
    return false;
  }
}

// Test with invalid email
async function testInvalidEmail() {
  console.log('\nTesting with invalid email...');
  
  try {
    const response = await fetch('http://localhost:5000/api/auth/forgot-password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: 'invalid-email'
      })
    });
    
    const data = await response.json();
    
    if (response.status === 400) {
      console.log('✅ Invalid email properly rejected');
      console.log('✅ Error message:', data.message);
      return true;
    } else {
      console.log('❌ Invalid email should be rejected');
      return false;
    }
  } catch (error) {
    console.log('❌ Test failed:', error.message);
    return false;
  }
}

// Check if login page loads
async function testLoginPageLoads() {
  console.log('\nTesting if login page loads...');
  
  try {
    const response = await fetch('http://localhost:5000/login');
    
    if (response.ok) {
      const html = await response.text();
      
      // Check for forgot password elements
      const hasForgotPassword = html.includes('Forgot password') || html.includes('forgot');
      const hasRememberMe = html.includes('Remember me') || html.includes('remember');
      
      console.log('✅ Login page loads successfully');
      console.log('✅ Contains forgot password:', hasForgotPassword);
      console.log('✅ Contains remember me:', hasRememberMe);
      
      return hasForgotPassword && hasRememberMe;
    } else {
      console.log('❌ Login page failed to load');
      return false;
    }
  } catch (error) {
    console.log('❌ Failed to load login page:', error.message);
    return false;
  }
}

// Check server status
async function checkServerStatus() {
  try {
    const response = await fetch('http://localhost:5000/api/destinations');
    return response.ok;
  } catch (error) {
    return false;
  }
}

// Run all tests
async function runAllTests() {
  console.log('🧪 Starting Forgot Password Functionality Test');
  console.log('================================================');
  
  // Check if server is running
  const serverRunning = await checkServerStatus();
  if (!serverRunning) {
    console.log('❌ Server not running on localhost:5000');
    console.log('Please ensure the application is started');
    return;
  }
  
  console.log('✅ Server is running');
  
  // Run tests
  const results = [];
  
  results.push(await testLoginPageLoads());
  results.push(await testForgotPasswordAPI());
  results.push(await testInvalidEmail());
  
  // Summary
  console.log('\n📋 Test Results Summary');
  console.log('========================');
  
  const passed = results.filter(r => r).length;
  const total = results.length;
  
  console.log(`Passed: ${passed}/${total} tests`);
  
  if (passed === total) {
    console.log('🎉 All tests passed! Forgot password functionality is working correctly.');
    console.log('\nUser Experience Summary:');
    console.log('- Login page loads with forgot password button');
    console.log('- Forgot password API accepts valid emails');
    console.log('- Invalid emails are properly rejected');
    console.log('- Remember me checkbox is available');
    console.log('- Backend processes password reset requests');
  } else {
    console.log('⚠️  Some tests failed. Please check the issues above.');
  }
}

runAllTests();