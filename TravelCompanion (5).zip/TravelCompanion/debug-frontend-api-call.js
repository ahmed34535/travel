/**
 * Debug Frontend API Call - Check what happens when frontend calls the API
 */

async function debugFrontendAPICall() {
  console.log("🔍 Debugging frontend API call...");
  
  // Simulate the exact call the frontend makes
  const requestBody = {
    origin: "LAX",
    destination: "JFK", 
    departureDate: "2025-06-17",
    adults: 1,
    children: 0,
    infants: 0,
    cabin_class: "economy"
  };
  
  console.log("1. Testing frontend request format...");
  console.log("Request body:", JSON.stringify(requestBody, null, 2));
  
  try {
    const response = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    });
    
    console.log(`Response status: ${response.status}`);
    console.log(`Response headers:`, Object.fromEntries(response.headers.entries()));
    
    if (response.ok) {
      const data = await response.json();
      console.log(`✅ API call successful`);
      console.log(`📊 Flights returned: ${data.data?.length || 0}`);
      
      if (data.data && data.data.length > 0) {
        const flight = data.data[0];
        console.log(`🛫 Sample flight:`, {
          id: flight.id,
          airline: flight.owner?.name,
          price: `${flight.total_currency} ${flight.total_amount}`,
          route: `${flight.slices?.[0]?.origin?.iata_code} → ${flight.slices?.[0]?.destination?.iata_code}`
        });
        
        console.log("✅ Frontend should be able to display this data");
      } else {
        console.log("❌ No flight data in response");
      }
    } else {
      const errorText = await response.text();
      console.log(`❌ API call failed: ${response.status}`);
      console.log(`Error response:`, errorText);
    }
  } catch (error) {
    console.error("❌ Request failed:", error.message);
  }
  
  console.log("\n2. Now testing actual frontend page rendering...");
  
  // Check if the frontend page loads and what it contains
  try {
    const frontendResponse = await fetch('http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy');
    
    if (frontendResponse.ok) {
      const html = await frontendResponse.text();
      
      // Look for specific indicators
      const indicators = {
        'React Query loading': html.includes('queryKey'),
        'API endpoint reference': html.includes('/api/flight-search'),
        'Error boundary': html.includes('error'),
        'Flight results component': html.includes('flight-results'),
        'Console logs': html.includes('console.log'),
        'JavaScript errors': html.includes('ReferenceError') || html.includes('TypeError')
      };
      
      console.log("Frontend page indicators:");
      Object.entries(indicators).forEach(([key, value]) => {
        console.log(`- ${key}: ${value}`);
      });
      
    } else {
      console.log(`Frontend page failed: ${frontendResponse.status}`);
    }
  } catch (error) {
    console.error("Frontend page test failed:", error.message);
  }
}

debugFrontendAPICall().catch(console.error);