/**
 * Create Complete Deployment Package
 * Generates a comprehensive package with all files needed for deployment
 */

import fs from 'fs/promises';
import path from 'path';

async function createDeploymentPackage() {
  console.log("Creating complete TravalSearch deployment package...\n");

  const packageData = {
    name: "travalsearch",
    version: "1.0.0",
    type: "module",
    scripts: {
      "dev": "NODE_ENV=development tsx server/index.ts",
      "build": "vite build",
      "start": "NODE_ENV=production tsx server/index.ts",
      "db:push": "drizzle-kit push",
      "db:studio": "drizzle-kit studio"
    },
    dependencies: {
      "@hookform/resolvers": "^3.3.2",
      "@neondatabase/serverless": "^0.9.0",
      "@radix-ui/react-accordion": "^1.1.2",
      "@radix-ui/react-alert-dialog": "^1.0.5",
      "@radix-ui/react-avatar": "^1.0.4",
      "@radix-ui/react-checkbox": "^1.0.4",
      "@radix-ui/react-dialog": "^1.0.5",
      "@radix-ui/react-dropdown-menu": "^2.0.6",
      "@radix-ui/react-label": "^2.0.2",
      "@radix-ui/react-popover": "^1.0.7",
      "@radix-ui/react-select": "^2.0.0",
      "@radix-ui/react-separator": "^1.0.3",
      "@radix-ui/react-slot": "^1.0.2",
      "@radix-ui/react-tabs": "^1.0.4",
      "@radix-ui/react-toast": "^1.1.5",
      "@tanstack/react-query": "^5.0.0",
      "@types/express": "^4.17.21",
      "@types/node": "^20.0.0",
      "@types/react": "^18.2.0",
      "@types/react-dom": "^18.2.0",
      "@vitejs/plugin-react": "^4.2.0",
      "class-variance-authority": "^0.7.0",
      "clsx": "^2.0.0",
      "date-fns": "^3.0.0",
      "drizzle-kit": "^0.20.0",
      "drizzle-orm": "^0.30.0",
      "drizzle-zod": "^0.5.1",
      "express": "^4.18.2",
      "lucide-react": "^0.400.0",
      "react": "^18.2.0",
      "react-dom": "^18.2.0",
      "react-hook-form": "^7.48.0",
      "tailwind-merge": "^2.0.0",
      "tailwindcss": "^3.4.0",
      "tailwindcss-animate": "^1.0.7",
      "tsx": "^4.7.0",
      "typescript": "^5.3.0",
      "vite": "^5.0.0",
      "wouter": "^3.0.0",
      "zod": "^3.22.0"
    }
  };

  const setupScript = `#!/bin/bash
# TravalSearch Complete Setup Script

echo "🚀 Setting up TravalSearch platform..."

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

# Create project structure
echo "📁 Creating directory structure..."
mkdir -p client/src/{components,pages,contexts,lib}
mkdir -p server
mkdir -p shared
mkdir -p api-integration/{duffel,types,config}

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Setup environment
echo "🔧 Setting up environment..."
if [ ! -f .env ]; then
    echo "DATABASE_URL=your_postgresql_database_url" > .env
    echo "DUFFEL_API_TOKEN=your_duffel_api_token" >> .env
    echo "NODE_ENV=development" >> .env
    echo "✅ Created .env file - please update with your credentials"
fi

# Database setup
echo "🗄️ Setting up database..."
npm run db:push

echo "✅ TravalSearch setup complete!"
echo ""
echo "Next steps:"
echo "1. Update .env with your database URL and Duffel API token"
echo "2. Run: npm run dev"
echo "3. Open: http://localhost:5000"
echo ""
echo "For production: npm run build && npm start"
`;

  const readmeContent = `# TravalSearch - Full-Stack Travel Booking Platform

## Quick Start

\`\`\`bash
# 1. Clone and setup
git clone <repository-url>
cd travalsearch

# 2. Run setup script
chmod +x setup.sh
./setup.sh

# 3. Update environment variables in .env

# 4. Start development server
npm run dev
\`\`\`

## Features

- ✈️ Live flight search with Duffel API
- 🏨 Hotel booking system
- 👤 User authentication
- 📱 Responsive design
- 🎨 Modern UI with Tailwind CSS

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **UI**: Tailwind CSS, shadcn/ui
- **APIs**: Duffel for flights

## Environment Variables

\`\`\`env
DATABASE_URL=postgresql://username:password@host/database
DUFFEL_API_TOKEN=duffel_live_your_token_here
NODE_ENV=development
\`\`\`

## Available Scripts

- \`npm run dev\` - Start development server
- \`npm run build\` - Build for production
- \`npm start\` - Start production server
- \`npm run db:push\` - Push database schema
- \`npm run db:studio\` - Open database studio

## Deployment

### Single Command Deployment
\`\`\`bash
npm run build && npm start
\`\`\`

### Production with PM2
\`\`\`bash
npm install -g pm2
pm2 start "npm start" --name "travalsearch"
\`\`\`

## File Structure

\`\`\`
travalsearch/
├── client/src/          # React frontend
├── server/              # Express backend
├── shared/              # Shared types and schemas
├── api-integration/     # External API integrations
├── package.json         # Dependencies and scripts
├── vite.config.ts       # Build configuration
└── .env                 # Environment variables
\`\`\`

## Documentation

- See \`DEPLOYMENT_GUIDE.md\` for detailed deployment instructions
- See \`replit.md\` for complete project architecture
`;

  const dockerfileContent = `FROM node:20-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy source code
COPY . .

# Build application
RUN npm run build

# Expose port
EXPOSE 5000

# Start application
CMD ["npm", "start"]
`;

  const dockerComposeContent = `version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=\${DATABASE_URL}
      - DUFFEL_API_TOKEN=\${DUFFEL_API_TOKEN}
    depends_on:
      - postgres

  postgres:
    image: postgres:16-alpine
    environment:
      - POSTGRES_DB=travalsearch
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

volumes:
  postgres_data:
`;

  try {
    // Create package.json
    await fs.writeFile('package-deployment.json', JSON.stringify(packageData, null, 2));
    console.log("✅ Created deployment package.json");

    // Create setup script
    await fs.writeFile('setup.sh', setupScript);
    console.log("✅ Created setup script");

    // Create README
    await fs.writeFile('README-deployment.md', readmeContent);
    console.log("✅ Created deployment README");

    // Create Docker files
    await fs.writeFile('Dockerfile', dockerfileContent);
    await fs.writeFile('docker-compose.yml', dockerComposeContent);
    console.log("✅ Created Docker configuration");

    // Create deployment command
    const deployCommand = `#!/bin/bash
# Single command to recreate TravalSearch

echo "🚀 Recreating TravalSearch platform..."

# Setup project
mkdir -p travalsearch && cd travalsearch

# Copy configuration
cp ../package-deployment.json package.json
cp ../setup.sh .
cp ../README-deployment.md README.md
cp ../Dockerfile .
cp ../docker-compose.yml .

# Make setup executable
chmod +x setup.sh

# Run setup
./setup.sh

echo "✅ TravalSearch recreation complete!"
echo "Update .env with your credentials and run: npm run dev"
`;

    await fs.writeFile('recreate-travalsearch.sh', deployCommand);
    console.log("✅ Created recreation script");

    console.log("\n🎉 Complete deployment package created!");
    console.log("\nFiles created:");
    console.log("- package-deployment.json (Dependencies)");
    console.log("- setup.sh (Setup script)");
    console.log("- README-deployment.md (Documentation)");
    console.log("- Dockerfile (Container deployment)");
    console.log("- docker-compose.yml (Full stack deployment)");
    console.log("- recreate-travalsearch.sh (Single command recreation)");

    console.log("\n🚀 To recreate the website:");
    console.log("1. chmod +x recreate-travalsearch.sh");
    console.log("2. ./recreate-travalsearch.sh");
    console.log("3. Update .env with your credentials");
    console.log("4. npm run dev");

  } catch (error) {
    console.error("❌ Error creating deployment package:", error);
  }
}

createDeploymentPackage();