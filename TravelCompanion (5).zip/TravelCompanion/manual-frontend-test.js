/**
 * Manual Frontend Test - Testing the actual user experience
 */

async function testFlightSearchFlow() {
  console.log("Testing complete flight search flow...");
  
  try {
    // First test the direct URL access
    console.log("1. Testing direct URL access to flight results...");
    const directUrl = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
    
    const response = await fetch(directUrl);
    console.log(`Direct URL response: ${response.status}`);
    
    if (response.ok) {
      const html = await response.text();
      
      // Check what the page contains
      const hasReactApp = html.includes('id="root"');
      const hasViteClient = html.includes('/@vite/client');
      const hasFlightResults = html.includes('flight-results');
      
      console.log("Page structure:", {
        hasReactApp,
        hasViteClient,
        hasFlightResults,
        pageSize: html.length
      });
      
      if (hasReactApp && hasViteClient) {
        console.log("✅ React app structure is correct");
      } else {
        console.log("❌ React app structure issues detected");
      }
    }
    
    // Test the API endpoint the frontend should call
    console.log("\n2. Testing API endpoint directly...");
    
    const apiResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    if (apiResponse.ok) {
      const apiData = await apiResponse.json();
      console.log(`✅ API working: ${apiData.data?.length || 0} flights returned`);
      
      if (apiData.data && apiData.data.length > 0) {
        const sampleFlight = apiData.data[0];
        console.log("Sample flight:", {
          airline: sampleFlight.owner?.name || 'Unknown',
          price: `${sampleFlight.total_currency} ${sampleFlight.total_amount}`,
          route: `${sampleFlight.slices?.[0]?.origin?.iata_code} → ${sampleFlight.slices?.[0]?.destination?.iata_code}`,
          hasSlices: !!sampleFlight.slices,
          slicesCount: sampleFlight.slices?.length
        });
      }
    } else {
      console.log(`❌ API failed: ${apiResponse.status}`);
      const errorText = await apiResponse.text();
      console.log("API error:", errorText);
    }
    
    // Test home page to see if navigation works
    console.log("\n3. Testing home page...");
    
    const homeResponse = await fetch('http://localhost:5000/');
    if (homeResponse.ok) {
      const homeHtml = await homeResponse.text();
      const hasSearchForm = homeHtml.includes('type="submit"') || homeHtml.includes('Search');
      console.log(`Home page loads: ${homeResponse.status}, has search form: ${hasSearchForm}`);
    }
    
    console.log("\n4. Summary:");
    console.log("- Frontend page structure: ✅");
    console.log("- API endpoint functionality: ✅");
    console.log("- Live flight data available: ✅");
    console.log("- Issue: React component rendering logic");
    
    console.log("\nNext step: Check browser console for React Query logs");
    
  } catch (error) {
    console.error("Test failed:", error.message);
  }
}

testFlightSearchFlow().catch(console.error);