/**
 * Debug Hotel Details - Find what's not working for customers
 */

async function debugHotelDetails() {
  console.log("Debugging hotel details that aren't working...\n");

  try {
    // 1. Check what data is actually available
    const response = await fetch('http://localhost:5000/api/hotels');
    const hotels = await response.json();
    
    console.log("1. Hotel data structure:");
    if (hotels.length > 0) {
      const firstHotel = hotels[0];
      console.log("   Sample hotel object:");
      Object.keys(firstHotel).forEach(key => {
        console.log(`   ${key}: ${typeof firstHotel[key]} = ${firstHotel[key]}`);
      });
    }

    // 2. Check hotels page HTML for missing elements
    console.log("\n2. Checking what renders on hotels page...");
    const pageResponse = await fetch('http://localhost:5000/hotels');
    const html = await pageResponse.text();
    
    // Check for specific UI elements
    const checks = {
      'Hotel search form': html.includes('Where are you going'),
      'Check-in field': html.includes('Check-in'),
      'Check-out field': html.includes('Check-out'),
      'Guest field': html.includes('Guest'),
      'Search button': html.includes('Search Hotels'),
      'Hotel cards': html.includes('Grand Plaza'),
      'Pricing display': html.includes('$299'),
      'Rating stars': html.includes('Star'),
      'Amenities': html.includes('Free WiFi'),
      'Location info': html.includes('Manhattan'),
      'View Details button': html.includes('View Details')
    };

    Object.entries(checks).forEach(([element, present]) => {
      console.log(`   ${element}: ${present ? 'PRESENT' : 'MISSING'}`);
    });

    // 3. Test what happens with different search terms
    console.log("\n3. Testing search functionality...");
    
    const searchTests = ['New York', 'Miami', 'Colorado', 'Los Angeles'];
    searchTests.forEach(location => {
      const matches = hotels.filter(hotel => 
        hotel.location.toLowerCase().includes(location.toLowerCase()) ||
        hotel.name.toLowerCase().includes(location.toLowerCase())
      );
      console.log(`   Search "${location}": ${matches.length} results`);
      matches.forEach(hotel => {
        console.log(`     - ${hotel.name} (${hotel.location})`);
      });
    });

    // 4. Check for specific missing functionality
    console.log("\n4. Checking common hotel booking features...");
    
    const features = {
      'Date picker functionality': html.includes('type="date"'),
      'Guest count selector': html.includes('type="number"'),
      'Filter options': html.includes('Filter'),
      'Sort options': html.includes('Sort'),
      'Map view': html.includes('Map'),
      'Photo gallery': html.includes('imageUrl'),
      'Room types': html.includes('room'),
      'Booking button': html.includes('Book') || html.includes('Reserve'),
      'Price breakdown': html.includes('per night'),
      'Cancellation policy': html.includes('cancellation')
    };

    Object.entries(features).forEach(([feature, present]) => {
      console.log(`   ${feature}: ${present ? 'AVAILABLE' : 'MISSING'}`);
    });

    console.log("\n=== ISSUES IDENTIFIED ===");
    const issues = [];
    
    if (!checks['Check-in field']) issues.push("Check-in date picker not visible");
    if (!checks['Check-out field']) issues.push("Check-out date picker not visible");
    if (!checks['Guest field']) issues.push("Guest selection not visible");
    if (!checks['View Details button']) issues.push("Hotel detail buttons missing");
    if (!features['Booking button']) issues.push("Booking functionality missing");
    if (!features['Room types']) issues.push("Room type selection missing");
    
    if (issues.length > 0) {
      console.log("Customer experience issues found:");
      issues.forEach((issue, index) => {
        console.log(`${index + 1}. ${issue}`);
      });
    } else {
      console.log("No major issues detected - hotel functionality appears complete");
    }

  } catch (error) {
    console.log(`Debug error: ${error.message}`);
  }
}

debugHotelDetails().catch(console.error);