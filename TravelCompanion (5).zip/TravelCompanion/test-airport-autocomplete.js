/**
 * Airport Autocomplete User Experience Test
 * Tests the complete flow of typing in airport search and seeing suggestions
 */

import puppeteer from 'puppeteer';

async function testAirportAutocomplete() {
  const browser = await puppeteer.launch({ 
    headless: false,
    defaultViewport: { width: 1200, height: 800 }
  });
  
  try {
    const page = await browser.newPage();
    
    console.log("🌐 Opening TravalSearch homepage...");
    await page.goto('http://localhost:5000', { waitUntil: 'networkidle0' });
    
    // Wait for the flight search form to be visible
    await page.waitForSelector('[data-testid="flight-search-form"]', { timeout: 10000 });
    console.log("✅ Flight search form loaded");
    
    // Test typing in the "From" airport field
    console.log("✈️ Testing airport autocomplete - typing 'los'");
    const fromInput = await page.$('input[placeholder*="New York"]') || await page.$('input[id="from"]') || await page.$('input:first-of-type');
    
    if (fromInput) {
      // Clear the field and type
      await fromInput.click();
      await fromInput.evaluate(el => el.value = '');
      await fromInput.type('los', { delay: 200 });
      
      // Wait for dropdown to appear
      await page.waitForTimeout(1000);
      
      // Check if dropdown suggestions are visible
      const dropdown = await page.$('[class*="dropdown"], [class*="suggestions"], [class*="autocomplete"]');
      if (dropdown) {
        console.log("✅ Dropdown suggestions appeared");
        
        // Check for Los Angeles in the suggestions
        const suggestions = await page.$$eval('button:contains("Los Angeles"), div:contains("Los Angeles"), li:contains("Los Angeles")', 
          elements => elements.map(el => el.textContent));
        
        if (suggestions.length > 0) {
          console.log("✅ Los Angeles found in suggestions:", suggestions[0]);
        } else {
          console.log("❌ Los Angeles not found in suggestions");
        }
      } else {
        console.log("❌ No dropdown suggestions found");
      }
      
      // Test typing in destination field
      console.log("✈️ Testing destination field - typing 'new'");
      const toInput = await page.$('input[placeholder*="Los Angeles"]') || await page.$('input[id="to"]') || await page.$('input:nth-of-type(2)');
      
      if (toInput) {
        await toInput.click();
        await toInput.evaluate(el => el.value = '');
        await toInput.type('new', { delay: 200 });
        
        await page.waitForTimeout(1000);
        
        // Check for New York suggestions
        const nyDropdown = await page.$('[class*="dropdown"], [class*="suggestions"]');
        if (nyDropdown) {
          console.log("✅ Destination dropdown appeared");
        }
      }
      
    } else {
      console.log("❌ Could not find airport input field");
    }
    
    // Take a screenshot of the current state
    await page.screenshot({ path: 'airport-autocomplete-test.png', fullPage: true });
    console.log("📸 Screenshot saved as airport-autocomplete-test.png");
    
  } catch (error) {
    console.error("❌ Test failed:", error.message);
  } finally {
    await browser.close();
  }
}

// Test the API endpoint directly first
async function testAPIEndpoint() {
  console.log("🔍 Testing airport search API directly...");
  
  const testQueries = ['los', 'new', 'lax', 'jfk', 'london'];
  
  for (const query of testQueries) {
    try {
      const response = await fetch(`http://localhost:5000/api/airports?q=${query}`);
      const data = await response.json();
      
      console.log(`Query: "${query}" → ${data.data?.length || 0} results`);
      if (data.data?.[0]) {
        console.log(`  First result: ${data.data[0].city_name} (${data.data[0].iata_code})`);
      }
    } catch (error) {
      console.log(`❌ API test failed for "${query}":`, error.message);
    }
  }
}

async function runCompleteTest() {
  console.log("🚀 Starting complete airport autocomplete test...\n");
  
  // Test API first
  await testAPIEndpoint();
  console.log("\n" + "=".repeat(50) + "\n");
  
  // Test user interface
  await testAirportAutocomplete();
  
  console.log("\n✅ Airport autocomplete test completed!");
}

runCompleteTest().catch(console.error);