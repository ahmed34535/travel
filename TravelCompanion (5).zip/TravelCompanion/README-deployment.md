# TravalSearch - Full-Stack Travel Booking Platform

## Quick Start

```bash
# 1. Clone and setup
git clone <repository-url>
cd travalsearch

# 2. Run setup script
chmod +x setup.sh
./setup.sh

# 3. Update environment variables in .env

# 4. Start development server
npm run dev
```

## Features

- ✈️ Live flight search with Duffel API
- 🏨 Hotel booking system
- 👤 User authentication
- 📱 Responsive design
- 🎨 Modern UI with Tailwind CSS

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **UI**: Tailwind CSS, shadcn/ui
- **APIs**: Duffel for flights

## Environment Variables

```env
DATABASE_URL=postgresql://username:password@host/database
DUFFEL_API_TOKEN=duffel_live_your_token_here
NODE_ENV=development
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run db:push` - Push database schema
- `npm run db:studio` - Open database studio

## Deployment

### Single Command Deployment
```bash
npm run build && npm start
```

### Production with PM2
```bash
npm install -g pm2
pm2 start "npm start" --name "travalsearch"
```

## File Structure

```
travalsearch/
├── client/src/          # React frontend
├── server/              # Express backend
├── shared/              # Shared types and schemas
├── api-integration/     # External API integrations
├── package.json         # Dependencies and scripts
├── vite.config.ts       # Build configuration
└── .env                 # Environment variables
```

## Documentation

- See `DEPLOYMENT_GUIDE.md` for detailed deployment instructions
- See `replit.md` for complete project architecture
