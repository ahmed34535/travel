# TravalSearch Customer Support & Issue Resolution Guide

## Common Customer Issues & Solutions

### Flight Search Issues

#### 1. "No flights found" or "Search returns empty"
**Immediate Actions:**
- Check if customer entered valid airport codes (LAX, JFK, etc.)
- Verify departure date is in the future
- Confirm passenger count is between 1-9

**Technical Troubleshooting:**
```bash
# Test flight search API directly
curl -X POST http://localhost:5000/api/flight-search \
  -H "Content-Type: application/json" \
  -d '{"origin":"LAX","destination":"JFK","departureDate":"2025-07-01","passengers":{"adults":1}}'
```

**If API fails:**
- Check DUFFEL_API_TOKEN environment variable
- Verify Duffel API status at https://status.duffel.com
- Contact Duffel support if API is down

#### 2. "Slow flight search results"
**Expected Behavior:** 
- Duffel API responses take 2-4 seconds (normal)
- Platform shows loading indicator during search

**Optimization:**
- Results are cached after first search
- Subsequent searches for same route are faster

### Hotel Search Issues

#### 3. "City autocomplete not working"
**Customer Action:**
- Type at least 2 letters (e.g., "Ne" for New York)
- Click on suggestion from dropdown

**Available Cities:**
New York, Manhattan, Miami, Miami Beach, Los Angeles, Chicago, Las Vegas, San Francisco, Boston, Denver, Aspen, Savannah, Scottsdale, Orlando, Nashville, Seattle, Portland, Austin

**If autocomplete fails:**
```bash
# Test hotel data
curl http://localhost:5000/api/hotels
```

#### 4. "No hotels showing"
**Common Causes:**
- React component rendering issue
- Database connection problem

**Quick Fix:**
1. Refresh the page
2. Clear browser cache
3. Try different city name

### Booking & Payment Issues

#### 5. "Cannot complete booking"
**Current Status:** 
- Platform configured for live bookings with 2% markup
- Requires active Duffel API token for production

**For Live Bookings:**
- Customer needs valid payment method
- Booking confirmation sent via email
- Reference number provided for tracking

#### 6. "Price discrepancies"
**Pricing Formula:**
- Final Price = (Base Price + 2% Markup) / (1 - 0.029)
- 2% markup covers platform revenue
- 2.9% accounts for payment processing fees

## When to Contact Duffel Support

### Duffel API Issues
Contact Duffel when:
- API returns consistent errors across multiple searches
- Flight offers show incorrect pricing
- Booking process fails after successful payment
- Airport search returns invalid codes

### Duffel Contact Information
- **Support Email:** help@duffel.com
- **Status Page:** https://status.duffel.com
- **Documentation:** https://duffel.com/docs
- **API Version:** v2 (current integration)

### Information to Provide Duffel
When contacting Duffel support, include:
1. **API Token:** (first 8 characters only for security)
2. **Request ID:** From failed API calls
3. **Timestamp:** When issue occurred
4. **Error Response:** Complete API error message
5. **Search Parameters:** Origin, destination, dates

### Sample Duffel Support Email
```
Subject: API Issue - Flight Search Failing

Hello Duffel Support,

We're experiencing issues with the flight search API on our platform TravalSearch.

Issue Details:
- API Endpoint: /air/offer_requests
- Error: [specific error message]
- Timestamp: [date/time]
- Request ID: [if available]
- Search: LAX to JFK, 2025-07-01

Our API token starts with: duffel_te...

Could you please investigate this issue?

Best regards,
TravalSearch Support Team
```

## Escalation Procedures

### Level 1: Customer Support (You)
**Handle:**
- Basic troubleshooting
- Account issues
- Platform navigation help
- Common booking questions

### Level 2: Technical Support
**Escalate when:**
- API errors persist
- Database issues
- Payment processing failures
- System-wide outages

**Contact Duffel for:**
- Flight data accuracy issues
- Booking confirmation problems
- API rate limiting issues
- New airport codes needed

### Level 3: Engineering Team
**Critical Issues:**
- Security concerns
- Data integrity problems
- Major system failures
- Payment security issues

## Customer Communication Templates

### Flight Search Issue Response
```
Hi [Customer Name],

Thank you for contacting TravalSearch support.

I understand you're having trouble finding flights for your search. Let me help you resolve this:

1. Please verify your search details:
   - Departure city: [confirm]
   - Destination city: [confirm]  
   - Travel date: [confirm]
   - Number of passengers: [confirm]

2. Try these steps:
   - Use airport codes (LAX, JFK, ORD)
   - Ensure date is in the future
   - Clear browser cache and try again

Our flight search connects directly to airline systems and typically returns 50+ options for most routes.

If the issue persists, I'll escalate to our technical team for investigation.

Best regards,
TravalSearch Customer Support
```

### Hotel Search Issue Response
```
Hi [Customer Name],

I'm sorry you're experiencing issues with hotel search.

Our platform includes hotels in these destinations:
- New York area (Manhattan, Brooklyn, Queens)
- Miami area (Miami Beach, South Beach)
- Los Angeles area (Hollywood, Beverly Hills)
- Chicago, Las Vegas, San Francisco, Boston
- And 15+ other popular destinations

To use the city search:
1. Start typing your destination (e.g., "New" for New York)
2. Select from the dropdown suggestions
3. Choose your dates and guest count
4. Click "Search Hotels"

If you still don't see suggestions, please let me know your desired destination and I'll check availability.

Best regards,
TravalSearch Customer Support
```

## System Status Monitoring

### Health Checks
Monitor these endpoints:
- `/api/hotels` - Hotel data availability
- `/api/airports` - Airport search functionality
- `/api/flight-search` - Duffel API connectivity

### Error Monitoring
Watch for:
- Duffel API rate limits
- Database connection timeouts
- Frontend-backend communication failures

### Performance Metrics
Track:
- Flight search response times (target: <5 seconds)
- Hotel autocomplete response (target: <1 second)
- Page load times (target: <3 seconds)

## Emergency Procedures

### Platform Down
1. Check system status
2. Verify database connectivity
3. Test Duffel API status
4. Contact hosting provider if needed
5. Update customers via status page

### Payment Issues
1. Verify payment processor status
2. Check Duffel Cards integration
3. Contact payment provider
4. Document transaction details
5. Escalate to finance team

### Data Security Incident
1. Immediately secure affected systems
2. Document incident details
3. Notify security team
4. Contact legal team if customer data affected
5. Prepare customer communication

---

**Support Team Training:** All support staff should be familiar with the platform's technical architecture and common troubleshooting steps outlined in the deployment package.

**Last Updated:** June 16, 2025