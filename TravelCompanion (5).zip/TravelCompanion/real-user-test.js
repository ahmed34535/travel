/**
 * Real Human User Test - Actually navigating and using the website
 */

const puppeteer = require('puppeteer');

async function testLikeRealUser() {
  console.log("Testing exactly like a real human user...");
  
  let browser;
  try {
    browser = await puppeteer.launch({ 
      headless: false,
      defaultViewport: null,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--start-maximized']
    });
    
    const page = await browser.newPage();
    
    // Listen to all console messages from the browser
    page.on('console', msg => {
      console.log(`[Browser] ${msg.type()}: ${msg.text()}`);
    });
    
    page.on('pageerror', error => {
      console.log(`[Error] ${error.message}`);
    });
    
    console.log("1. Going to homepage...");
    await page.goto('http://localhost:5000', { waitUntil: 'networkidle2' });
    
    // Take screenshot of homepage
    await page.screenshot({ path: 'homepage.png', fullPage: true });
    console.log("Homepage screenshot saved");
    
    console.log("2. Looking for flight search form...");
    
    // Wait for the page to load
    await page.waitForTimeout(2000);
    
    // Find and fill origin
    try {
      await page.waitForSelector('input[placeholder*="From"]', { timeout: 5000 });
      await page.click('input[placeholder*="From"]');
      await page.type('input[placeholder*="From"]', 'LAX');
      console.log("Typed LAX in origin field");
    } catch (error) {
      console.log("Could not find origin input field");
    }
    
    await page.waitForTimeout(1000);
    
    // Find and fill destination
    try {
      await page.click('input[placeholder*="To"]');
      await page.type('input[placeholder*="To"]', 'JFK');
      console.log("Typed JFK in destination field");
    } catch (error) {
      console.log("Could not find destination input field");
    }
    
    await page.waitForTimeout(1000);
    
    // Set date to tomorrow
    try {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const dateString = tomorrow.toISOString().split('T')[0];
      
      await page.evaluate((date) => {
        const dateInput = document.querySelector('input[type="date"]');
        if (dateInput) {
          dateInput.value = date;
          dateInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }, dateString);
      console.log("Set departure date");
    } catch (error) {
      console.log("Could not set date");
    }
    
    console.log("3. Submitting search...");
    
    // Click search button
    try {
      const searchButton = await page.$('button[type="submit"]');
      if (searchButton) {
        await searchButton.click();
        console.log("Clicked search button");
        
        // Wait for navigation
        await page.waitForNavigation({ timeout: 10000 });
        console.log("Navigated to results page");
      } else {
        console.log("Search button not found");
      }
    } catch (error) {
      console.log("Navigation error:", error.message);
    }
    
    console.log("4. Waiting for results to load...");
    await page.waitForTimeout(8000); // Wait for API call
    
    // Take screenshot of results page
    await page.screenshot({ path: 'results-page.png', fullPage: true });
    console.log("Results page screenshot saved");
    
    // Check what's on the page
    const pageContent = await page.evaluate(() => {
      return {
        url: window.location.href,
        title: document.title,
        hasFlightResults: document.body.innerText.includes('Flight Results'),
        hasNoFlights: document.body.innerText.includes('No flights found'),
        hasBookButton: document.body.innerText.includes('Book Flight'),
        hasPrice: document.body.innerText.includes('$') || document.body.innerText.includes('USD'),
        hasAirline: document.body.innerText.includes('Airlines') || document.body.innerText.includes('Flight'),
        pageText: document.body.innerText.substring(0, 1000)
      };
    });
    
    console.log("\n5. Results analysis:");
    console.log(pageContent);
    
    if (pageContent.hasBookButton || pageContent.hasPrice) {
      console.log("✅ SUCCESS: Real user sees flight results!");
    } else if (pageContent.hasNoFlights) {
      console.log("❌ ISSUE: User sees 'No flights found'");
    } else {
      console.log("⚠️ UNCLEAR: Unknown page state");
    }
    
  } catch (error) {
    console.error("Real user test failed:", error.message);
  } finally {
    // Keep browser open for 10 seconds to see results
    console.log("\nKeeping browser open for inspection...");
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    if (browser) {
      await browser.close();
    }
  }
}

testLikeRealUser().catch(console.error);