import { 
  destinations, hotels, flights, packages, users, bookings, webhooks, supportTickets, supportMessages,
  type Destination, type Hotel, type Flight, type Package, type User, type Booking, type Webhook, type SupportTicket, type SupportMessage,
  type InsertDestination, type InsertHotel, type InsertFlight, type InsertPackage, type InsertUser, type InsertBooking, type InsertWebhook, type InsertSupportTicket, type InsertSupportMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, ilike, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  updateUserPassword(id: number, newPassword: string): Promise<User | undefined>;
  updateUserAvatar(id: number, avatar: string): Promise<User | undefined>;
  
  // Destinations
  getDestinations(): Promise<Destination[]>;
  getDestination(id: number): Promise<Destination | undefined>;
  
  // Hotels
  getHotels(): Promise<Hotel[]>;
  getHotel(id: number): Promise<Hotel | undefined>;
  getFeaturedHotels(): Promise<Hotel[]>;
  searchHotels(location?: string, minPrice?: number, maxPrice?: number): Promise<Hotel[]>;
  
  // Flights
  getFlights(): Promise<Flight[]>;
  getFlight(id: number): Promise<Flight | undefined>;
  searchFlights(origin?: string, destination?: string, minPrice?: number, maxPrice?: number): Promise<Flight[]>;
  
  // Packages
  getPackages(): Promise<Package[]>;
  getPackage(id: number): Promise<Package | undefined>;
  
  // Bookings
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingByReference(reference: string): Promise<Booking | undefined>;
  getUserBookings(userId: number): Promise<Booking[]>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  
  // Webhooks
  getAllWebhooks(): Promise<Webhook[]>;
  getWebhook(id: number): Promise<Webhook | undefined>;
  createWebhook(webhook: InsertWebhook & { secret: string }): Promise<Webhook>;
  updateWebhook(id: number, updates: Partial<Webhook>): Promise<Webhook | undefined>;
  deleteWebhook(id: number): Promise<boolean>;
  incrementWebhookSuccess(id: number): Promise<void>;
  incrementWebhookFailure(id: number): Promise<void>;
  updateWebhookLastPing(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: any): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<any>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async updateUserPassword(id: number, newPassword: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ password: newPassword })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async updateUserAvatar(id: number, avatar: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ avatar: avatar })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Destinations - Live API required
  async getDestinations(): Promise<Destination[]> {
    throw new Error("Live travel API integration required for destinations");
  }

  async getDestination(id: number): Promise<Destination | undefined> {
    throw new Error("Live travel API integration required for destination details");
  }

  // Hotels - Live API required
  async getHotels(): Promise<Hotel[]> {
    throw new Error("Live hotel booking API integration required");
  }

  async getHotel(id: number): Promise<Hotel | undefined> {
    throw new Error("Live hotel booking API integration required");
  }

  async getFeaturedHotels(): Promise<Hotel[]> {
    throw new Error("Live hotel booking API integration required");
  }

  async searchHotels(location?: string, minPrice?: number, maxPrice?: number): Promise<Hotel[]> {
    throw new Error("Live hotel booking API integration required");
  }

  // Flights - Live API required
  async getFlights(): Promise<Flight[]> {
    throw new Error("Live flight API integration required");
  }

  async getFlight(id: number): Promise<Flight | undefined> {
    throw new Error("Live flight API integration required");
  }

  async searchFlights(origin?: string, destination?: string, minPrice?: number, maxPrice?: number): Promise<Flight[]> {
    throw new Error("Live flight API integration required");
  }

  // Packages - Live API required
  async getPackages(): Promise<Package[]> {
    throw new Error("Live travel package API integration required");
  }

  async getPackage(id: number): Promise<Package | undefined> {
    throw new Error("Live travel package API integration required");
  }

  // Bookings
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db
      .insert(bookings)
      .values(booking)
      .returning();
    return newBooking;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking || undefined;
  }

  async getBookingByReference(reference: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.reference, reference));
    return booking || undefined;
  }

  async getUserBookings(userId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId));
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const [booking] = await db
      .update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    return booking || undefined;
  }

  // Webhooks - Live API required
  async getAllWebhooks(): Promise<Webhook[]> {
    throw new Error("Live webhook API integration required");
  }

  async getWebhook(id: number): Promise<Webhook | undefined> {
    throw new Error("Live webhook API integration required");
  }

  async createWebhook(webhook: InsertWebhook & { secret: string }): Promise<Webhook> {
    throw new Error("Live webhook API integration required");
  }

  async updateWebhook(id: number, updates: Partial<Webhook>): Promise<Webhook | undefined> {
    throw new Error("Live webhook API integration required");
  }

  async deleteWebhook(id: number): Promise<boolean> {
    throw new Error("Live webhook API integration required");
  }

  async incrementWebhookSuccess(id: number): Promise<void> {
    throw new Error("Live webhook API integration required");
  }

  async incrementWebhookFailure(id: number): Promise<void> {
    throw new Error("Live webhook API integration required");
  }

  async updateWebhookLastPing(id: number): Promise<void> {
    throw new Error("Live webhook API integration required");
  }
}

export class LiveAPIStorage implements IStorage {
  private users: Map<number, User>;
  private bookings: Map<number, Booking>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.bookings = new Map();
    this.currentId = 1;
  }

  // Live API methods - no more mock data

  // Destinations - redirect to live travel APIs
  async getDestinations(): Promise<Destination[]> {
    throw new Error("Use live travel APIs for destinations. No mock data available.");
  }

  async getDestination(id: number): Promise<Destination | undefined> {
    throw new Error("Use live travel APIs for destination details. No mock data available.");
  }

  // Hotels - redirect to live booking APIs  
  async getHotels(): Promise<Hotel[]> {
    throw new Error("Use live hotel booking APIs (Booking.com, Expedia, etc). No mock data available.");
  }

  async getHotel(id: number): Promise<Hotel | undefined> {
    throw new Error("Use live hotel booking APIs for hotel details. No mock data available.");
  }

  async getFeaturedHotels(): Promise<Hotel[]> {
    throw new Error("Use live hotel booking APIs for featured hotels. No mock data available.");
  }

  async searchHotels(location?: string, minPrice?: number, maxPrice?: number): Promise<Hotel[]> {
    throw new Error("Use live hotel booking APIs for hotel search. No mock data available.");
  }

  // Flights - redirect to live Duffel API
  async getFlights(): Promise<Flight[]> {
    throw new Error("Use live Duffel API for flights. No mock data available.");
  }

  async getFlight(id: number): Promise<Flight | undefined> {
    throw new Error("Use live Duffel API for flight details. No mock data available.");
  }

  async searchFlights(origin?: string, destination?: string, minPrice?: number, maxPrice?: number): Promise<Flight[]> {
    throw new Error("Use live Duffel API for flight search. No mock data available.");
  }

  // Packages - redirect to live travel APIs
  async getPackages(): Promise<Package[]> {
    throw new Error("Use live travel package APIs. No mock data available.");
  }

  async getPackage(id: number): Promise<Package | undefined> {
    throw new Error("Use live travel package APIs for package details. No mock data available.");
  }

  // Essential user management
  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return undefined;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      id,
      email: userData.email,
      password: userData.password,
      firstName: userData.firstName,
      lastName: userData.lastName,
      username: userData.username,
      phone: userData.phone || null,
      dateOfBirth: userData.dateOfBirth || null,
      passportNumber: userData.passportNumber || null,
      emailVerified: false,
      phoneVerified: false,
      emailVerificationToken: null,
      phoneVerificationCode: null,
      nationality: userData.nationality || null,
      emergencyContactName: userData.emergencyContactName || null,
      emergencyContactPhone: userData.emergencyContactPhone || null,
      dietaryRequirements: userData.dietaryRequirements || null,
      accessibilityRequirements: userData.accessibilityRequirements || null,
      seatPreference: userData.seatPreference || null,
      mealPreference: userData.mealPreference || null,
      frequentFlyerNumbers: userData.frequentFlyerNumbers || null,
      preferredCurrency: userData.preferredCurrency || null,
      preferredLanguage: userData.preferredLanguage || null,
      twoFactorEnabled: false,
      apiKey: null,
      stripeCustomerId: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserPassword(id: number, newPassword: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      password: newPassword,
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserAvatar(id: number, avatar: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      avatar: avatar,
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Booking management
  async createBooking(bookingData: InsertBooking): Promise<Booking> {
    const id = this.currentId++;
    const booking: Booking = {
      id,
      userId: bookingData.userId,
      type: bookingData.type,
      status: bookingData.status,
      totalAmount: bookingData.totalAmount,
      currency: bookingData.currency,
      bookingData: bookingData.bookingData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async getBookingByReference(reference: string): Promise<Booking | undefined> {
    for (const booking of this.bookings.values()) {
      if (booking.bookingData && typeof booking.bookingData === 'object' && 
          'reference' in booking.bookingData && booking.bookingData.reference === reference) {
        return booking;
      }
    }
    return undefined;
  }

  async getUserBookings(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.userId === userId);
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    booking.status = status;
    booking.updatedAt = new Date();
    this.bookings.set(id, booking);
    return booking;
  }

  // Webhook management - placeholder for future implementation
  async getAllWebhooks(): Promise<Webhook[]> {
    return [];
  }

  async getWebhook(id: number): Promise<Webhook | undefined> {
    return undefined;
  }

  async createWebhook(webhook: InsertWebhook & { secret: string }): Promise<Webhook> {
    throw new Error("Webhook management requires live API integration");
  }

  async updateWebhook(id: number, updates: Partial<Webhook>): Promise<Webhook | undefined> {
    throw new Error("Webhook management requires live API integration");
  }

  async deleteWebhook(id: number): Promise<boolean> {
    throw new Error("Webhook management requires live API integration");
  }

  async incrementWebhookSuccess(id: number): Promise<void> {
    // Live webhook analytics implementation needed
  }

  async incrementWebhookFailure(id: number): Promise<void> {
    // Live webhook analytics implementation needed
  }

  async updateWebhookLastPing(id: number): Promise<void> {
    // Live webhook analytics implementation needed
  }
}

export const storage = new DatabaseStorage();