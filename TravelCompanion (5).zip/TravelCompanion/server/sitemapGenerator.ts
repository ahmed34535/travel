import { storage } from "./storage";

interface SitemapUrl {
  url: string;
  lastmod?: string;
  changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority?: number;
  alternates?: { hreflang: string; href: string }[];
}

// Popular flight routes for SEO pages
const POPULAR_ROUTES = [
  // US Domestic
  { from: 'LAX', to: 'JFK', fromCity: 'Los Angeles', toCity: 'New York' },
  { from: 'LAX', to: 'LAS', fromCity: 'Los Angeles', toCity: 'Las Vegas' },
  { from: 'LAX', to: 'SFO', fromCity: 'Los Angeles', toCity: 'San Francisco' },
  { from: 'JFK', to: 'LAX', fromCity: 'New York', toCity: 'Los Angeles' },
  { from: 'JFK', to: 'MIA', fromCity: 'New York', toCity: 'Miami' },
  { from: 'ORD', to: 'LAX', fromCity: 'Chicago', toCity: 'Los Angeles' },
  { from: 'DFW', to: 'JFK', fromCity: 'Dallas', toCity: 'New York' },
  { from: 'ATL', to: 'LAX', fromCity: 'Atlanta', toCity: 'Los Angeles' },
  
  // International from US
  { from: 'JFK', to: 'LHR', fromCity: 'New York', toCity: 'London' },
  { from: 'LAX', to: 'NRT', fromCity: 'Los Angeles', toCity: 'Tokyo' },
  { from: 'JFK', to: 'CDG', fromCity: 'New York', toCity: 'Paris' },
  { from: 'LAX', to: 'LHR', fromCity: 'Los Angeles', toCity: 'London' },
  { from: 'MIA', to: 'MAD', fromCity: 'Miami', toCity: 'Madrid' },
  { from: 'SFO', to: 'FRA', fromCity: 'San Francisco', toCity: 'Frankfurt' },
  
  // European Routes
  { from: 'LHR', to: 'CDG', fromCity: 'London', toCity: 'Paris' },
  { from: 'FRA', to: 'FCO', fromCity: 'Frankfurt', toCity: 'Rome' },
  { from: 'MAD', to: 'BCN', fromCity: 'Madrid', toCity: 'Barcelona' },
  { from: 'AMS', to: 'LHR', fromCity: 'Amsterdam', toCity: 'London' },
];

// Popular destinations for cheap flights pages
const POPULAR_DESTINATIONS = [
  { code: 'LHR', city: 'London', country: 'United Kingdom' },
  { code: 'CDG', city: 'Paris', country: 'France' },
  { code: 'FCO', city: 'Rome', country: 'Italy' },
  { code: 'MAD', city: 'Madrid', country: 'Spain' },
  { code: 'FRA', city: 'Frankfurt', country: 'Germany' },
  { code: 'AMS', city: 'Amsterdam', country: 'Netherlands' },
  { code: 'NRT', city: 'Tokyo', country: 'Japan' },
  { code: 'DXB', city: 'Dubai', country: 'UAE' },
  { code: 'SIN', city: 'Singapore', country: 'Singapore' },
  { code: 'HKG', city: 'Hong Kong', country: 'Hong Kong' },
];

// Supported languages and their regions
const LANGUAGE_REGIONS = [
  { lang: 'en', region: 'US', domain: 'travalsearch.com' },
  { lang: 'en', region: 'GB', domain: 'travalsearch.com' },
  { lang: 'en', region: 'CA', domain: 'travalsearch.com' },
  { lang: 'en', region: 'AU', domain: 'travalsearch.com' },
  { lang: 'es', region: 'ES', domain: 'travalsearch.com' },
  { lang: 'fr', region: 'FR', domain: 'travalsearch.com' },
  { lang: 'de', region: 'DE', domain: 'travalsearch.com' },
  { lang: 'it', region: 'IT', domain: 'travalsearch.com' },
  { lang: 'pt', region: 'PT', domain: 'travalsearch.com' },
  { lang: 'nl', region: 'NL', domain: 'travalsearch.com' },
];

function createAlternateLinks(basePath: string): { hreflang: string; href: string }[] {
  return LANGUAGE_REGIONS.map(({ lang, region, domain }) => ({
    hreflang: `${lang}-${region}`,
    href: `https://${domain}${basePath}`
  }));
}

export function generateSitemap(): string {
  const urls: SitemapUrl[] = [];
  const baseUrl = 'https://travalsearch.com';
  const currentDate = new Date().toISOString().split('T')[0];

  // Homepage
  urls.push({
    url: `${baseUrl}/`,
    lastmod: currentDate,
    changefreq: 'daily',
    priority: 1.0,
    alternates: createAlternateLinks('/')
  });

  // Main pages
  const mainPages = [
    { path: '/flights', priority: 0.9 },
    { path: '/hotels', priority: 0.8 },
    { path: '/about', priority: 0.6 },
    { path: '/support', priority: 0.7 },
    { path: '/privacy-policy', priority: 0.5 },
    { path: '/terms-of-service', priority: 0.5 },
  ];

  mainPages.forEach(page => {
    urls.push({
      url: `${baseUrl}${page.path}`,
      lastmod: currentDate,
      changefreq: 'weekly',
      priority: page.priority,
      alternates: createAlternateLinks(page.path)
    });
  });

  // Flight route pages (flights-from-X-to-Y)
  POPULAR_ROUTES.forEach(route => {
    const routePath = `/flights-from-${route.from.toLowerCase()}-to-${route.to.toLowerCase()}`;
    urls.push({
      url: `${baseUrl}${routePath}`,
      lastmod: currentDate,
      changefreq: 'daily',
      priority: 0.8,
      alternates: createAlternateLinks(routePath)
    });
  });

  // Cheap flights to destination pages
  POPULAR_DESTINATIONS.forEach(dest => {
    const destPath = `/cheap-flights-to-${dest.city.toLowerCase().replace(/\s+/g, '-')}`;
    urls.push({
      url: `${baseUrl}${destPath}`,
      lastmod: currentDate,
      changefreq: 'daily',
      priority: 0.7,
      alternates: createAlternateLinks(destPath)
    });
  });

  // Generate XML
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n';

  urls.forEach(urlObj => {
    xml += '  <url>\n';
    xml += `    <loc>${urlObj.url}</loc>\n`;
    if (urlObj.lastmod) xml += `    <lastmod>${urlObj.lastmod}</lastmod>\n`;
    if (urlObj.changefreq) xml += `    <changefreq>${urlObj.changefreq}</changefreq>\n`;
    if (urlObj.priority) xml += `    <priority>${urlObj.priority}</priority>\n`;
    
    // Add hreflang alternates for international SEO
    if (urlObj.alternates) {
      urlObj.alternates.forEach(alt => {
        xml += `    <xhtml:link rel="alternate" hreflang="${alt.hreflang}" href="${alt.href}" />\n`;
      });
    }
    
    xml += '  </url>\n';
  });

  xml += '</urlset>';
  return xml;
}

export function generateRobotsTxt(): string {
  return `User-agent: *
Allow: /

# Block admin and internal areas
Disallow: /admin/
Disallow: /api/
Disallow: /dev/

# Allow all search engines to crawl flight and hotel pages
Allow: /flights*
Allow: /hotels*
Allow: /cheap-flights*
Allow: /flights-from*
Allow: /flights-to*

Sitemap: https://travalsearch.com/sitemap.xml`;
}

// Generate route-specific structured data
export function generateFlightRouteSchema(from: string, to: string, fromCity: string, toCity: string) {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": `Flights from ${fromCity} to ${toCity}`,
    "description": `Find cheap flights from ${fromCity} (${from}) to ${toCity} (${to}). Compare prices and book with TravalSearch.`,
    "url": `https://travalsearch.com/flights-from-${from.toLowerCase()}-to-${to.toLowerCase()}`,
    "breadcrumb": {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://travalsearch.com"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Flights",
          "item": "https://travalsearch.com/flights"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": `${fromCity} to ${toCity}`,
          "item": `https://travalsearch.com/flights-from-${from.toLowerCase()}-to-${to.toLowerCase()}`
        }
      ]
    },
    "mainEntity": {
      "@type": "Trip",
      "name": `Flight from ${fromCity} to ${toCity}`,
      "description": `Direct and connecting flights from ${fromCity} (${from}) to ${toCity} (${to})`,
      "tripOrigin": {
        "@type": "Airport",
        "name": `${fromCity} Airport`,
        "iataCode": from,
        "address": {
          "@type": "PostalAddress",
          "addressLocality": fromCity
        }
      },
      "tripDestination": {
        "@type": "Airport",
        "name": `${toCity} Airport`,
        "iataCode": to,
        "address": {
          "@type": "PostalAddress",
          "addressLocality": toCity
        }
      }
    },
    "provider": {
      "@type": "Organization",
      "name": "TravalSearch",
      "url": "https://travalsearch.com",
      "logo": "https://travalsearch.com/logo.png"
    }
  };
}