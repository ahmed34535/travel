/**
 * Real Hotel User Experience Test
 * Tests exactly how a customer would use the hotel search functionality
 */

const puppeteer = require('puppeteer');

async function testHotelUserExperience() {
  console.log("Testing hotel search like a real customer...\n");

  const browser = await puppeteer.launch({ 
    headless: false,
    slowMo: 100,
    args: ['--no-sandbox']
  });
  
  const page = await browser.newPage();
  
  try {
    // Navigate to hotels page
    console.log("1. Going to hotels page...");
    await page.goto('http://localhost:5000/hotels', { waitUntil: 'networkidle0' });
    
    // Test city autocomplete functionality
    const testCities = [
      { input: 'New', expected: ['New York', 'Manhattan'] },
      { input: 'Mia', expected: ['Miami', 'Miami Beach'] },
      { input: 'Los', expected: ['Los Angeles', 'Hollywood'] },
      { input: 'Chi', expected: ['Chicago', 'Downtown Chicago'] },
      { input: 'San', expected: ['San Francisco', 'Santa Monica'] },
      { input: 'Las', expected: ['Las Vegas', 'The Strip'] }
    ];

    for (const testCase of testCities) {
      console.log(`\n2. Testing autocomplete for "${testCase.input}"...`);
      
      // Clear the input field
      await page.click('#location');
      await page.keyboard.selectAll();
      await page.keyboard.press('Backspace');
      
      // Type the test input
      await page.type('#location', testCase.input);
      await page.waitForTimeout(500);
      
      // Check if suggestions appear
      const suggestions = await page.$$('.absolute.top-full div[class*="hover:bg-blue-50"]');
      console.log(`   Suggestions found: ${suggestions.length}`);
      
      if (suggestions.length > 0) {
        // Get suggestion text
        const suggestionTexts = await Promise.all(
          suggestions.map(async (suggestion) => {
            return await suggestion.$eval('div', el => el.textContent.trim());
          })
        );
        
        console.log(`   Suggestions: ${suggestionTexts.join(', ')}`);
        
        // Click on first suggestion
        console.log(`   Selecting: ${suggestionTexts[0]}`);
        await suggestions[0].click();
        await page.waitForTimeout(300);
        
        // Verify selection worked
        const selectedValue = await page.$eval('#location', el => el.value);
        console.log(`   Selected value: ${selectedValue}`);
      } else {
        console.log(`   ❌ No suggestions appeared for "${testCase.input}"`);
      }
    }

    // Test different room configurations
    console.log("\n3. Testing room configurations...");
    
    const roomTests = [
      { guests: 1, description: "Solo traveler" },
      { guests: 2, description: "Couple" },
      { guests: 4, description: "Family of 4" },
      { guests: 6, description: "Large group" }
    ];

    for (const roomTest of roomTests) {
      console.log(`\n   Testing ${roomTest.description} (${roomTest.guests} guests)...`);
      
      // Set guest count
      const guestInput = await page.$('#guests');
      if (guestInput) {
        await guestInput.click();
        await page.keyboard.selectAll();
        await page.type('#guests', roomTest.guests.toString());
        console.log(`   ✓ Set guests to ${roomTest.guests}`);
      }
    }

    // Test date selection
    console.log("\n4. Testing date selection...");
    
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const checkInDate = tomorrow.toISOString().split('T')[0];
    
    const dayAfter = new Date();
    dayAfter.setDate(dayAfter.getDate() + 3);
    const checkOutDate = dayAfter.toISOString().split('T')[0];
    
    console.log(`   Setting check-in: ${checkInDate}`);
    await page.type('#checkin', checkInDate);
    
    console.log(`   Setting check-out: ${checkOutDate}`);
    await page.type('#checkout', checkOutDate);

    // Test complete search flow
    console.log("\n5. Testing complete search flow...");
    
    // Set destination
    await page.click('#location');
    await page.keyboard.selectAll();
    await page.type('#location', 'Miami');
    await page.waitForTimeout(500);
    
    // Click search button
    const searchButton = await page.$('button:has-text("Search Hotels")');
    if (searchButton) {
      console.log("   Clicking search button...");
      await searchButton.click();
      await page.waitForTimeout(2000);
      
      // Check for search results
      const hotelCards = await page.$$('.hover\\:shadow-lg');
      console.log(`   Hotel results found: ${hotelCards.length}`);
      
      if (hotelCards.length > 0) {
        console.log("   ✓ Search returned hotel results");
        
        // Check first hotel details
        const firstHotel = hotelCards[0];
        const hotelName = await firstHotel.$eval('h3', el => el.textContent);
        const hotelPrice = await firstHotel.$eval('[class*="text-2xl"]', el => el.textContent).catch(() => 'Price not found');
        
        console.log(`   First hotel: ${hotelName}`);
        console.log(`   Price: ${hotelPrice}`);
      } else {
        console.log("   ❌ No hotel results displayed");
      }
    } else {
      console.log("   ❌ Search button not found");
    }

    console.log("\n=== HOTEL SEARCH TEST RESULTS ===");
    console.log("Autocomplete functionality: TESTED");
    console.log("Room configurations: TESTED");
    console.log("Date selection: TESTED");
    console.log("Complete search flow: TESTED");
    
  } catch (error) {
    console.log(`Test error: ${error.message}`);
  } finally {
    await browser.close();
  }
}

// Run if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  testHotelUserExperience().catch(console.error);
}

export { testHotelUserExperience };