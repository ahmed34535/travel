#!/bin/bash
# Single command to recreate TravalSearch

echo "🚀 Recreating TravalSearch platform..."

# Setup project
mkdir -p travalsearch && cd travalsearch

# Copy configuration
cp ../package-deployment.json package.json
cp ../setup.sh .
cp ../README-deployment.md README.md
cp ../Dockerfile .
cp ../docker-compose.yml .

# Make setup executable
chmod +x setup.sh

# Run setup
./setup.sh

echo "✅ TravalSearch recreation complete!"
echo "Update .env with your credentials and run: npm run dev"
