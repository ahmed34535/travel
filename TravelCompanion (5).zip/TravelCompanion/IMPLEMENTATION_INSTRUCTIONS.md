# Implementation Instructions for AI Assistant

## Flight Search Engine Setup

### Step 1: Fix Frontend-Backend Field Mapping
In `client/src/pages/flight-results.tsx`, ensure search parameters match exactly:

```typescript
const searchParams = {
  origin: searchParams.get('from'),
  destination: searchParams.get('to'), 
  departureDate: searchParams.get('departure'), // NOT departure_date
  cabinClass: searchParams.get('class'),
  passengers: {
    adults: parseInt(searchParams.get('adults') || '1'),
    children: parseInt(searchParams.get('children') || '0'),
    infants: parseInt(searchParams.get('infants') || '0')
  }
};
```

### Step 2: Fix API Endpoint Route
In `server/routes.ts`, use correct endpoint:
```typescript
app.post('/api/flights/search', async (req, res) => { // NOT /api/flight-search
```

### Step 3: Fix React Component Rendering Bug
In flight results component, replace broken conditional:
```typescript
// BROKEN - causes no results to display:
if (isLoading || !searchResult || !searchResult.data) {
  return <LoadingState />;
}

// FIXED - properly handles states:
if (isLoading) {
  return <LoadingState />;
}

if (!searchResult?.data?.length) {
  return <NoResultsState />;
}
```

### Step 4: Add Missing Handler Functions
In `client/src/pages/flight-results.tsx`, add after handleBookFlight:

```typescript
const handleHoldFlight = async (offer: any) => {
  if (!user) {
    const holdData = {
      type: 'hold',
      offerId: offer.id,
      price: offer.total_amount,
      currency: offer.total_currency,
      returnUrl: `/hold-confirmation?offer_id=${offer.id}`
    };
    localStorage.setItem('pendingHoldOrder', JSON.stringify(holdData));
    setLocation('/login?message=signup-to-hold');
    return;
  }

  try {
    const holdOrder = await apiRequest('POST', '/api/hold-orders', {
      offer_id: offer.id,
      passengers: [{
        given_name: user.firstName,
        family_name: user.lastName,
        title: 'mr',
        born_on: '1990-01-01',
        email: user.email
      }],
      payment_method: 'hold'
    });

    localStorage.setItem('holdOrder', JSON.stringify(holdOrder));
    setLocation(`/hold-confirmation?hold_id=${holdOrder.data.id}`);
  } catch (error) {
    console.error('Failed to create hold order:', error);
    alert('Failed to create hold order. Please try again.');
  }
};

const handleViewPolicies = (offer: any) => {
  localStorage.setItem('selectedOfferForPolicies', JSON.stringify(offer));
  setLocation(`/policies?offer_id=${offer.id}`);
};
```

### Step 5: Add Backend Hold Orders API
In `server/routes.ts`, add after existing routes:

```typescript
app.post('/api/hold-orders', async (req, res) => {
  try {
    const { offer_id, passengers, payment_method } = req.body;
    
    const holdOrder = {
      id: `ord_${Date.now()}`,
      type: 'hold',
      live_mode: false,
      booking_reference: generateBookingReference(),
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      payment_required_by: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      base_amount: '248.50',
      total_amount: '318.20',
      total_currency: 'USD',
      available_actions: ['pay', 'cancel'],
      passengers: passengers || [],
      // Add full flight details structure here
    };

    res.json({ data: holdOrder });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create hold order' });
  }
});

function generateBookingReference(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
```

## Hotel Search Engine Setup

### Step 1: Verify Database Schema
Ensure hotels table exists in `shared/schema.ts`:
```typescript
export const hotels = pgTable('hotels', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  location: varchar('location', { length: 255 }).notNull(),
  description: text('description'),
  rating: varchar('rating', { length: 10 }).notNull(),
  pricePerNight: varchar('price_per_night', { length: 20 }).notNull(),
  amenities: text('amenities').array().notNull(),
  imageUrl: varchar('image_url', { length: 500 }),
  featured: boolean('featured').default(false)
});
```

### Step 2: Add Hotel Search API Route
In `server/routes.ts`:
```typescript
app.post('/api/hotels/search', async (req, res) => {
  try {
    const { location, priceRange, amenities, rating, guests } = req.body;
    
    const hotels = await storage.searchHotels({
      location,
      priceRange,
      amenities,
      rating,
      guests
    });
    
    res.json({ data: hotels });
  } catch (error) {
    res.status(500).json({ error: 'Hotel search failed' });
  }
});
```

### Step 3: Implement Hotel Search in Storage
In `server/storage.ts`, add to IStorage interface and MemStorage class:
```typescript
// Add to interface
async searchHotels(params: {
  location?: string;
  priceRange?: [number, number];
  amenities?: string[];
  rating?: number;
  guests?: number;
}): Promise<any[]>;

// Add to class implementation
async searchHotels(params: any) {
  let results = this.hotels;
  
  if (params.location) {
    results = results.filter(hotel => 
      hotel.location.toLowerCase().includes(params.location.toLowerCase())
    );
  }
  
  if (params.priceRange) {
    results = results.filter(hotel => {
      const price = parseInt(hotel.pricePerNight.replace('$', ''));
      return price >= params.priceRange[0] && price <= params.priceRange[1];
    });
  }
  
  if (params.amenities?.length) {
    results = results.filter(hotel =>
      params.amenities.some(amenity => hotel.amenities.includes(amenity))
    );
  }
  
  return results;
}
```

### Step 4: Fix Frontend Hotel Search Component
In `client/src/pages/hotels.tsx`, ensure proper query implementation:
```typescript
const { data: hotels, isLoading, error } = useQuery({
  queryKey: ['/api/hotels/search', searchFilters],
  queryFn: () => apiRequest('POST', '/api/hotels/search', searchFilters),
  enabled: !!searchFilters.location
});
```

## Critical Testing Steps

### Test Flight Search:
1. Go to homepage
2. Enter: Los Angeles → New York, tomorrow's date
3. Click search
4. Verify flight results display with airline logos

### Test Hotel Search:
1. Go to /hotels page  
2. Enter location: "New York"
3. Set price range and amenities
4. Click search
5. Verify hotel cards display with pricing

## Common Issues and Fixes

### Issue: "No flights found" despite API working
**Fix:** Check conditional rendering in flight-results component

### Issue: Hotels not filtering properly  
**Fix:** Verify searchHotels implementation in storage.ts

### Issue: API endpoints not found
**Fix:** Ensure exact endpoint names match frontend calls

### Issue: Hold orders failing
**Fix:** Add missing backend API routes and handlers

## Required Environment
- PostgreSQL database with seeded data
- Node.js with all npm dependencies installed  
- Duffel API token (optional, will fallback to database)

Follow these steps exactly and the search engines will work.