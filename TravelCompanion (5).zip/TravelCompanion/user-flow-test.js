/**
 * Real User Flow Test - Tests exactly how a human would use the website
 * This simulates clicking through the actual website interface
 */

async function testRealUserFlow() {
  console.log("Testing real user experience through the website...");
  
  try {
    // Step 1: Test homepage access
    console.log("1. Accessing homepage...");
    const homeResponse = await fetch('http://localhost:5000/');
    
    if (!homeResponse.ok) {
      console.log(`Homepage failed: ${homeResponse.status}`);
      return;
    }
    
    const homeHtml = await homeResponse.text();
    const hasSearchForm = homeHtml.includes('input') && homeHtml.includes('button');
    console.log(`Homepage loads: ${homeResponse.status}, has search form: ${hasSearchForm}`);
    
    // Step 2: Test direct flight results URL (simulating form submission)
    console.log("\n2. Testing flight search results (simulating user search)...");
    
    const resultsUrl = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
    const resultsResponse = await fetch(resultsUrl);
    
    if (!resultsResponse.ok) {
      console.log(`Results page failed: ${resultsResponse.status}`);
      return;
    }
    
    const resultsHtml = await resultsResponse.text();
    
    // Analyze what the user would see
    const userExperience = {
      pageLoads: resultsResponse.status === 200,
      hasReactApp: resultsHtml.includes('id="root"'),
      hasViteClient: resultsHtml.includes('/@vite/client'),
      pageSize: resultsHtml.length,
      hasFlightResults: resultsHtml.includes('Flight Results'),
      hasNoFlights: resultsHtml.includes('No flights found'),
      hasBookButton: resultsHtml.includes('Book Flight'),
      hasPrice: resultsHtml.includes('$') || resultsHtml.includes('USD'),
      hasAirlineName: resultsHtml.includes('Airlines'),
      hasSearching: resultsHtml.includes('Searching flights'),
      hasError: resultsHtml.includes('Search failed'),
    };
    
    console.log("User sees on results page:", userExperience);
    
    // Step 3: Test the API that the browser JavaScript calls
    console.log("\n3. Testing browser API call (what React Query does)...");
    
    const apiResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    const apiWorking = apiResponse.ok;
    let flightCount = 0;
    let samplePrice = 'N/A';
    let sampleAirline = 'N/A';
    
    if (apiWorking) {
      const apiData = await apiResponse.json();
      flightCount = apiData.data?.length || 0;
      if (apiData.data && apiData.data.length > 0) {
        samplePrice = `${apiData.data[0].total_currency} ${apiData.data[0].total_amount}`;
        sampleAirline = apiData.data[0].owner?.name || 'Unknown';
      }
    }
    
    console.log(`API call result: ${apiWorking ? 'Success' : 'Failed'}`);
    console.log(`Flights available: ${flightCount}`);
    console.log(`Sample offer: ${sampleAirline} - ${samplePrice}`);
    
    // Step 4: Determine what the real user experience would be
    console.log("\n4. Real user experience analysis:");
    
    if (userExperience.pageLoads && userExperience.hasReactApp) {
      console.log("✅ Website loads properly for user");
    } else {
      console.log("❌ Website loading issues");
    }
    
    if (apiWorking && flightCount > 0) {
      console.log("✅ Live flight data available");
    } else {
      console.log("❌ No flight data available");
    }
    
    // Final determination
    if (userExperience.hasBookButton || userExperience.hasPrice) {
      console.log("🎉 SUCCESS: User would see flight results and can book!");
    } else if (userExperience.hasNoFlights) {
      console.log("⚠️ ISSUE: User sees 'No flights found' despite API working");
    } else if (userExperience.hasSearching) {
      console.log("⏳ User sees loading state - may need to wait longer");
    } else if (userExperience.hasError) {
      console.log("❌ User sees error state");
    } else {
      console.log("❓ Unclear user experience - need to investigate React rendering");
    }
    
    return {
      websiteWorks: userExperience.pageLoads && userExperience.hasReactApp,
      apiWorks: apiWorking,
      flightsAvailable: flightCount > 0,
      userWouldSeeResults: userExperience.hasBookButton || userExperience.hasPrice
    };
    
  } catch (error) {
    console.error("Real user test failed:", error.message);
  }
}

async function testFrontendAPI() {
  console.log("\n=== Testing Frontend API Integration ===");
  
  // Test what happens when the React component makes API calls
  try {
    const response = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'MIA',
        destination: 'LAX',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log(`MIA→LAX: ${data.data?.length || 0} flights available`);
      
      if (data.data && data.data.length > 0) {
        const firstFlight = data.data[0];
        console.log(`Sample: ${firstFlight.owner?.name} - ${firstFlight.total_currency} ${firstFlight.total_amount}`);
        console.log(`Route: ${firstFlight.slices?.[0]?.origin?.iata_code} → ${firstFlight.slices?.[0]?.destination?.iata_code}`);
      }
    } else {
      console.log(`API failed: ${response.status}`);
    }
  } catch (error) {
    console.log("API test error:", error.message);
  }
}

async function runAllTests() {
  const result = await testRealUserFlow();
  await testFrontendAPI();
  
  console.log("\n=== FINAL ASSESSMENT ===");
  if (result) {
    console.log(`Website functionality: ${result.websiteWorks ? 'Working' : 'Issues'}`);
    console.log(`API functionality: ${result.apiWorks ? 'Working' : 'Issues'}`);
    console.log(`Live flight data: ${result.flightsAvailable ? 'Available' : 'None'}`);
    console.log(`User experience: ${result.userWouldSeeResults ? 'Success' : 'Needs fixing'}`);
  }
}

runAllTests().catch(console.error);