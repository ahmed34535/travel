# TravalSearch Deployment Guide

## Complete Website Recreation Commands

### 1. Environment Setup
```bash
# Clone or create project directory
mkdir travalsearch
cd travalsearch

# Initialize Node.js project
npm init -y

# Install all dependencies
npm install @hookform/resolvers @jridgewell/trace-mapping @neondatabase/serverless @radix-ui/react-accordion @radix-ui/react-alert-dialog @radix-ui/react-aspect-ratio @radix-ui/react-avatar @radix-ui/react-checkbox @radix-ui/react-collapsible @radix-ui/react-context-menu @radix-ui/react-dialog @radix-ui/react-dropdown-menu @radix-ui/react-hover-card @radix-ui/react-label @radix-ui/react-menubar @radix-ui/react-navigation-menu @radix-ui/react-popover @radix-ui/react-progress @radix-ui/react-radio-group @radix-ui/react-scroll-area @radix-ui/react-select @radix-ui/react-separator @radix-ui/react-slider @radix-ui/react-slot @radix-ui/react-switch @radix-ui/react-tabs @radix-ui/react-toast @radix-ui/react-toggle @radix-ui/react-toggle-group @radix-ui/react-tooltip @replit/vite-plugin-cartographer @replit/vite-plugin-runtime-error-modal @sendgrid/mail @stripe/react-stripe-js @stripe/stripe-js @tailwindcss/typography @tailwindcss/vite @tanstack/react-query @types/connect-pg-simple @types/express @types/express-session @types/memoizee @types/node @types/passport @types/passport-local @types/react @types/react-dom @types/ws @vitejs/plugin-react autoprefixer class-variance-authority clsx cmdk connect-pg-simple date-fns drizzle-kit drizzle-orm drizzle-zod embla-carousel-react esbuild express express-session framer-motion input-otp lucide-react memoizee memorystore next-themes openid-client passport passport-local playwright postcss puppeteer react react-day-picker react-dom react-hook-form react-icons react-resizable-panels recharts stripe tailwind-merge tailwindcss tailwindcss-animate tsx tw-animate-css typescript vaul vite wouter ws zod zod-validation-error
```

### 2. Database Setup
```bash
# Setup PostgreSQL database (Neon or local)
# Get DATABASE_URL from Neon Dashboard or local PostgreSQL

# Push database schema
npm run db:push
```

### 3. Environment Variables
Create `.env` file:
```env
DATABASE_URL=postgresql://username:password@host/database
DUFFEL_API_TOKEN=duffel_live_your_token_here
NODE_ENV=production
```

### 4. Single Command Deployment
```bash
# Build and start the application
npm run build && npm start
```

## File Structure Required

```
travalsearch/
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── contexts/
│   │   ├── pages/
│   │   └── lib/
├── server/
│   ├── index.ts
│   ├── routes.ts
│   ├── storage.ts
│   └── vite.ts
├── shared/
│   └── schema.ts
├── api-integration/
│   ├── duffel/
│   ├── types/
│   └── config/
├── package.json
├── vite.config.ts
├── tailwind.config.ts
├── drizzle.config.ts
└── .env
```

## Essential Configuration Files

### package.json (Key Scripts)
```json
{
  "type": "module",
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build",
    "start": "NODE_ENV=production tsx server/index.ts",
    "db:push": "drizzle-kit push",
    "db:studio": "drizzle-kit studio"
  }
}
```

### vite.config.ts
```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './client/src'),
      '@shared': path.resolve(__dirname, './shared'),
      '@assets': path.resolve(__dirname, './attached_assets')
    }
  },
  build: {
    outDir: 'dist/public',
    emptyOutDir: true
  }
});
```

## API Integration Status

### Live APIs Active
- **Duffel Flight API**: Live integration with real flight data
- **Airport Search**: Global airport database
- **User Authentication**: Complete signup/login system

### APIs Ready for Activation
- **Hotel Booking APIs**: Booking.com, Hotels.com (needs API keys)
- **Payment Processing**: Stripe integration ready
- **Email Notifications**: SendGrid integration ready

## Key Features Implemented

1. **Flight Search**: Live Duffel API with authentic airline logos
2. **User Authentication**: Required signup before booking
3. **Responsive Design**: Mobile-first approach
4. **Database**: PostgreSQL with Drizzle ORM
5. **Real-time Data**: TanStack Query for caching

## Replication Commands

### Quick Setup (5 minutes)
```bash
# 1. Create project
mkdir travalsearch && cd travalsearch

# 2. Copy all files from this project
cp -r /path/to/existing/project/* .

# 3. Install dependencies
npm install

# 4. Setup environment
echo "DATABASE_URL=your_db_url" > .env
echo "DUFFEL_API_TOKEN=your_token" >> .env

# 5. Start application
npm run dev
```

### Production Deployment
```bash
# Build for production
npm run build

# Start production server
npm start

# Or use PM2 for process management
pm2 start "npm start" --name "travalsearch"
```

## Critical Files for Recreation

1. **server/index.ts** - Main server entry point
2. **server/routes.ts** - All API endpoints
3. **server/storage.ts** - Database operations
4. **shared/schema.ts** - Database schema
5. **client/src/App.tsx** - Frontend routing
6. **package.json** - Dependencies and scripts
7. **.env** - Environment configuration

## Dependencies Critical for Function

- **Frontend**: React 18, Vite, TailwindCSS, shadcn/ui
- **Backend**: Express.js, TypeScript, Drizzle ORM
- **Database**: PostgreSQL with Neon serverless
- **APIs**: Duffel flight integration
- **State**: TanStack Query, Wouter routing

## Single Command Recreation
```bash
# Complete recreation from scratch
git clone https://github.com/your-repo/travalsearch.git &&
cd travalsearch &&
npm install &&
echo "DATABASE_URL=your_url\nDUFFEL_API_TOKEN=your_token" > .env &&
npm run db:push &&
npm run dev
```

This documentation ensures the entire TravalSearch platform can be recreated with these commands and file structures.