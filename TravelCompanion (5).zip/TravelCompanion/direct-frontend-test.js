/**
 * Direct Frontend Test - Simple test to verify flight search works
 */

// Test the API endpoint directly first
async function testAPI() {
  console.log('Testing API endpoint...');
  
  try {
    const response = await fetch('http://localhost:5000/api/flights/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-20',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    const data = await response.json();
    console.log('API Status:', response.status);
    console.log('Offers returned:', data.data?.length || 0);
    
    if (data.data && data.data.length > 0) {
      const sample = data.data[0];
      console.log('Sample offer:');
      console.log('- ID:', sample.id);
      console.log('- Price:', sample.total_amount, sample.total_currency);
      console.log('- Route:', sample.slices?.[0]?.origin?.iata_code, '→', sample.slices?.[0]?.destination?.iata_code);
      return true;
    }
    return false;
    
  } catch (error) {
    console.log('API Error:', error.message);
    return false;
  }
}

// Test if homepage loads
async function testHomepage() {
  console.log('\nTesting homepage...');
  
  try {
    const response = await fetch('http://localhost:5000/');
    console.log('Homepage status:', response.status);
    
    const html = await response.text();
    const hasSearchForm = html.includes('flight') || html.includes('search') || html.includes('origin') || html.includes('destination');
    console.log('Contains search elements:', hasSearchForm);
    
    return response.ok;
    
  } catch (error) {
    console.log('Homepage Error:', error.message);
    return false;
  }
}

async function runTests() {
  console.log('Running direct frontend tests...\n');
  
  const apiWorks = await testAPI();
  const homepageWorks = await testHomepage();
  
  console.log('\n--- Test Results ---');
  console.log('API functioning:', apiWorks ? 'YES' : 'NO');
  console.log('Homepage loading:', homepageWorks ? 'YES' : 'NO');
  
  if (apiWorks && homepageWorks) {
    console.log('\nBoth backend and frontend are operational');
    console.log('Issue may be in the frontend JavaScript or React components');
  } else if (apiWorks && !homepageWorks) {
    console.log('\nAPI works but homepage has issues');
  } else if (!apiWorks && homepageWorks) {
    console.log('\nHomepage loads but API has problems');
  } else {
    console.log('\nBoth API and homepage have issues');
  }
}

runTests().catch(console.error);