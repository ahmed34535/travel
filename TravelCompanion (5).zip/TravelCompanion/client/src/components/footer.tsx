import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-blue-400 mb-4">TravalSearch</h3>
            <p className="text-gray-300 mb-4">Your trusted partner for unforgettable travel experiences worldwide.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-travel-blue transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-travel-blue transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-travel-blue transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-travel-blue transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><Link href="/flights" className="text-gray-300 hover:text-blue-400 transition-colors">Flight Booking</Link></li>
              <li><Link href="/hotels" className="text-gray-300 hover:text-blue-400 transition-colors">Hotel Reservations</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-blue-400 transition-colors">Vacation Packages</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-blue-400 transition-colors">Group Travel</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-blue-400 transition-colors">Travel Planning</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Help Center</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Contact Us</Link></li>
              <li><Link href="/profile?tab=bookings" className="text-gray-300 hover:text-travel-blue transition-colors">Manage Booking</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Cancellation Policy</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Travel Advisories</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-300 hover:text-travel-blue transition-colors">About Us</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Careers</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-travel-blue transition-colors">Press</Link></li>
              <li><Link href="/privacy" className="text-gray-300 hover:text-travel-blue transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-gray-300 hover:text-travel-blue transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-300">© 2024 TravalSearch. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
