import { Button } from "@/components/ui/button";
import { Plane } from "lucide-react";
import { useLocation } from "wouter";
import TravelSelector from "@/components/travel-selector";

export default function HeroSection() {
  return (
    <section className="relative">
      {/* Hero Background */}
      <div 
        className="h-screen bg-cover bg-center relative"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/60"></div>
        


        {/* Hero Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
          <div className="text-center space-y-6">
            <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
              Your Journey
              <span className="block text-blue-400">Starts Here</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto">
              Discover amazing destinations with our comprehensive travel platform. 
              Book flights, hotels, and vacation packages with confidence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">
                Start Planning
              </Button>
              <Button variant="outline" size="lg" className="text-white border-white hover:bg-white hover:text-black px-8 py-3 text-lg">
                View Deals
              </Button>
            </div>
          </div>
        </div>


      </div>
      
      {/* Search Interface */}
      <div className="absolute bottom-0 left-0 right-0 pb-28 z-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <TravelSelector />
        </div>
      </div>
    </section>
  );
}
