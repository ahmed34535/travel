import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plane, 
  Bed, 
  Car,
  ArrowRight
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import AirportSearch from "./airport-search";

function TravelSelector() {
  const [selectedTab, setSelectedTab] = useState("flights");
  const [, setLocation] = useLocation();
  
  // Flight search state
  const [flightForm, setFlightForm] = useState({
    origin: '',
    destination: '',
    departureDate: '',
    returnDate: '',
    adults: 1,
    children: 0,
    infants: 0,
    cabinClass: 'economy'
  });

  // Airport suggestions for common searches
  const getAirportSuggestion = (input: string): string => {
    const suggestions: Record<string, string> = {
      'minnesota': 'MSP',
      'minneapolis': 'MSP',
      'twin cities': 'MSP',
      'los angeles': 'LAX',
      'la': 'LAX',
      'new york': 'JFK',
      'nyc': 'JFK',
      'chicago': 'ORD',
      'miami': 'MIA',
      'boston': 'BOS',
      'seattle': 'SEA',
      'san francisco': 'SFO',
      'denver': 'DEN',
      'atlanta': 'ATL',
      'dallas': 'DFW',
      'phoenix': 'PHX',
      'las vegas': 'LAS',
      'orlando': 'MCO',
      'washington': 'DCA',
      'dc': 'DCA'
    };
    
    const normalized = input.toLowerCase().trim();
    return suggestions[normalized as keyof typeof suggestions] || input.toUpperCase();
  };

  const handleFlightSearch = () => {
    if (!flightForm.origin || !flightForm.destination || !flightForm.departureDate) {
      alert('Please fill in origin, destination, and departure date');
      return;
    }
    
    const params = new URLSearchParams({
      origin: flightForm.origin,
      destination: flightForm.destination,
      departureDate: flightForm.departureDate,
      adults: flightForm.adults.toString(),
      children: flightForm.children.toString(),
      infants: flightForm.infants.toString(),
      cabin_class: flightForm.cabinClass
    });
    
    if (flightForm.returnDate) {
      params.append('returnDate', flightForm.returnDate);
    }
    
    setLocation(`/flight-results?${params.toString()}`);
  };

  const handleSearch = (type: string) => {
    if (type === 'flights') {
      handleFlightSearch();
    } else {
      setLocation(`/${type}`);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
      <CardContent className="p-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="flights" className="flex items-center space-x-2">
              <Plane className="w-4 h-4" />
              <span>Flights</span>
            </TabsTrigger>
            <TabsTrigger value="hotels" className="flex items-center space-x-2">
              <Bed className="w-4 h-4" />
              <span>Hotels</span>
            </TabsTrigger>
            <TabsTrigger value="cars" className="flex items-center space-x-2">
              <Car className="w-4 h-4" />
              <span>Cars</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="flights" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <AirportSearch
                id="from"
                label="From"
                placeholder="Enter departure city or airport"
                value={flightForm.origin}
                onChange={(value) => setFlightForm({...flightForm, origin: value})}
              />
              <AirportSearch
                id="to"
                label="To"
                placeholder="Enter destination city or airport"
                value={flightForm.destination}
                onChange={(value) => setFlightForm({...flightForm, destination: value})}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="departure">Departure</Label>
                <Input 
                  id="departure" 
                  type="date" 
                  value={flightForm.departureDate}
                  onChange={(e) => setFlightForm({...flightForm, departureDate: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="return">Return (Optional)</Label>
                <Input 
                  id="return" 
                  type="date" 
                  value={flightForm.returnDate}
                  onChange={(e) => setFlightForm({...flightForm, returnDate: e.target.value})}
                />
              </div>
            </div>
            <Button 
              onClick={() => handleSearch('flights')} 
              className="w-full bg-blue-600 hover:bg-blue-700 h-12"
            >
              Search Flights
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </TabsContent>

          <TabsContent value="hotels" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <Input id="destination" placeholder="Where are you going?" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="checkin">Check-in</Label>
                <Input id="checkin" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="checkout">Check-out</Label>
                <Input id="checkout" type="date" />
              </div>
            </div>
            <Button 
              onClick={() => handleSearch('hotels')} 
              className="w-full bg-blue-600 hover:bg-blue-700 h-12"
            >
              Search Hotels
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <div className="mt-4 text-center">
              <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-lg border border-orange-200">
                <span className="text-sm font-medium">Hotel Booking - Coming Soon</span>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="cars" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pickup">Pick-up Location</Label>
              <Input id="pickup" placeholder="City or airport" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pickupdate">Pick-up Date</Label>
                <Input id="pickupdate" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dropoffdate">Drop-off Date</Label>
                <Input id="dropoffdate" type="date" />
              </div>
            </div>
            <Button 
              onClick={() => handleSearch('cars')} 
              className="w-full bg-blue-600 hover:bg-blue-700 h-12"
            >
              Search Cars
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <div className="mt-4 text-center">
              <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-lg border border-orange-200">
                <span className="text-sm font-medium">Car Rental - Coming Soon</span>
              </div>
            </div>
          </TabsContent>


        </Tabs>
      </CardContent>
    </Card>
  );
}

export default TravelSelector;