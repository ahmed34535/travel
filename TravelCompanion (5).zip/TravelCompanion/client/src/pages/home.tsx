import HeroSection from "@/components/hero-section";
import PopularDestinations from "@/components/popular-destinations";
import FeaturedHotels from "@/components/featured-hotels";
import FlightDeals from "@/components/flight-deals";
import CTASection from "@/components/cta-section";
import { SEOHead } from "@/components/SEOHead";

export default function Home() {
  const homeStructuredData = {
    "@context": "https://schema.org",
    "@type": "TravelAgency",
    "name": "TravalSearch",
    "description": "Find and book cheap flights, hotels, and vacation packages. Compare prices from major airlines and travel providers worldwide.",
    "url": "https://travalsearch.com",
    "logo": "https://travalsearch.com/logo.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-800-TRAVAL-1",
      "contactType": "customer service",
      "availableLanguage": "English"
    },
    "sameAs": [
      "https://facebook.com/travalsearch",
      "https://twitter.com/travalsearch",
      "https://instagram.com/travalsearch"
    ],
    "offers": {
      "@type": "AggregateOffer",
      "category": "Travel Services",
      "description": "Flight bookings, hotel reservations, and vacation packages"
    }
  };

  return (
    <div>
      <SEOHead
        title="TravalSearch - Book Cheap Flights, Hotels & Vacation Packages"
        description="Find and book the best deals on flights, hotels, and vacation packages. Compare prices from major airlines and travel providers. Best price guarantee and instant confirmation."
        canonical="https://travalsearch.com/"
        structuredData={homeStructuredData}
        ogImage="https://travalsearch.com/og-home.jpg"
      />
      <HeroSection />
      <FlightDeals />
      <FeaturedHotels />
      <PopularDestinations />
      <CTASection />
    </div>
  );
}
