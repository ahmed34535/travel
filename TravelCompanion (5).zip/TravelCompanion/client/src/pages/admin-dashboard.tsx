import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from "recharts";
import { 
  Users, Plane, Bed, Package, DollarSign, TrendingUp, 
  Calendar, MapPin, Plus, Edit, Trash2, Eye, Search
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock analytics data
const analyticsData = {
  totalRevenue: 125840.50,
  totalBookings: 342,
  totalUsers: 1247,
  avgBookingValue: 368.13,
  monthlyRevenue: [
    { month: "Jan", revenue: 12500 },
    { month: "Feb", revenue: 15200 },
    { month: "Mar", revenue: 18300 },
    { month: "Apr", revenue: 22100 },
    { month: "May", revenue: 25400 },
    { month: "Jun", revenue: 32300 }
  ],
  bookingsByType: [
    { name: "Flights", value: 45, color: "#3B82F6" },
    { name: "Hotels", value: 35, color: "#10B981" },
    { name: "Packages", value: 20, color: "#F59E0B" }
  ],
  recentBookings: [
    { id: "TH-FL-001234", type: "flight", customer: "Customer #1234", amount: 599, status: "confirmed", date: "2024-06-15" },
    { id: "TH-HT-002156", type: "hotel", customer: "Customer #2156", amount: 299, status: "confirmed", date: "2024-06-14" },
    { id: "TH-PK-003789", type: "package", customer: "Customer #3789", amount: 1799, status: "pending", date: "2024-06-14" },
    { id: "TH-FL-004321", type: "flight", customer: "Customer #4321", amount: 450, status: "confirmed", date: "2024-06-13" },
    { id: "TH-HT-005432", type: "hotel", customer: "Customer #5432", amount: 189, status: "cancelled", date: "2024-06-13" }
  ]
};

export default function AdminDashboard() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch data for admin tables with proper error handling
  const { data: destinationsResponse, isError: destinationsError } = useQuery({
    queryKey: ["/api/destinations"],
    queryFn: async () => {
      const response = await fetch("/api/destinations");
      const data = await response.json();
      return { data, status: response.status, ok: response.ok };
    },
    retry: false
  });

  const { data: hotelsResponse, isError: hotelsError } = useQuery({
    queryKey: ["/api/hotels"],
    queryFn: async () => {
      const response = await fetch("/api/hotels");
      const data = await response.json();
      return { data, status: response.status, ok: response.ok };
    },
    retry: false
  });

  const { data: flightsResponse, isError: flightsError } = useQuery({
    queryKey: ["/api/flights"],
    queryFn: async () => {
      const response = await fetch("/api/flights");
      const data = await response.json();
      return { data, status: response.status, ok: response.ok };
    },
    retry: false
  });

  const { data: packagesResponse, isError: packagesError } = useQuery({
    queryKey: ["/api/packages"],
    queryFn: async () => {
      const response = await fetch("/api/packages");
      const data = await response.json();
      return { data, status: response.status, ok: response.ok };
    },
    retry: false
  });

  // Extract actual data or provide empty arrays for error states
  const destinations = destinationsResponse?.ok && Array.isArray(destinationsResponse.data) 
    ? destinationsResponse.data 
    : [];
  const hotels = hotelsResponse?.ok && Array.isArray(hotelsResponse.data) 
    ? hotelsResponse.data 
    : [];
  const flights = flightsResponse?.ok && Array.isArray(flightsResponse.data) 
    ? flightsResponse.data 
    : [];
  const packages = packagesResponse?.ok && Array.isArray(packagesResponse.data) 
    ? packagesResponse.data 
    : [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed": return "bg-green-100 text-green-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "flight": return <Plane className="w-4 h-4" />;
      case "hotel": return <Bed className="w-4 h-4" />;
      case "package": return <Package className="w-4 h-4" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  const handleAction = (action: string, item?: any) => {
    toast({
      title: `${action} Action`,
      description: `${action} functionality would be implemented here.`,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Analytics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${analyticsData.totalRevenue.toLocaleString()}
                  </p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +12.3% from last month
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Bookings</p>
                  <p className="text-2xl font-bold text-gray-900">{analyticsData.totalBookings}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +8.7% from last month
                  </p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{analyticsData.totalUsers}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +15.2% from last month
                  </p>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Booking Value</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${analyticsData.avgBookingValue.toFixed(2)}
                  </p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +5.1% from last month
                  </p>
                </div>
                <div className="p-3 bg-orange-100 rounded-full">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analyticsData.monthlyRevenue}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                  <Bar dataKey="revenue" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Bookings by Type</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={analyticsData.bookingsByType}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {analyticsData.bookingsByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs defaultValue="bookings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="destinations">Destinations</TabsTrigger>
            <TabsTrigger value="hotels">Hotels</TabsTrigger>
            <TabsTrigger value="flights">Flights</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
          </TabsList>

          {/* Bookings Tab */}
          <TabsContent value="bookings">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Bookings</CardTitle>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Search bookings..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Button onClick={() => handleAction("Export")}>Export</Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Booking ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {analyticsData.recentBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            {getTypeIcon(booking.type)}
                            <span className="ml-2 capitalize">{booking.type}</span>
                          </div>
                        </TableCell>
                        <TableCell>{booking.customer}</TableCell>
                        <TableCell>${booking.amount}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(booking.status)}>
                            {booking.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(booking.date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button size="sm" variant="outline" onClick={() => handleAction("View", booking)}>
                              <Eye className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleAction("Edit", booking)}>
                              <Edit className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Destinations Tab */}
          <TabsContent value="destinations">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Manage Destinations</CardTitle>
                <Button onClick={() => handleAction("Add Destination")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Destination
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Country</TableHead>
                      <TableHead>Price From</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {destinations?.length > 0 ? (
                      destinations.map((destination: any) => (
                        <TableRow key={destination.id}>
                          <TableCell className="font-medium">{destination.name}</TableCell>
                          <TableCell>{destination.country}</TableCell>
                          <TableCell>${destination.priceFrom}</TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button size="sm" variant="outline" onClick={() => handleAction("Edit", destination)}>
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleAction("Delete", destination)}>
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8">
                          <div className="flex flex-col items-center space-y-3">
                            <MapPin className="w-12 h-12 text-gray-400" />
                            <div>
                              <p className="text-lg font-medium text-gray-900">No destinations available</p>
                              <p className="text-sm text-gray-500">Live destination data requires travel API integration</p>
                              {destinationsResponse?.status === 501 && (
                                <Badge variant="secondary" className="mt-2">
                                  API Integration Required
                                </Badge>
                              )}
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hotels Tab */}
          <TabsContent value="hotels">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Manage Hotels</CardTitle>
                <Button onClick={() => handleAction("Add Hotel")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Hotel
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead>Price/Night</TableHead>
                      <TableHead>Featured</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {hotels?.length > 0 ? (
                      hotels.map((hotel: any) => (
                        <TableRow key={hotel.id}>
                          <TableCell className="font-medium">{hotel.name}</TableCell>
                          <TableCell>{hotel.location}</TableCell>
                          <TableCell>{hotel.rating} ⭐</TableCell>
                          <TableCell>${hotel.pricePerNight}</TableCell>
                          <TableCell>
                            <Badge variant={hotel.featured ? "default" : "secondary"}>
                              {hotel.featured ? "Yes" : "No"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button size="sm" variant="outline" onClick={() => handleAction("Edit", hotel)}>
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleAction("Delete", hotel)}>
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <div className="flex flex-col items-center space-y-3">
                            <Bed className="w-12 h-12 text-gray-400" />
                            <div>
                              <p className="text-lg font-medium text-gray-900">No hotels available</p>
                              <p className="text-sm text-gray-500">Live hotel data requires hotel booking API integration</p>
                              {hotelsResponse?.status === 501 && (
                                <Badge variant="secondary" className="mt-2">
                                  API Integration Required
                                </Badge>
                              )}
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Flights Tab */}
          <TabsContent value="flights">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Manage Flights</CardTitle>
                <Button onClick={() => handleAction("Add Flight")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Flight
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Flight</TableHead>
                      <TableHead>Route</TableHead>
                      <TableHead>Departure</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {flights?.length > 0 ? (
                      flights.map((flight: any) => (
                        <TableRow key={flight.id}>
                          <TableCell className="font-medium">
                            {flight.airline} {flight.flightNumber}
                          </TableCell>
                          <TableCell>{flight.origin} → {flight.destination}</TableCell>
                          <TableCell>{flight.departureTime}</TableCell>
                          <TableCell>{flight.duration}</TableCell>
                          <TableCell>${flight.price}</TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button size="sm" variant="outline" onClick={() => handleAction("Edit", flight)}>
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleAction("Delete", flight)}>
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <div className="flex flex-col items-center space-y-3">
                            <Plane className="w-12 h-12 text-gray-400" />
                            <div>
                              <p className="text-lg font-medium text-gray-900">Flight data managed by Duffel API</p>
                              <p className="text-sm text-gray-500">Live flight offers are fetched dynamically from airlines</p>
                              <Badge variant="default" className="mt-2 bg-green-100 text-green-800">
                                Live API Active
                              </Badge>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Packages Tab */}
          <TabsContent value="packages">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Manage Packages</CardTitle>
                <Button onClick={() => handleAction("Add Package")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Package
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Original Price</TableHead>
                      <TableHead>Sale Price</TableHead>
                      <TableHead>Savings</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {packages?.length > 0 ? (
                      packages.map((pkg: any) => (
                        <TableRow key={pkg.id}>
                          <TableCell className="font-medium">{pkg.title}</TableCell>
                          <TableCell>{pkg.location}</TableCell>
                          <TableCell>{pkg.duration}</TableCell>
                          <TableCell>${pkg.originalPrice}</TableCell>
                          <TableCell>${pkg.price}</TableCell>
                          <TableCell className="text-green-600 font-semibold">${pkg.savings}</TableCell>
                          <TableCell>
                            <div className="flex space-x-1">
                              <Button size="sm" variant="outline" onClick={() => handleAction("Edit", pkg)}>
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleAction("Delete", pkg)}>
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          <div className="flex flex-col items-center space-y-3">
                            <Package className="w-12 h-12 text-gray-400" />
                            <div>
                              <p className="text-lg font-medium text-gray-900">No vacation packages available</p>
                              <p className="text-sm text-gray-500">Live package data requires travel package API integration</p>
                              {packagesResponse?.status === 501 && (
                                <Badge variant="secondary" className="mt-2">
                                  API Integration Required
                                </Badge>
                              )}
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}