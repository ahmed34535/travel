import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Users, 
  Globe, 
  Award, 
  Shield, 
  Plane, 
  MapPin,
  Clock,
  Star,
  TrendingUp,
  Heart,
  Target,
  CheckCircle
} from "lucide-react";

export default function About() {
  const stats = [
    { label: "Countries Served", value: "190+", icon: <Globe className="w-6 h-6 text-blue-600" /> },
    { label: "Happy Travelers", value: "2M+", icon: <Users className="w-6 h-6 text-green-600" /> },
    { label: "Partner Airlines", value: "1,200+", icon: <Plane className="w-6 h-6 text-purple-600" /> },
    { label: "Years of Experience", value: "15+", icon: <Award className="w-6 h-6 text-orange-600" /> }
  ];

  const values = [
    {
      title: "Customer First",
      description: "Every decision we make is guided by what's best for our travelers",
      icon: <Heart className="w-8 h-8 text-red-500" />
    },
    {
      title: "Trust & Security",
      description: "Your personal information and payments are protected with industry-leading security",
      icon: <Shield className="w-8 h-8 text-blue-500" />
    },
    {
      title: "Innovation",
      description: "We continuously improve our platform to make travel booking simpler and smarter",
      icon: <TrendingUp className="w-8 h-8 text-green-500" />
    },
    {
      title: "Global Reach",
      description: "Connecting travelers to destinations worldwide with local expertise",
      icon: <Globe className="w-8 h-8 text-purple-500" />
    }
  ];

  const milestones = [
    { year: "2009", event: "TravalSearch founded with a mission to simplify travel booking" },
    { year: "2012", event: "Launched mobile app and reached 100,000 users" },
    { year: "2015", event: "Expanded to international markets across Europe and Asia" },
    { year: "2018", event: "Introduced AI-powered travel recommendations" },
    { year: "2020", event: "Implemented flexible booking policies during global challenges" },
    { year: "2022", event: "Reached 1 million active users milestone" },
    { year: "2024", event: "Launched comprehensive loyalty program and corporate solutions" }
  ];

  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      description: "Former airline executive with 20+ years in travel industry",
      image: "👩‍💼"
    },
    {
      name: "Michael Chen",
      role: "CTO",
      description: "Technology leader specializing in scalable travel platforms",
      image: "👨‍💻"
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Customer Experience",
      description: "Passionate about creating exceptional travel experiences",
      image: "👩‍🎓"
    },
    {
      name: "David Kumar",
      role: "Head of Partnerships",
      description: "Expert in building strategic relationships with travel providers",
      image: "👨‍💼"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About TravalSearch
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're on a mission to make travel accessible, affordable, and effortless for everyone. 
            Since 2009, we've been connecting travelers with their dream destinations through innovative 
            technology and personalized service.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-center mb-3">
                  {stat.icon}
                </div>
                <h3 className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <Target className="w-6 h-6 text-blue-600" />
                <CardTitle>Our Mission</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                To democratize travel by providing a platform that makes booking flights, hotels, 
                and vacation packages simple, transparent, and affordable for travelers worldwide. 
                We believe everyone deserves to explore the world without the complexity of traditional 
                travel booking.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <Star className="w-6 h-6 text-yellow-500" />
                <CardTitle>Our Vision</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                To become the world's most trusted travel platform, where technology meets human 
                expertise to create seamless travel experiences. We envision a future where planning 
                and booking travel is as easy as a few clicks, backed by 24/7 support and 
                industry-leading security.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Core Values */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {value.icon}
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">{value.title}</h3>
                  <p className="text-gray-600 text-sm">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Company Timeline */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-center">Our Journey</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                      {milestone.year.slice(-2)}
                    </div>
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center space-x-3 mb-1">
                      <Badge variant="outline">{milestone.year}</Badge>
                    </div>
                    <p className="text-gray-700">{milestone.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Leadership Team */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Leadership Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="text-6xl mb-4">{member.image}</div>
                  <h3 className="font-semibold text-lg text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Why Choose Us */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-center">Why Choose TravalSearch?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Best Price Guarantee</h4>
                  <p className="text-gray-600 text-sm">Find a lower price elsewhere? We'll match it and give you an extra 5% off.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">24/7 Customer Support</h4>
                  <p className="text-gray-600 text-sm">Our travel experts are available around the clock to assist you.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Secure Booking</h4>
                  <p className="text-gray-600 text-sm">Your personal and payment information is protected with bank-level security.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Instant Confirmation</h4>
                  <p className="text-gray-600 text-sm">Get immediate booking confirmations and e-tickets delivered to your email.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Global Coverage</h4>
                  <p className="text-gray-600 text-sm">Access to flights, hotels, and packages in over 190 countries worldwide.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Flexible Options</h4>
                  <p className="text-gray-600 text-sm">Free cancellation and change options available on most bookings.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact CTA */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Start Your Journey?</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Join millions of travelers who trust TravalSearch for their adventures. 
              Start planning your next trip today and discover why we're the preferred choice for smart travelers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <div className="flex items-center space-x-2 text-blue-700">
                <MapPin className="w-5 h-5" />
                <span className="font-medium">190+ Countries</span>
              </div>
              <div className="flex items-center space-x-2 text-blue-700">
                <Clock className="w-5 h-5" />
                <span className="font-medium">24/7 Support</span>
              </div>
              <div className="flex items-center space-x-2 text-blue-700">
                <Shield className="w-5 h-5" />
                <span className="font-medium">Secure Booking</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}