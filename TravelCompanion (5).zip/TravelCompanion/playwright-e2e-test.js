/**
 * Comprehensive E2E Testing System
 * Simulates real user interactions with the flight search platform
 */

import { chromium } from 'playwright';

async function runFullE2ETest() {
  console.log('Starting comprehensive E2E testing...\n');
  
  let browser;
  
  try {
    // Launch browser
    browser = await chromium.launch({ 
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    });
    
    const page = await browser.newPage();
    
    // Capture console logs from the frontend
    page.on('console', msg => {
      const text = msg.text();
      if (text.includes('📦') || text.includes('✈️') || text.includes('🎯') || text.includes('📊')) {
        console.log('Frontend Log:', text);
      }
    });
    
    // Test 1: Navigate to homepage
    console.log('Test 1: Homepage Navigation');
    await page.goto('http://localhost:5000', { waitUntil: 'networkidle' });
    
    const title = await page.title();
    console.log(`Page title: ${title}`);
    
    // Test 2: Locate and interact with flight search form
    console.log('\nTest 2: Flight Search Form Interaction');
    
    // Wait for page to load completely
    await page.waitForTimeout(2000);
    
    // Try different strategies to find form inputs
    const inputSelectors = [
      'input[placeholder*="From"]',
      'input[placeholder*="Origin"]',
      'input[name="origin"]',
      '#origin',
      '.origin-input',
      'input[type="text"]'
    ];
    
    let originFound = false;
    for (const selector of inputSelectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          console.log(`Found origin input: ${selector}`);
          await page.fill(selector, 'NRT');
          await page.waitForTimeout(500);
          originFound = true;
          break;
        }
      } catch (e) {
        // Continue to next selector
      }
    }
    
    if (!originFound) {
      console.log('Attempting to find any text input for origin...');
      const allInputs = await page.$$('input[type="text"]');
      if (allInputs.length > 0) {
        await allInputs[0].fill('NRT');
        console.log('Filled first text input with NRT');
        originFound = true;
      }
    }
    
    // Find destination input
    let destFound = false;
    const destSelectors = [
      'input[placeholder*="To"]',
      'input[placeholder*="Destination"]', 
      'input[name="destination"]',
      '#destination',
      '.destination-input'
    ];
    
    for (const selector of destSelectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          console.log(`Found destination input: ${selector}`);
          await page.fill(selector, 'SYD');
          await page.waitForTimeout(500);
          destFound = true;
          break;
        }
      } catch (e) {
        // Continue to next selector
      }
    }
    
    if (!destFound) {
      const allInputs = await page.$$('input[type="text"]');
      if (allInputs.length > 1) {
        await allInputs[1].fill('SYD');
        console.log('Filled second text input with SYD');
        destFound = true;
      }
    }
    
    // Set departure date
    const dateSelectors = ['input[type="date"]', 'input[name="departureDate"]'];
    let dateSet = false;
    
    for (const selector of dateSelectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          await page.fill(selector, '2025-08-20');
          console.log('Set departure date');
          dateSet = true;
          break;
        }
      } catch (e) {
        // Continue
      }
    }
    
    // Test 3: Submit search form
    console.log('\nTest 3: Search Form Submission');
    
    // Find and click search button
    const searchSelectors = [
      'button[type="submit"]',
      'button:has-text("Search")',
      '.search-button',
      'button:has-text("Find")',
      'button[class*="search"]'
    ];
    
    let searchClicked = false;
    for (const selector of searchSelectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          console.log(`Clicking search button: ${selector}`);
          await element.click();
          searchClicked = true;
          break;
        }
      } catch (e) {
        // Continue
      }
    }
    
    if (!searchClicked) {
      // Try clicking any button with search-related text
      const buttons = await page.$$('button');
      for (const button of buttons) {
        const text = await button.textContent();
        if (text && (text.toLowerCase().includes('search') || text.toLowerCase().includes('find'))) {
          console.log(`Clicking button with text: ${text}`);
          await button.click();
          searchClicked = true;
          break;
        }
      }
    }
    
    if (searchClicked) {
      console.log('Search submitted successfully');
      
      // Test 4: Wait for and verify results
      console.log('\nTest 4: Results Verification');
      
      try {
        // Wait for navigation or results to appear
        await Promise.race([
          page.waitForNavigation({ timeout: 15000 }),
          page.waitForSelector('.flight-offer, .flight-result, [data-testid="flight-offer"]', { timeout: 15000 }),
          page.waitForFunction(() => {
            return document.querySelector('h1') && 
                   document.querySelector('h1').textContent.includes('Flight Results');
          }, { timeout: 15000 })
        ]);
        
        // Check current URL
        const currentUrl = page.url();
        console.log(`Current URL: ${currentUrl}`);
        
        // Look for results
        const resultSelectors = [
          '.flight-offer',
          '.flight-result', 
          '[data-testid="flight-offer"]',
          '.offer-card',
          '.flight-card'
        ];
        
        let resultsFound = 0;
        for (const selector of resultSelectors) {
          const elements = await page.$$(selector);
          if (elements.length > 0) {
            resultsFound = elements.length;
            console.log(`Found ${resultsFound} flight results using selector: ${selector}`);
            break;
          }
        }
        
        // Check for results page indicators
        const pageContent = await page.textContent('body');
        const hasFlightContent = pageContent.includes('flight') || pageContent.includes('Flight');
        const hasResultsHeader = pageContent.includes('Flight Results') || pageContent.includes('results');
        
        if (resultsFound > 0) {
          console.log(`SUCCESS: Found ${resultsFound} flight offers displayed`);
          
          // Test 5: Interact with first result
          console.log('\nTest 5: Result Interaction');
          
          const firstResult = await page.$(resultSelectors.find(s => page.$(s)));
          if (firstResult) {
            const resultText = await firstResult.textContent();
            console.log(`First result preview: ${resultText.substring(0, 150)}...`);
            
            // Look for book button
            const bookButtons = await page.$$('button:has-text("Book"), button:has-text("Select"), .book-button');
            if (bookButtons.length > 0) {
              console.log('Found booking buttons - interaction possible');
            }
          }
          
        } else if (hasResultsHeader) {
          console.log('SUCCESS: Reached flight results page');
          
          if (pageContent.includes('No flights found')) {
            console.log('INFO: No flights found message displayed');
          } else {
            console.log('INFO: Results page loaded but no offers visible');
          }
          
        } else if (hasFlightContent) {
          console.log('SUCCESS: Page contains flight-related content');
          
        } else {
          console.log('WARNING: Search completed but results unclear');
          console.log(`Page contains: ${pageContent.substring(0, 200)}...`);
        }
        
      } catch (waitError) {
        console.log('TIMEOUT: Waiting for results exceeded 15 seconds');
        
        const currentUrl = page.url();
        const currentTitle = await page.title();
        console.log(`Final URL: ${currentUrl}`);
        console.log(`Final title: ${currentTitle}`);
        
        // Check if we're still on a valid page
        if (currentUrl.includes('flight') || currentTitle.includes('flight')) {
          console.log('SUCCESS: Navigation to flight-related page detected');
        }
      }
      
    } else {
      console.log('ERROR: Could not find or click search button');
      
      // Debug: List all buttons
      const buttons = await page.$$('button');
      console.log(`Found ${buttons.length} buttons on page:`);
      for (let i = 0; i < Math.min(buttons.length, 5); i++) {
        const text = await buttons[i].textContent();
        console.log(`  Button ${i + 1}: "${text}"`);
      }
    }
    
    // Test 6: Performance and network analysis
    console.log('\nTest 6: Performance Analysis');
    
    const performanceMetrics = await page.evaluate(() => {
      const navigation = performance.getEntriesByType('navigation')[0];
      return {
        loadTime: navigation.loadEventEnd - navigation.loadEventStart,
        domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
        totalTime: navigation.loadEventEnd - navigation.fetchStart
      };
    });
    
    console.log('Performance metrics:', performanceMetrics);
    
  } catch (error) {
    console.error('E2E test failed:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// Additional API verification test
async function verifyAPIEndpoint() {
  console.log('\nAPI Verification Test');
  
  try {
    const response = await fetch('http://localhost:5000/api/flights/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'NRT',
        destination: 'SYD',
        departureDate: '2025-08-20',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log(`API Status: ${response.status} OK`);
      console.log(`Offers returned: ${data.data?.length || 0}`);
      
      if (data.data && data.data.length > 0) {
        const firstOffer = data.data[0];
        console.log(`Sample offer: ${firstOffer.slices[0].origin.iata_code} → ${firstOffer.slices[0].destination.iata_code}`);
        console.log(`Price: ${firstOffer.total_amount} ${firstOffer.total_currency}`);
      }
    } else {
      console.log(`API Error: ${response.status} ${response.statusText}`);
    }
  } catch (error) {
    console.error('API test failed:', error.message);
  }
}

// Run all tests
async function runAllTests() {
  console.log('='.repeat(60));
  console.log('COMPREHENSIVE E2E TEST SUITE');
  console.log('='.repeat(60));
  
  await runFullE2ETest();
  await verifyAPIEndpoint();
  
  console.log('\n' + '='.repeat(60));
  console.log('E2E TESTING COMPLETE');
  console.log('='.repeat(60));
}

runAllTests();