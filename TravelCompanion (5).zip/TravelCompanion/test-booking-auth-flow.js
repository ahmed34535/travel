/**
 * Test Booking Authentication Flow
 * Verify if customers must sign up before booking flights
 */

async function testBookingAuthFlow() {
  console.log("Testing booking authentication requirements...\n");

  const baseUrl = 'http://localhost:5000';
  
  console.log("1. Testing flight search without login...");
  try {
    // Search for flights without being logged in
    const searchResponse = await fetch(`${baseUrl}/api/flights/search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-01-15',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    console.log(`   Flight search status: ${searchResponse.status}`);
    
    if (searchResponse.ok) {
      const flights = await searchResponse.json();
      console.log(`   ✓ Flight search works without login`);
      console.log(`   ✓ Found ${flights.length} flights`);
      
      if (flights.length > 0) {
        const sampleFlight = flights[0];
        console.log(`   ✓ Sample flight: ${sampleFlight.airline} ${sampleFlight.price}`);
        
        // Try to book the first flight without login
        console.log("\n2. Testing flight booking without login...");
        
        const bookingData = {
          flightId: sampleFlight.id,
          passengers: [{
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.test@example.com',
            phone: '+1-555-123-4567'
          }],
          contactEmail: 'john.test@example.com',
          totalAmount: sampleFlight.price
        };
        
        const bookingResponse = await fetch(`${baseUrl}/api/bookings`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(bookingData)
        });
        
        console.log(`   Booking without login status: ${bookingResponse.status}`);
        
        if (bookingResponse.status === 401) {
          console.log(`   ✓ Booking requires authentication (as expected)`);
        } else if (bookingResponse.status === 200 || bookingResponse.status === 201) {
          console.log(`   ❌ Booking allowed without login (should require signup)`);
        } else {
          const errorText = await bookingResponse.text();
          console.log(`   ? Booking failed with: ${errorText}`);
        }
      }
    } else {
      console.log(`   ❌ Flight search failed: ${searchResponse.status}`);
    }
    
  } catch (error) {
    console.log(`   ❌ Error testing flight search: ${error.message}`);
  }

  console.log("\n3. Testing booking with authentication...");
  try {
    // First register a user
    const registerResponse = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        firstName: 'Test',
        lastName: 'Booker',
        email: 'test.booker@example.com',
        password: 'BookingTest123!'
      })
    });
    
    if (registerResponse.ok) {
      const registerResult = await registerResponse.json();
      const token = registerResult.token;
      console.log(`   ✓ User registered successfully`);
      
      // Try booking with authentication token
      const authBookingResponse = await fetch(`${baseUrl}/api/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          flightId: 1, // Use a test flight ID
          passengers: [{
            firstName: 'Test',
            lastName: 'Booker',
            email: 'test.booker@example.com',
            phone: '+1-555-123-4567'
          }],
          contactEmail: 'test.booker@example.com',
          totalAmount: '299.00'
        })
      });
      
      console.log(`   Authenticated booking status: ${authBookingResponse.status}`);
      
      if (authBookingResponse.ok) {
        const booking = await authBookingResponse.json();
        console.log(`   ✓ Booking successful with authentication`);
        console.log(`   ✓ Booking reference: ${booking.reference || 'Generated'}`);
      } else {
        const errorText = await authBookingResponse.text();
        console.log(`   ? Authenticated booking failed: ${errorText}`);
      }
    }
    
  } catch (error) {
    console.log(`   ❌ Error testing authenticated booking: ${error.message}`);
  }

  console.log("\n4. Testing frontend booking flow...");
  try {
    // Test the frontend booking pages
    const bookingPageResponse = await fetch(`${baseUrl}/booking`);
    console.log(`   Booking page accessible: ${bookingPageResponse.ok}`);
    
    const checkoutPageResponse = await fetch(`${baseUrl}/checkout`);
    console.log(`   Checkout page accessible: ${checkoutPageResponse.ok}`);
    
    // Check if these pages contain authentication checks
    if (bookingPageResponse.ok) {
      const bookingHtml = await bookingPageResponse.text();
      const hasAuthCheck = bookingHtml.includes('login') || 
                          bookingHtml.includes('auth') || 
                          bookingHtml.includes('sign');
      console.log(`   Booking page has auth references: ${hasAuthCheck}`);
    }
    
  } catch (error) {
    console.log(`   ❌ Error testing frontend pages: ${error.message}`);
  }

  console.log("\n5. Testing complete customer journey...");
  try {
    // Simulate complete customer journey
    console.log("   Step 1: Customer searches for flights (no login required)");
    console.log("   Step 2: Customer finds desired flight");
    console.log("   Step 3: Customer clicks 'Book Now'");
    console.log("   Step 4: System should redirect to login/signup");
    console.log("   Step 5: After authentication, proceed to booking");
    
    // Test if this flow is implemented
    const flightResultsResponse = await fetch(`${baseUrl}/flight-results`);
    if (flightResultsResponse.ok) {
      const html = await flightResultsResponse.text();
      const hasBookButton = html.includes('Book') || html.includes('book');
      console.log(`   ✓ Flight results page has booking buttons: ${hasBookButton}`);
    }
    
  } catch (error) {
    console.log(`   ❌ Error testing customer journey: ${error.message}`);
  }

  console.log("\n=== BOOKING AUTHENTICATION TEST RESULTS ===");
  console.log("Testing complete - analyzing results:");
  console.log("• Flight search accessibility without login");
  console.log("• Booking authentication requirements");
  console.log("• User registration and authenticated booking");
  console.log("• Frontend page access patterns");
  console.log("• Complete customer journey flow");
  
  console.log("\nRecommendations:");
  console.log("1. Flight search should be open (no login required)");
  console.log("2. Booking should require user authentication");
  console.log("3. Redirect users to signup/login when they try to book");
  console.log("4. Maintain booking details during auth process");
}

testBookingAuthFlow().catch(console.error);