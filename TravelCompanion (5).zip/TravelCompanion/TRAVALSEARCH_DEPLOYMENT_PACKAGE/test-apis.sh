#!/bin/bash
echo "🧪 Testing TravalSearch API endpoints..."

BASE_URL="http://localhost:5000"

# Test hotel data
echo "1. Testing hotel data..."
curl -s "$BASE_URL/api/hotels" | jq '.[:2]' || echo "Hotel API test failed"

# Test airport search
echo -e "\n2. Testing airport search..."
curl -s "$BASE_URL/api/airports?q=LAX" | jq '.data[:3]' || echo "Airport search test failed"

# Test flight search (requires server to be running)
echo -e "\n3. Testing flight search..."
curl -s -X POST "$BASE_URL/api/flight-search" \
  -H "Content-Type: application/json" \
  -d '{"origin":"LAX","destination":"JFK","departureDate":"2025-07-01","passengers":{"adults":1}}' \
  | jq '.[:2]' || echo "Flight search test failed (check DUFFEL_API_TOKEN)"

echo -e "\n✅ API testing complete"