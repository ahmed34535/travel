
# TravalSearch - Complete Deployment Package

## ONE-COMMAND SETUP
```bash
npm install && npm run db:push && npm run dev
```

## WHAT THIS INCLUDES
✓ Complete working platform with live Duffel API integration
✓ Hotel search with smart city autocomplete (20+ destinations)
✓ Flight search returning 50+ real flight offers
✓ Revenue-generating 2% markup pricing system
✓ Professional UI with responsive design
✓ Database with seeded travel data

## ENVIRONMENT SETUP
1. Create .env file:
```env
DATABASE_URL=postgresql://username:password@host:port/database
DUFFEL_API_TOKEN=duffel_test_your_token_here
NODE_ENV=development
```

2. Install dependencies:
```bash
npm install
```

3. Setup database:
```bash
npm run db:push
```

4. Start application:
```bash
npm run dev
```

## ACCESS POINTS
- Frontend: http://localhost:5000
- Flight Search: http://localhost:5000/flights
- Hotel Search: http://localhost:5000/hotels
- Admin Dashboard: Login with admin@travalsearch.com / admin123

## VERIFICATION TESTS
Test flight search:
```bash
curl -X POST http://localhost:5000/api/flight-search \
  -H "Content-Type: application/json" \
  -d '{"origin":"LAX","destination":"JFK","departureDate":"2025-07-01","passengers":{"adults":1}}'
```

Test hotel data:
```bash
curl http://localhost:5000/api/hotels
```

## TROUBLESHOOTING
- No flight results: Check DUFFEL_API_TOKEN
- Hotel interface not showing: Restart server
- Database errors: Verify DATABASE_URL

## FEATURES CONFIRMED WORKING
✓ Live flight search with Duffel API (50+ results)
✓ Hotel autocomplete with cities like "New York", "Miami"
✓ Airport search with global coverage
✓ Revenue-generating pricing formula
✓ Complete frontend-backend integration
