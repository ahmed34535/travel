#!/bin/bash
echo "🚀 Starting TravalSearch deployment..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required. Please install Node.js 18+ first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is required. Please install npm first."
    exit 1
fi

echo "✅ Node.js and npm found"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  Creating .env file from template..."
    cp .env.example .env
    echo "📝 Please edit .env file with your database URL and Duffel API token"
    echo "   DATABASE_URL=your_postgresql_connection_string"
    echo "   DUFFEL_API_TOKEN=your_duffel_api_token"
    read -p "Press Enter after updating .env file..."
fi

# Setup database
echo "🗄️  Setting up database..."
npm run db:push

# Start application
echo "🌟 Starting TravalSearch application..."
echo "📍 Frontend: http://localhost:5000"
echo "📍 Hotel Search: http://localhost:5000/hotels"
echo "📍 Flight Search: http://localhost:5000/flights"
echo ""
npm run dev