#!/bin/bash
# TravalSearch Complete Setup Script

echo "🚀 Setting up TravalSearch platform..."

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

# Create project structure
echo "📁 Creating directory structure..."
mkdir -p client/src/{components,pages,contexts,lib}
mkdir -p server
mkdir -p shared
mkdir -p api-integration/{duffel,types,config}

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Setup environment
echo "🔧 Setting up environment..."
if [ ! -f .env ]; then
    echo "DATABASE_URL=your_postgresql_database_url" > .env
    echo "DUFFEL_API_TOKEN=your_duffel_api_token" >> .env
    echo "NODE_ENV=development" >> .env
    echo "✅ Created .env file - please update with your credentials"
fi

# Database setup
echo "🗄️ Setting up database..."
npm run db:push

echo "✅ TravalSearch setup complete!"
echo ""
echo "Next steps:"
echo "1. Update .env with your database URL and Duffel API token"
echo "2. Run: npm run dev"
echo "3. Open: http://localhost:5000"
echo ""
echo "For production: npm run build && npm start"
