/**
 * Comprehensive Issue Detection Test
 */

async function runComprehensiveTest() {
  console.log("=== COMPREHENSIVE ISSUE DETECTION ===\n");

  // Test 1: Direct API call
  console.log("1. Testing API directly:");
  try {
    const response = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK', 
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });

    if (response.ok) {
      const data = await response.json();
      console.log(`   ✓ API working: ${data.data?.length || 0} flights`);
      console.log(`   ✓ Sample: ${data.data?.[0]?.owner?.name} $${data.data?.[0]?.total_amount}`);
    } else {
      console.log(`   ✗ API failed: ${response.status}`);
    }
  } catch (error) {
    console.log(`   ✗ API error: ${error.message}`);
  }

  // Test 2: Homepage content analysis
  console.log("\n2. Testing homepage:");
  try {
    const response = await fetch('http://localhost:5000/');
    const html = await response.text();
    
    console.log(`   Status: ${response.status}`);
    console.log(`   Has search form: ${html.includes('From') && html.includes('To')}`);
    console.log(`   Has input fields: ${html.includes('<input')}`);
    console.log(`   Has Search button: ${html.includes('Search Flights')}`);
  } catch (error) {
    console.log(`   Homepage error: ${error.message}`);
  }

  // Test 3: Flight results page analysis
  console.log("\n3. Testing flight results page:");
  try {
    const url = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
    const response = await fetch(url);
    const html = await response.text();
    
    console.log(`   Status: ${response.status}`);
    console.log(`   Page loads: ${response.ok}`);
    console.log(`   Has Flight Results header: ${html.includes('Flight Results')}`);
    console.log(`   Has Book Flight button: ${html.includes('Book Flight')}`);
    console.log(`   Has price display: ${html.includes('USD') || html.includes('$')}`);
    console.log(`   Has airline names: ${html.includes('Airlines') || html.includes('Frontier')}`);
    console.log(`   Shows no flights: ${html.includes('No flights found')}`);
    console.log(`   Shows searching: ${html.includes('Searching flights')}`);
    console.log(`   Shows error: ${html.includes('error') || html.includes('Error')}`);
    
    // Check if it's showing the React app or static content
    console.log(`   Has React root: ${html.includes('id="root"')}`);
    console.log(`   Has Vite client: ${html.includes('/@vite/client')}`);
    
  } catch (error) {
    console.log(`   Results page error: ${error.message}`);
  }

  // Test 4: Different route test
  console.log("\n4. Testing different search routes:");
  const routes = [
    { origin: 'MIA', destination: 'LAX', name: 'MIA-LAX' },
    { origin: 'SFO', destination: 'BOS', name: 'SFO-BOS' },
    { origin: 'ORD', destination: 'DEN', name: 'ORD-DEN' }
  ];

  for (const route of routes) {
    try {
      const response = await fetch('http://localhost:5000/api/flight-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: route.origin,
          destination: route.destination,
          departureDate: '2025-06-17',
          adults: 1,
          children: 0,
          infants: 0,
          cabin_class: 'economy'
        })
      });

      if (response.ok) {
        const data = await response.json();
        console.log(`   ${route.name}: ${data.data?.length || 0} flights available`);
      } else {
        console.log(`   ${route.name}: API error ${response.status}`);
      }
    } catch (error) {
      console.log(`   ${route.name}: Failed - ${error.message}`);
    }
  }

  // Test 5: Check routing behavior
  console.log("\n5. Testing routing:");
  const routeTests = [
    { path: '/', description: 'Homepage' },
    { path: '/flights', description: 'Flights page' },
    { path: '/flight-results', description: 'Flight results' },
    { path: '/hotels', description: 'Hotels page' },
    { path: '/packages', description: 'Packages page' }
  ];

  for (const test of routeTests) {
    try {
      const response = await fetch(`http://localhost:5000${test.path}`);
      console.log(`   ${test.description}: ${response.status} ${response.statusText}`);
    } catch (error) {
      console.log(`   ${test.description}: Failed - ${error.message}`);
    }
  }

  console.log("\n=== ISSUE SUMMARY ===");
  console.log("Based on the test results above:");
  console.log("- Check if API is returning data but frontend isn't displaying it");
  console.log("- Verify if search form is submitting to correct endpoint");
  console.log("- Confirm React component is rendering flight results properly");
  console.log("- Look for JavaScript errors in browser console");
}

runComprehensiveTest().catch(console.error);