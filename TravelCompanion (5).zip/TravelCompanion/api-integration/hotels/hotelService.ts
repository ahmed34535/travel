// Hotel Service with Live/Mock Toggle
// Ready for integration with booking.com or hotels.com API

import { isLiveMode, shouldUseMockData, apiConfig } from '../config/environment';
import type { Hotel } from '../../shared/schema';

export class HotelService {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = apiConfig.hotelApiKey || '';
    this.baseUrl = apiConfig.hotelBaseUrl;
  }

  async searchHotels(params: {
    location?: string;
    checkIn?: string;
    checkOut?: string;
    guests?: number;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Hotel[]> {
    if (isLiveMode() && this.apiKey) {
      try {
        return await this.searchHotelsFromAPI(params);
      } catch (error) {
        console.error('Live hotel search failed:', error);
        
        if (!shouldUseMockData()) {
          throw error;
        }
      }
    }

    return this.searchHotelsFromDatabase(params);
  }

  private async searchHotelsFromAPI(params: {
    location?: string;
    checkIn?: string;
    checkOut?: string;
    guests?: number;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Hotel[]> {
    const searchParams = new URLSearchParams({
      location: params.location || '',
      checkin_date: params.checkIn || '',
      checkout_date: params.checkOut || '',
      adults_number: (params.guests || 1).toString(),
    });

    if (params.minPrice) searchParams.set('price_filter_min', params.minPrice.toString());
    if (params.maxPrice) searchParams.set('price_filter_max', params.maxPrice.toString());

    const response = await fetch(`${this.baseUrl}/hotels/search?${searchParams}`, {
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Hotel API error: ${response.statusText}`);
    }

    const data = await response.json();
    return this.transformHotelData(data);
  }

  private transformHotelData(apiData: any): Hotel[] {
    // Transform external hotel API response to our schema
    if (!apiData.result) return [];

    return apiData.result.map((hotel: any) => ({
      id: parseInt(hotel.hotel_id) || Math.floor(Math.random() * 1000000),
      name: hotel.hotel_name || 'Unknown Hotel',
      location: hotel.address || 'Location not specified',
      description: hotel.review_nr ? `Rated by ${hotel.review_nr} guests` : 'No description available',
      imageUrl: hotel.main_photo_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80',
      rating: hotel.review_score ? (hotel.review_score / 2).toFixed(1) : '4.0',
      pricePerNight: hotel.min_total_price || '199',
      amenities: this.extractAmenities(hotel),
      featured: hotel.is_featured || false,
    }));
  }

  private extractAmenities(hotel: any): string[] {
    const amenities = [];
    if (hotel.has_free_wifi) amenities.push('Free WiFi');
    if (hotel.has_swimming_pool) amenities.push('Pool');
    if (hotel.has_fitness_center) amenities.push('Gym');
    if (hotel.has_restaurant) amenities.push('Restaurant');
    if (hotel.has_parking) amenities.push('Parking');
    return amenities.length ? amenities : ['Standard Amenities'];
  }

  private async searchHotelsFromDatabase(params: {
    location?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Hotel[]> {
    const { storage } = await import('../../server/storage');
    return storage.searchHotels(params.location, params.minPrice, params.maxPrice);
  }

  async validateConnection(): Promise<{ isLive: boolean; status: string }> {
    if (!isLiveMode() || !this.apiKey) {
      return {
        isLive: false,
        status: 'Using database fallback (no API key configured)'
      };
    }

    try {
      const response = await fetch(`${this.baseUrl}/hotels/search?limit=1`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      return {
        isLive: response.ok,
        status: response.ok ? 'Live hotel API connected' : 'API key validation failed'
      };
    } catch (error) {
      return {
        isLive: false,
        status: `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}