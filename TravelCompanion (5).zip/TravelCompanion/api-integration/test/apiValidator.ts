// API Validation and Test Endpoint
// Hidden endpoint to test live API connections when keys are provided

import { FlightService } from '../duffel/flightService';
import { HotelService } from '../hotels/hotelService';
import { PackageService } from '../packages/packageService';
import { isLiveMode } from '../config/environment';

export interface APIValidationResult {
  mode: 'live' | 'mock';
  services: {
    flights: { isLive: boolean; status: string };
    hotels: { isLive: boolean; status: string };
    packages: { isLive: boolean; status: string };
  };
  overall: {
    hasLiveServices: boolean;
    readyForProduction: boolean;
  };
}

export class APIValidator {
  private flightService: FlightService;
  private hotelService: HotelService;
  private packageService: PackageService;

  constructor() {
    this.flightService = new FlightService();
    this.hotelService = new HotelService();
    this.packageService = new PackageService();
  }

  async validateAllServices(): Promise<APIValidationResult> {
    const [flights, hotels, packages] = await Promise.all([
      this.flightService.validateConnection(),
      this.hotelService.validateConnection(),
      this.packageService.validateConnection(),
    ]);

    const hasLiveServices = flights.isLive || hotels.isLive || packages.isLive;
    const readyForProduction = flights.isLive && hotels.isLive;

    return {
      mode: isLiveMode() ? 'live' : 'mock',
      services: {
        flights,
        hotels,
        packages,
      },
      overall: {
        hasLiveServices,
        readyForProduction,
      },
    };
  }

  async testFlightSearch(): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      const results = await this.flightService.searchFlights({
        origin: 'JFK',
        destination: 'LAX',
        departureDate: '2024-07-01',
        passengers: 1,
      });

      return {
        success: true,
        data: {
          count: results.length,
          source: results.length > 0 && results[0].id > 1000000 ? 'live_api' : 'database',
          sample: results.slice(0, 2),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  async testHotelSearch(): Promise<{ success: boolean; data?: any; error?: string }> {
    try {
      const results = await this.hotelService.searchHotels({
        location: 'New York',
        checkIn: '2024-07-01',
        checkOut: '2024-07-03',
        guests: 2,
      });

      return {
        success: true,
        data: {
          count: results.length,
          source: results.length > 0 && results[0].id > 1000000 ? 'live_api' : 'database',
          sample: results.slice(0, 2),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}