// Duffel API Client
// This handles all direct communication with Duffel's flight API

import { apiConfig } from '../config/environment';
import type { 
  DuffelFlightSearchRequest, 
  DuffelFlightSearchResponse, 
  DuffelErrorResponse,
  DuffelSearchOptions,
  SEARCH_DEFAULTS
} from '../types/duffel';

export class DuffelClient {
  private apiKey: string;
  private baseUrl: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || apiConfig.duffelApiKey || '';
    this.baseUrl = apiConfig.duffelBaseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    if (!this.apiKey) {
      throw new Error('Duffel API key is required for live data');
    }

    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Duffel-Version': 'v1',
      ...options.headers,
    };

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const errorData: DuffelErrorResponse = await response.json();
      throw new Error(
        `Duffel API Error: ${errorData.errors[0]?.title || 'Unknown error'}`
      );
    }

    return response.json();
  }

  async searchFlights(
    searchParams: DuffelFlightSearchRequest
  ): Promise<DuffelFlightSearchResponse> {
    return this.request<DuffelFlightSearchResponse>('/offer_requests', {
      method: 'POST',
      body: JSON.stringify(searchParams),
    });
  }

  async getOffer(offerId: string) {
    return this.request(`/offers/${offerId}`, {
      method: 'GET',
    });
  }

  async createOrder(offerIds: string[], passengers: any[]) {
    return this.request('/orders', {
      method: 'POST',
      body: JSON.stringify({
        selected_offers: offerIds,
        passengers,
        type: 'instant',
      }),
    });
  }

  // Update offer passenger with loyalty programme accounts for discounted fares
  async updateOfferPassenger(
    offerId: string, 
    passengerID: string, 
    passengerData: {
      given_name: string;
      family_name: string;
      loyalty_programme_accounts?: Array<{
        airline_iata_code: string;
        account_number: string;
      }>;
    }
  ) {
    const response = await this.request<any>(
      `/air/offers/${offerId}/passengers/${passengerID}`,
      {
        method: 'PATCH',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: passengerData
        })
      }
    );
    return response;
  }

  // Find airports within a geographic area
  async findAirportsByLocation(
    latitude: number,
    longitude: number,
    radius: number = 100000 // Default 100km radius
  ) {
    const queryParams = new URLSearchParams({
      lat: latitude.toString(),
      lng: longitude.toString(),
      rad: radius.toString()
    });

    const response = await this.request<any>(
      `/places/suggestions?${queryParams.toString()}`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Create hold order for deferred payment
  async createHoldOrder(
    selectedOffers: string[],
    passengers: Array<{
      id: string;
      title: string;
      given_name: string;
      family_name: string;
      gender: 'm' | 'f';
      born_on: string;
      email: string;
      phone_number: string;
    }>
  ) {
    const response = await this.request<any>(
      '/air/orders',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: {
            type: 'hold',
            selected_offers: selectedOffers,
            passengers
          }
        })
      }
    );
    return response;
  }

  // Pay for a held order
  async payForOrder(
    orderId: string,
    amount: string,
    currency: string
  ) {
    const response = await this.request<any>(
      '/air/payments',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: {
            order_id: orderId,
            payment: {
              type: 'balance',
              amount,
              currency
            }
          }
        })
      }
    );
    return response;
  }

  // Get order details including payment status
  async getOrder(orderId: string) {
    const response = await this.request<any>(
      `/air/orders/${orderId}`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Get seat maps for an offer
  async getSeatMaps(offerId: string) {
    const queryParams = new URLSearchParams({
      offer_id: offerId
    });

    const response = await this.request<any>(
      `/air/seat_maps?${queryParams.toString()}`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Create cancellation quote for an order
  async createCancellationQuote(orderId: string) {
    const response = await this.request<any>(
      '/air/order_cancellations',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: {
            order_id: orderId
          }
        })
      }
    );
    return response;
  }

  // Confirm order cancellation
  async confirmCancellation(orderCancellationId: string) {
    const response = await this.request<any>(
      `/air/order_cancellations/${orderCancellationId}/actions/confirm`,
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Create order change request
  async createOrderChange(changeRequest: any) {
    const response = await this.request<any>(
      '/air/order_changes',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: changeRequest
        })
      }
    );
    return response;
  }

  // Confirm order change
  async confirmOrderChange(orderChangeId: string) {
    const response = await this.request<any>(
      `/air/order_changes/${orderChangeId}/actions/confirm`,
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Get available services for an order (post-booking)
  async getOrderAvailableServices(orderId: string) {
    const response = await this.request<any>(
      `/air/orders/${orderId}/available_services`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Book services for an order (post-booking)
  async bookOrderServices(orderId: string, serviceRequest: any) {
    const response = await this.request<any>(
      `/air/orders/${orderId}/services`,
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: serviceRequest
        })
      }
    );
    return response;
  }

  // Duffel Stays - Search for accommodation
  async searchStays(searchRequest: any) {
    const response = await this.request<any>(
      '/stays/search',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: searchRequest
        })
      }
    );
    return response;
  }

  // Duffel Stays - Get rates for a search result
  async getStaysRates(searchResultId: string) {
    const response = await this.request<any>(
      `/stays/search_results/${searchResultId}/rates`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Duffel Stays - Create quote
  async createStaysQuote(rateId: string) {
    const response = await this.request<any>(
      '/stays/quotes',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: {
            rate_id: rateId
          }
        })
      }
    );
    return response;
  }

  // Duffel Stays - Create booking
  async createStaysBooking(bookingRequest: any) {
    const response = await this.request<any>(
      '/stays/bookings',
      {
        method: 'POST',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Duffel-Version': 'v2'
        },
        body: JSON.stringify({
          data: bookingRequest
        })
      }
    );
    return response;
  }

  // Duffel Stays - Get booking
  async getStaysBooking(bookingId: string) {
    const response = await this.request<any>(
      `/stays/bookings/${bookingId}`,
      {
        method: 'GET',
        headers: {
          'Accept-Encoding': 'gzip',
          'Accept': 'application/json',
          'Duffel-Version': 'v2'
        }
      }
    );
    return response;
  }

  // Health check to validate API key
  async validateConnection(): Promise<boolean> {
    try {
      await this.request('/airlines?limit=1');
      return true;
    } catch (error) {
      console.error('Duffel API validation failed:', error);
      return false;
    }
  }
}