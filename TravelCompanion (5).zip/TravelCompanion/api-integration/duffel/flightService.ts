// Flight Service with Live/Mock Toggle
// This service layer handles switching between live Duffel API and fallback data

import { DuffelClient } from './client';
import { DataTransformer } from '../utils/dataTransform';
import { isLiveMode, shouldUseMockData } from '../config/environment';
import type { Flight } from '../../shared/schema';

export class FlightService {
  private duffelClient: DuffelClient;

  constructor() {
    this.duffelClient = new DuffelClient();
  }

  async searchFlights(params: {
    origin?: string;
    destination?: string;
    departureDate?: string;
    passengers?: number;
    cabinClass?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Flight[]> {
    // Attempt live API first if configured
    if (isLiveMode()) {
      try {
        const searchRequest = DataTransformer.toFlightSearchRequest(params);
        const response = await this.duffelClient.searchFlights(searchRequest);
        
        let flights = response.data.map(offer => 
          DataTransformer.duffelToFlight(offer)
        );

        // Apply price filtering if specified
        if (params.minPrice || params.maxPrice) {
          flights = flights.filter(flight => {
            const price = parseFloat(flight.price);
            if (params.minPrice && price < params.minPrice) return false;
            if (params.maxPrice && price > params.maxPrice) return false;
            return true;
          });
        }

        return flights;
      } catch (error) {
        console.error('Live flight search failed:', error);
        
        if (!shouldUseMockData()) {
          throw error;
        }
        
        // Fall through to database fallback
      }
    }

    // Fallback to database/mock data
    return this.searchFlightsFromDatabase(params);
  }

  async getFlightById(id: number): Promise<Flight | undefined> {
    // For live mode, we'd need to store offer mappings
    // For now, fallback to database
    return this.getFlightFromDatabase(id);
  }

  private async searchFlightsFromDatabase(params: {
    origin?: string;
    destination?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Flight[]> {
    // This would call the existing database storage
    // Import and use the storage instance here
    const { storage } = await import('../../server/storage');
    return storage.searchFlights(params.origin, params.destination, params.minPrice, params.maxPrice);
  }

  private async getFlightFromDatabase(id: number): Promise<Flight | undefined> {
    const { storage } = await import('../../server/storage');
    return storage.getFlight(id);
  }

  // Validate API connection without exposing internals
  async validateConnection(): Promise<{ isLive: boolean; status: string }> {
    if (!isLiveMode()) {
      return {
        isLive: false,
        status: 'Using database fallback (no API key configured)'
      };
    }

    try {
      const isValid = await this.duffelClient.validateConnection();
      return {
        isLive: isValid,
        status: isValid ? 'Live API connected' : 'API key validation failed'
      };
    } catch (error) {
      return {
        isLive: false,
        status: `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}