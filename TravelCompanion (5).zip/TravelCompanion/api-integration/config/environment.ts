// API Environment Configuration
// This will switch between mock/live data based on environment

export interface APIConfig {
  duffelApiKey?: string;
  duffelBaseUrl: string;
  hotelApiKey?: string;
  hotelBaseUrl: string;
  mode: 'mock' | 'live';
  fallbackToMock: boolean;
}

export const apiConfig: APIConfig = {
  duffelApiKey: process.env.DUFFEL_API_KEY,
  duffelBaseUrl: 'https://api.duffel.com/v1',
  hotelApiKey: process.env.HOTEL_API_KEY,
  hotelBaseUrl: 'https://api.hotels.com/v1',
  mode: process.env.DUFFEL_API_KEY ? 'live' : 'mock',
  fallbackToMock: true
};

export const isLiveMode = () => apiConfig.mode === 'live' && apiConfig.duffelApiKey;
export const shouldUseMockData = () => !isLiveMode() || apiConfig.fallbackToMock;