// Data transformation utilities
// Converts live API responses to match our existing schema format

import type { DuffelFlightOffer, DuffelSegment } from '../types/duffel';
import type { Flight } from '../../shared/schema';

export class DataTransformer {
  // Transform Duffel flight offer to our Flight schema
  static duffelToFlight(offer: DuffelFlightOffer): Flight {
    const mainSegment = offer.slices[0]?.segments[0];
    if (!mainSegment) {
      throw new Error('Invalid flight offer: missing segments');
    }

    return {
      id: parseInt(offer.id.replace(/\D/g, '').slice(-6)) || Math.floor(Math.random() * 1000000),
      airline: mainSegment.marketing_carrier.name,
      flightNumber: mainSegment.marketing_carrier_flight_number,
      origin: `${mainSegment.origin.name} (${mainSegment.origin.iata_code})`,
      destination: `${mainSegment.destination.name} (${mainSegment.destination.iata_code})`,
      departureTime: this.formatTime(mainSegment.departing_at),
      arrivalTime: this.formatTime(mainSegment.arriving_at),
      duration: this.formatDuration(offer.slices[0].duration),
      price: offer.total_amount,
      stops: this.calculateStops(offer.slices[0].segments),
      imageUrl: this.getAirlineImage(mainSegment.marketing_carrier.iata_code)
    };
  }

  // Format ISO datetime to readable time
  private static formatTime(isoString: string): string {
    const date = new Date(isoString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  // Format ISO 8601 duration to readable format
  private static formatDuration(isoDuration: string): string {
    // Parse PT2H30M format
    const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?/);
    if (!match) return isoDuration;

    const hours = parseInt(match[1] || '0');
    const minutes = parseInt(match[2] || '0');
    
    if (hours > 0 && minutes > 0) {
      return `${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h`;
    } else {
      return `${minutes}m`;
    }
  }

  // Calculate number of stops
  private static calculateStops(segments: DuffelSegment[]): number {
    return Math.max(0, segments.length - 1);
  }

  // Get airline logo/image URL
  private static getAirlineImage(iataCode: string): string {
    // Fallback to a generic airline image
    return `https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=800&q=80`;
  }

  // Transform search parameters from our format to Duffel format
  static toFlightSearchRequest(params: {
    origin?: string;
    destination?: string;
    departureDate?: string;
    passengers?: number;
    cabinClass?: string;
  }) {
    if (!params.origin || !params.destination) {
      throw new Error('Origin and destination are required for flight search');
    }

    return {
      cabin_class: (params.cabinClass as any) || 'economy',
      passengers: Array(params.passengers || 1).fill({ type: 'adult' }),
      slices: [{
        origin: this.extractIATACode(params.origin),
        destination: this.extractIATACode(params.destination),
        departure_date: params.departureDate || new Date().toISOString().split('T')[0]
      }]
    };
  }

  // Extract IATA code from location string
  private static extractIATACode(location: string): string {
    const match = location.match(/\(([A-Z]{3})\)/);
    return match ? match[1] : location.substring(0, 3).toUpperCase();
  }
}