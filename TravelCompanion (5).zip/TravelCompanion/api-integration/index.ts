// Live API Integration Entry Point
// This file exports all the services ready for integration

export { FlightService } from './duffel/flightService';
export { HotelService } from './hotels/hotelService';
export { PackageService } from './packages/packageService';
export { APIValidator } from './test/apiValidator';
export { apiConfig, isLiveMode, shouldUseMockData } from './config/environment';

// Integration interface for seamless switching
export interface LiveAPIServices {
  flights: FlightService;
  hotels: HotelService;
  packages: PackageService;
  validator: APIValidator;
}

export function createLiveAPIServices(): LiveAPIServices {
  return {
    flights: new FlightService(),
    hotels: new HotelService(),
    packages: new PackageService(),
    validator: new APIValidator(),
  };
}

// Quick status check
export async function getAPIStatus() {
  const validator = new APIValidator();
  return validator.validateAllServices();
}