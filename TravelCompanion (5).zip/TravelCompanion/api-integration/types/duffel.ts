// Enhanced Duffel API Types with Search Best Practices
// Based on official Duffel documentation for optimized search performance

export interface DuffelFlightSearchRequest {
  slices: Array<{
    origin: string;
    destination: string;
    departure_date: string;
    departure_time?: {
      from?: string; // Format: "HH:MM" (e.g., "08:00")
      to?: string;   // Format: "HH:MM" (e.g., "11:00")
    };
    arrival_time?: {
      from?: string; // Format: "HH:MM" (e.g., "09:45")
      to?: string;   // Format: "HH:MM" (e.g., "17:00")
    };
  }>;
  passengers: Array<{
    type: 'adult' | 'child' | 'infant_without_seat';
    age?: number;
    // Passenger identity for loyalty programmes (required when using loyalty accounts)
    given_name?: string;
    family_name?: string;
    // Leisure private fares support
    fare_type?: 'student' | 'senior' | 'youth' | 'contract_bulk_child' | 'contract_bulk_adult';
    // Loyalty programme accounts for benefits and discounts
    loyalty_programme_accounts?: Array<{
      airline_iata_code: string; // e.g., "QF" for Qantas, "BA" for British Airways
      account_number: string;    // Loyalty account number
    }>;
  }>;
  // Search optimization filters
  cabin_class?: 'first' | 'business' | 'premium_economy' | 'economy';
  max_connections?: number; // 0 = direct flights only, 1 = up to 1 stop, 2 = up to 2 stops
  // Corporate private fares and loyalty programmes support
  private_fares?: Record<string, Array<{
    corporate_code?: string;
    tracking_reference?: string;
    tour_code?: string; // For United Airlines PerksPlus
  }>>;
}

export interface DuffelSearchOptions {
  // Query parameter for controlling search timeout (milliseconds)
  supplier_timeout?: number; // Default: 20000ms, recommended range: 10000-30000ms
  return_offers?: boolean;   // Whether to return offers immediately
}

export interface DuffelFlightOffer {
  id: string;
  total_amount: string;
  total_currency: string;
  slices: Array<{
    id: string;
    origin: {
      iata_code: string;
      name: string;
    };
    destination: {
      iata_code: string;
      name: string;
    };
    departure_date: string;
    arrival_date: string;
    segments: Array<{
      id: string;
      origin: {
        iata_code: string;
        name: string;
      };
      destination: {
        iata_code: string;
        name: string;
      };
      departing_at: string;
      arriving_at: string;
      duration: string;
      marketing_carrier: {
        iata_code: string;
        name: string;
      };
      operating_carrier: {
        iata_code: string;
        name: string;
      };
      flight_number: string;
      aircraft: {
        name: string;
      };
      // Flight stops information for displaying intermediate stops
      stops?: Array<{
        id: string;
        duration: string; // Format: "PT02H26M" (ISO 8601 duration)
        departing_at: string;
        airport: {
          id: string;
          iata_code: string;
          iata_city_code: string;
          iata_country_code: string;
          icao_code: string;
          name: string;
          city_name: string;
          time_zone: string;
          latitude: number;
          longitude: number;
          city: {
            id: string;
            name: string;
            iata_code: string;
            iata_country_code: string;
          };
        };
      }>;
    }>;
  }>;
  // Private fares indication
  private_fares?: Array<{
    type: 'corporate' | 'leisure';
    corporate_code?: string;
    tracking_reference?: string;
  }>;
  passenger_identity_documents_required: boolean;
  conditions: {
    change_before_departure?: {
      allowed: boolean;
      penalty_amount?: string;
      penalty_currency?: string;
    };
    refund_before_departure?: {
      allowed: boolean;
      penalty_amount?: string;
      penalty_currency?: string;
    };
  };
  // Fare brand information for displaying offer types
  fare_brand?: {
    name: string; // e.g., "Basic", "Comfort", "Flexible"
    conditions: {
      change_before_departure?: {
        allowed: boolean;
        penalty_amount?: string;
        penalty_currency?: string;
      };
      refund_before_departure?: {
        allowed: boolean;
        penalty_amount?: string;
        penalty_currency?: string;
      };
    };
  };
}

export interface DuffelFlightSearchResponse {
  data: DuffelFlightOffer[];
  meta: {
    count: number;
  };
}

export interface DuffelOrderRequest {
  selected_offers: string[];
  payments: Array<{
    type: 'balance' | 'arc_bsp_cash';
    amount: string;
    currency: string;
  }>;
  passengers: Array<{
    id: string;
    title: string;
    given_name: string;
    family_name: string;
    gender: 'm' | 'f';
    born_on: string; // Format: "YYYY-MM-DD"
    email: string;
    phone_number: string;
    infant_passenger_id?: string;
  }>;
}

export interface DuffelOrder {
  id: string;
  booking_reference: string;
  total_amount: string;
  total_currency: string;
  created_at: string;
  passengers: Array<{
    id: string;
    given_name: string;
    family_name: string;
  }>;
  slices: Array<{
    id: string;
    segments: Array<{
      id: string;
      flight_number: string;
      departing_at: string;
      arriving_at: string;
    }>;
  }>;
}

export interface DuffelErrorResponse {
  errors: Array<{
    type: string;
    title: string;
    detail: string;
    code: string;
  }>;
}

// Search performance optimization constants
export const SEARCH_DEFAULTS = {
  MAX_CONNECTIONS: 1,        // Balance between options and speed
  SUPPLIER_TIMEOUT: 20000,   // 20 seconds default timeout
  CABIN_CLASS: 'economy',    // Most common search
  RETURN_OFFERS: true,       // Get offers immediately
} as const;

// Supported fare types for leisure private fares
export const LEISURE_FARE_TYPES = [
  'student',
  'senior', 
  'youth',
  'contract_bulk_child',
  'contract_bulk_adult'
] as const;

export type LeisureFareType = typeof LEISURE_FARE_TYPES[number];

// Airport location search types
export interface DuffelAirportSuggestion {
  id: string;
  type: 'airport';
  iata_code: string;
  iata_city_code: string;
  iata_country_code: string;
  icao_code: string;
  name: string;
  city_name: string;
  time_zone: string;
  latitude: number;
  longitude: number;
}

export interface DuffelPlaceSuggestionsResponse {
  data: DuffelAirportSuggestion[];
  meta: null;
}

// Hold orders and payment types
export interface DuffelPaymentRequirements {
  requires_instant_payment: boolean;
  price_guarantee_expires_at?: string;
  payment_required_by?: string;
}

export interface DuffelPaymentStatus {
  awaiting_payment: boolean;
  price_guarantee_expires_at?: string;
  payment_required_by?: string;
}

export interface DuffelHoldOrderRequest {
  type: 'hold';
  selected_offers: string[];
  passengers: Array<{
    id: string;
    title: string;
    given_name: string;
    family_name: string;
    gender: 'm' | 'f';
    born_on: string;
    email: string;
    phone_number: string;
  }>;
}

export interface DuffelPaymentRequest {
  order_id: string;
  payment: {
    type: 'balance' | 'arc_bsp_cash';
    amount: string;
    currency: string;
  };
}

// Corporate loyalty programme airline codes and requirements
export const CORPORATE_LOYALTY_AIRLINES = {
  'UA': { name: 'United Airlines', programme: 'PerksPlus', parameter: 'tour_code' },
  'AA': { name: 'American Airlines', programme: 'AAdvantage', parameter: 'tracking_reference' },
  'AF': { name: 'Air France', programme: 'Bluebiz', parameter: 'tracking_reference' },
  'KL': { name: 'KLM', programme: 'Bluebiz', parameter: 'tracking_reference' },
  'DL': { name: 'Delta', programme: 'SkyBonus', parameter: 'tracking_reference' },
  'WN': { name: 'Southwest', programme: 'SWABIZ', parameter: 'tracking_reference' },
  'F9': { name: 'Frontier', programme: 'Biz travel for less', parameter: 'tracking_reference' },
  'AS': { name: 'Alaska', programme: 'EasyBiz', parameter: 'tracking_reference' },
  'WS': { name: 'WestJet', programme: 'WestJetBiz', parameter: 'tracking_reference' },
  'B6': { name: 'JetBlue', programme: 'JetBlue Business Travel', parameter: 'tracking_reference' }
} as const;

// Baggage and ancillary services types
export interface DuffelAvailableService {
  id: string;
  type: 'baggage';
  total_amount: string;
  total_currency: string;
  maximum_quantity: number;
  segment_ids: string[];
  passenger_ids: string[];
  metadata: {
    type: 'checked' | 'carry_on';
    maximum_weight_kg?: number;
    maximum_dimensions_cm?: {
      length: number;
      width: number;
      height: number;
    };
  };
}

export interface DuffelOfferWithServices extends DuffelFlightOffer {
  available_services: DuffelAvailableService[];
}

export interface DuffelServiceBookingRequest {
  id: string;
  quantity: number;
}

export interface DuffelOrderWithServices extends DuffelOrder {
  services: Array<{
    id: string;
    type: 'baggage';
    quantity: number;
    total_amount: string;
    total_currency: string;
    segment_ids: string[];
    passenger_ids: string[];
    metadata: {
      type: 'checked' | 'carry_on';
      maximum_weight_kg?: number;
      maximum_dimensions_cm?: {
        length: number;
        width: number;
        height: number;
      };
    };
  }>;
}

// Airlines supporting baggage booking
export const BAGGAGE_SUPPORTED_AIRLINES = [
  'BA', // British Airways (recommended for testing)
  'LH', // Lufthansa
  'AF', // Air France
  'KL', // KLM
  'UA', // United Airlines
  'AA', // American Airlines
  'DL'  // Delta Airlines
] as const;

// Seat selection types and interfaces
export interface DuffelSeatElement {
  designator: string; // e.g., "1A", "2B"
  type: 'seat' | 'exit_row' | 'lavatory' | 'galley' | 'blocked';
  name?: string;
  disclosures: string[];
  available_services: Array<{
    id: string;
    passenger_id: string;
    total_amount: string;
    total_currency: string;
  }>;
}

export interface DuffelSeatSection {
  elements: DuffelSeatElement[];
}

export interface DuffelSeatRow {
  sections: DuffelSeatSection[];
}

export interface DuffelSeatCabin {
  aisles: number;
  cabin_class: 'first' | 'business' | 'premium_economy' | 'economy';
  deck: number;
  rows: DuffelSeatRow[];
}

export interface DuffelSeatMap {
  id: string;
  segment_id: string;
  slice_id: string;
  cabins: DuffelSeatCabin[];
}

export interface DuffelSeatMapResponse {
  data: DuffelSeatMap[];
  meta: null;
}

export interface DuffelSeatSelection {
  seat_service_id: string;
  passenger_id: string;
}

// Airlines supporting seat selection
export const SEAT_SELECTION_SUPPORTED_AIRLINES = [
  'AA', // American Airlines (recommended for testing)
  'UA', // United Airlines
  'DL', // Delta Airlines
  'BA', // British Airways
  'LH', // Lufthansa
  'AF', // Air France
  'KL'  // KLM
] as const;

// Order cancellation types and interfaces
export interface DuffelCancellationQuoteRequest {
  order_id: string;
}

export interface DuffelAirlineCredit {
  passenger_id: string;
  credit_name: string;
  credit_currency: string;
  credit_amount: string;
  credit_code: string | null; // null until cancellation is confirmed
}

export interface DuffelOrderCancellation {
  id: string;
  order_id: string;
  refund_currency: string;
  refund_amount: string;
  refund_to: 'original_form_of_payment' | 'airline_credits' | 'voucher';
  expires_at: string;
  confirmed_at: string | null;
  airline_credits?: DuffelAirlineCredit[];
  created_at: string;
}

export interface DuffelOrderCancellationResponse {
  data: DuffelOrderCancellation;
  meta: null;
}

export interface DuffelCancellationConfirmRequest {
  order_cancellation_id: string;
}

// Order status and actions
export type DuffelOrderAction = 'cancel' | 'change' | 'refund';

export interface DuffelOrderWithActions extends DuffelOrder {
  available_actions: DuffelOrderAction[];
  cancellation?: DuffelOrderCancellation;
}

// Order change types and interfaces
export interface DuffelOrderSlice {
  id: string;
  origin: {
    iata_code: string;
    name: string;
  };
  destination: {
    iata_code: string;
    name: string;
  };
  departure_date: string;
  arrival_date: string;
  changeable: boolean;
  conditions: {
    change_before_departure?: {
      allowed: boolean;
      penalty_amount?: string;
      penalty_currency?: string;
    };
  };
  segments: Array<{
    id: string;
    departing_at: string;
    arriving_at: string;
    flight_number: string;
    marketing_carrier: {
      iata_code: string;
      name: string;
    };
  }>;
}

export interface DuffelOrderChange {
  id: string;
  order_id: string;
  slices: {
    add: Array<{
      cabin_class?: 'first' | 'business' | 'premium_economy' | 'economy';
      passengers: Array<{
        id: string;
        cabin_class?: 'first' | 'business' | 'premium_economy' | 'economy';
      }>;
    }>;
    remove: Array<{
      slice_id: string;
    }>;
  };
  created_at: string;
  confirmed_at: string | null;
  expires_at: string;
  change_total_amount: string;
  change_total_currency: string;
  penalty_total_amount?: string;
  penalty_total_currency?: string;
  new_total_amount: string;
  new_total_currency: string;
}

export interface DuffelOrderChangeRequest {
  order_id: string;
  slices: {
    add: Array<{
      origin: string;
      destination: string;
      departure_date: string;
      cabin_class?: 'first' | 'business' | 'premium_economy' | 'economy';
      passengers: Array<{
        id: string;
        cabin_class?: 'first' | 'business' | 'premium_economy' | 'economy';
      }>;
    }>;
    remove: Array<{
      slice_id: string;
    }>;
  };
}

export interface DuffelOrderChangeResponse {
  data: DuffelOrderChange;
  meta: null;
}

export interface DuffelOrderChangeConfirmRequest {
  order_change_id: string;
}

export interface DuffelOrderWithSlices extends DuffelOrder {
  slices: DuffelOrderSlice[];
}

// Post-booking services types
export interface DuffelPostBookingService {
  id: string;
  type: 'baggage';
  total_amount: string;
  total_currency: string;
  maximum_quantity: number;
  segment_ids: string[];
  passenger_ids: string[];
  metadata: {
    type: 'checked' | 'carry_on';
    maximum_weight_kg?: number;
    maximum_dimensions_cm?: {
      length: number;
      width: number;
      height: number;
    };
  };
}

export interface DuffelPostBookingServicesResponse {
  data: DuffelPostBookingService[];
  meta: null;
}

export interface DuffelBookServiceRequest {
  payment: {
    type: 'balance';
    currency: string;
    amount: string;
  };
  add_services: Array<{
    id: string;
    quantity: number;
  }>;
}

export interface DuffelBookedService {
  id: string;
  type: 'baggage';
  quantity: number;
  total_amount: string;
  total_currency: string;
  segment_ids: string[];
  passenger_ids: string[];
  metadata: {
    type: 'checked' | 'carry_on';
    maximum_weight_kg?: number;
    maximum_dimensions_cm?: {
      length: number;
      width: number;
      height: number;
    };
  };
}

export interface DuffelOrderWithServices extends DuffelOrder {
  services: DuffelBookedService[];
}

// Hotel booking types (Duffel Stays)
export interface DuffelStaysSearchRequest {
  rooms: number;
  location: {
    radius: number;
    geographic_coordinates: {
      longitude: number;
      latitude: number;
    };
  } | {
    accommodation_ids: string[];
  };
  check_in_date: string;
  check_out_date: string;
  guests: Array<{
    type: 'adult' | 'child';
    age?: number;
  }>;
}

export interface DuffelAccommodation {
  id: string;
  name: string;
  description?: string;
  location: {
    latitude: number;
    longitude: number;
    address: string;
    city: string;
    country_code: string;
  };
  amenities: string[];
  star_rating?: number;
  images: Array<{
    url: string;
    caption?: string;
  }>;
  cheapest_rate_total_amount: string;
  cheapest_rate_total_currency: string;
}

export interface DuffelStaysSearchResult {
  search_result_id: string;
  accommodation: DuffelAccommodation;
}

export interface DuffelStaysSearchResponse {
  data: DuffelStaysSearchResult[];
  meta: {
    count: number;
  };
}

export interface DuffelStaysRate {
  id: string;
  total_amount: string;
  total_currency: string;
  rate_plan_name: string;
  cancellation_policy: {
    free_cancellation_before?: string;
    penalties: Array<{
      amount: string;
      currency: string;
      starts_at: string;
      ends_at?: string;
    }>;
  };
  includes_breakfast: boolean;
  refundable: boolean;
  room: {
    name: string;
    bed_configurations: Array<{
      type: string;
      count: number;
    }>;
    maximum_occupancy: number;
    amenities: string[];
  };
}

export interface DuffelStaysRatesResponse {
  data: DuffelStaysRate[];
  meta: null;
}

export interface DuffelStaysQuoteRequest {
  rate_id: string;
}

export interface DuffelStaysQuote {
  id: string;
  rate_id: string;
  total_amount: string;
  total_currency: string;
  expires_at: string;
  accommodation: DuffelAccommodation;
  rate: DuffelStaysRate;
}

export interface DuffelStaysQuoteResponse {
  data: DuffelStaysQuote;
  meta: null;
}

export interface DuffelStaysBookingRequest {
  quote_id: string;
  email: string;
  phone_number: string;
  guests: Array<{
    given_name: string;
    family_name: string;
    born_on: string;
  }>;
  accommodation_special_requests?: string;
}

export interface DuffelStaysBooking {
  id: string;
  reference: string;
  confirmation_code: string;
  accommodation: DuffelAccommodation;
  check_in_date: string;
  check_out_date: string;
  guests: Array<{
    given_name: string;
    family_name: string;
  }>;
  total_amount: string;
  total_currency: string;
  status: 'confirmed' | 'pending' | 'cancelled';
  key_collection_instructions?: string;
  created_at: string;
}

export interface DuffelStaysBookingResponse {
  data: DuffelStaysBooking;
  meta: null;
}