#!/usr/bin/env node

// Direct Duffel API Test Script
// This confirms the live API integration independently

import fetch from 'node-fetch';

const DUFFEL_TOKEN = process.env.DUFFEL_API_TOKEN;
const BASE_URL = 'https://api.duffel.com';

console.log('🔍 Duffel API Verification Test');
console.log('================================');
console.log(`Token: ${DUFFEL_TOKEN ? DUFFEL_TOKEN.substring(0, 20) + '...' : 'MISSING'}`);
console.log(`Mode: ${DUFFEL_TOKEN?.startsWith('duffel_live_') ? 'LIVE' : 'TEST'}`);
console.log(`Date: ${new Date().toISOString()}`);
console.log('');

async function testDuffelAPI() {
  try {
    // Test 1: Create Offer Request
    console.log('📤 Creating offer request...');
    const offerRequestPayload = {
      data: {
        slices: [{
          origin: "LAX",
          destination: "JFK",
          departure_date: "2025-06-28"
        }],
        passengers: [{ type: "adult" }],
        cabin_class: "economy"
      }
    };

    const offerRequestResponse = await fetch(`${BASE_URL}/air/offer_requests`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${DUFFEL_TOKEN}`,
        'Content-Type': 'application/json',
        'Duffel-Version': 'v2'
      },
      body: JSON.stringify(offerRequestPayload)
    });

    const offerRequestData = await offerRequestResponse.json();
    
    if (!offerRequestResponse.ok) {
      console.error('❌ Offer request failed:', offerRequestData);
      return;
    }

    console.log('✅ Offer request created:', offerRequestData.data.id);
    console.log(`   Live mode: ${offerRequestData.data.live_mode}`);
    console.log(`   Expires: ${offerRequestData.data.expires_at}`);

    // Test 2: Get Offers
    console.log('📥 Retrieving offers...');
    const offersResponse = await fetch(`${BASE_URL}/air/offers?offer_request_id=${offerRequestData.data.id}&limit=10`, {
      headers: {
        'Authorization': `Bearer ${DUFFEL_TOKEN}`,
        'Duffel-Version': 'v2'
      }
    });

    const offersData = await offersResponse.json();
    
    if (!offersResponse.ok) {
      console.error('❌ Offers retrieval failed:', offersData);
      return;
    }

    console.log(`✅ Retrieved ${offersData.data.length} offers`);
    
    if (offersData.data.length > 0) {
      const firstOffer = offersData.data[0];
      console.log('');
      console.log('📋 Sample Offer Details:');
      console.log(`   ID: ${firstOffer.id}`);
      console.log(`   Price: ${firstOffer.total_amount} ${firstOffer.total_currency}`);
      console.log(`   Airline: ${firstOffer.slices[0].segments[0].marketing_airline.name}`);
      console.log(`   Flight: ${firstOffer.slices[0].segments[0].marketing_airline_flight_number}`);
      console.log(`   Duration: ${firstOffer.slices[0].duration}`);
      console.log(`   Emissions: ${firstOffer.total_emissions_kg}kg CO2`);
      console.log(`   Expires: ${firstOffer.expires_at}`);
    }

    console.log('');
    console.log('🎉 All tests passed! Live Duffel API is working correctly.');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testDuffelAPI();