/**
 * Test Hotels Like a Real Human Customer
 * Navigate to hotels page and interact exactly like a customer would
 */

async function testHotelLikeHuman() {
  console.log("Testing hotels exactly like a customer would experience...\n");

  const baseUrl = 'http://localhost:5000';
  
  console.log("1. Customer visits hotels page...");
  try {
    const hotelsResponse = await fetch(`${baseUrl}/hotels`);
    console.log(`   Hotels page status: ${hotelsResponse.status}`);
    
    if (hotelsResponse.ok) {
      console.log("   ✓ Hotels page loads successfully");
      
      // Test hotel data endpoint
      console.log("\n2. Checking what hotel data customers see...");
      const apiResponse = await fetch(`${baseUrl}/api/hotels`);
      
      if (apiResponse.ok) {
        const hotels = await apiResponse.json();
        console.log(`   ✓ Found ${hotels.length} hotels displayed to customers`);
        
        console.log("\n3. Analyzing hotel authenticity...");
        hotels.slice(0, 3).forEach((hotel, index) => {
          console.log(`   Hotel ${index + 1}:`);
          console.log(`     Name: ${hotel.name}`);
          console.log(`     Location: ${hotel.location}`);
          console.log(`     Price: $${hotel.pricePerNight}/night`);
          console.log(`     Rating: ${hotel.rating}`);
          console.log(`     Image: ${hotel.imageUrl}`);
          
          // Check if using stock photos
          if (hotel.imageUrl.includes('unsplash.com')) {
            console.log(`     ❌ Using stock photo (not authentic hotel)`);
          } else if (hotel.imageUrl.includes('booking.com') || 
                    hotel.imageUrl.includes('expedia.com') ||
                    hotel.imageUrl.includes('hotels.com')) {
            console.log(`     ✓ Using authentic hotel photo`);
          } else {
            console.log(`     ? Unknown image source`);
          }
          
          console.log('');
        });
        
        console.log("4. Testing hotel search functionality...");
        const searchResponse = await fetch(`${baseUrl}/api/hotels?location=miami`);
        if (searchResponse.ok) {
          const searchResults = await searchResponse.json();
          console.log(`   ✓ Hotel search works: ${searchResults.length} results for Miami`);
        }
        
      } else {
        console.log("   ❌ Cannot fetch hotel data");
      }
      
    } else {
      console.log("   ❌ Hotels page failed to load");
    }
    
  } catch (error) {
    console.log(`   ❌ Error: ${error.message}`);
  }

  console.log("\n=== HOTEL DATA ANALYSIS ===");
  console.log("Current Status: Mock hotel data with stock photos");
  console.log("Image Source: Unsplash stock photography");
  console.log("Hotel Names: Fictional (Grand Plaza Hotel, etc.)");
  console.log("Prices: Placeholder values");
  console.log("Availability: Not real-time");
  
  console.log("\nTo Show Live Hotels:");
  console.log("• Need hotel booking API credentials");
  console.log("• Integration ready for Booking.com or Hotels.com");
  console.log("• Will display authentic hotel photos and live pricing");
  console.log("• Real availability and actual hotel details");
}

testHotelLikeHuman().catch(console.error);