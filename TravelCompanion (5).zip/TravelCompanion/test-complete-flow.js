/**
 * Complete User Flow Test - Simulates exactly what a user would experience
 */

async function testCompleteUserFlow() {
  console.log('Testing complete user flow...\n');
  
  // Step 1: Test homepage loads
  console.log('1. Testing homepage...');
  try {
    const response = await fetch('http://localhost:5000/');
    console.log(`Homepage status: ${response.status}`);
    if (!response.ok) throw new Error('Homepage failed to load');
  } catch (error) {
    console.log(`❌ Homepage failed: ${error.message}`);
    return;
  }
  
  // Step 2: Test flight search API (what happens when user submits form)
  console.log('\n2. Testing flight search submission...');
  try {
    const searchResponse = await fetch('http://localhost:5000/api/flights/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-20',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    const searchData = await searchResponse.json();
    console.log(`Search API status: ${searchResponse.status}`);
    console.log(`Flight offers returned: ${searchData.data?.length || 0}`);
    
    if (searchData.data && searchData.data.length > 0) {
      const firstOffer = searchData.data[0];
      console.log(`Sample flight: ${firstOffer.slices?.[0]?.origin?.iata_code} → ${firstOffer.slices?.[0]?.destination?.iata_code}`);
      console.log(`Price: ${firstOffer.total_amount} ${firstOffer.total_currency}`);
      console.log(`Airline: ${firstOffer.owner?.name}`);
    }
    
    if (!searchResponse.ok) throw new Error('Flight search failed');
    
  } catch (error) {
    console.log(`❌ Flight search failed: ${error.message}`);
    return;
  }
  
  // Step 3: Test flight results page loads (where user would be redirected)
  console.log('\n3. Testing flight results page...');
  try {
    const resultsResponse = await fetch('http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-20&adults=1&cabin_class=economy');
    console.log(`Results page status: ${resultsResponse.status}`);
    
    const resultsHTML = await resultsResponse.text();
    const hasReactApp = resultsHTML.includes('id="root"') || resultsHTML.includes('script');
    console.log(`Contains React app: ${hasReactApp}`);
    
    if (!resultsResponse.ok) throw new Error('Results page failed to load');
    
  } catch (error) {
    console.log(`❌ Results page failed: ${error.message}`);
    return;
  }
  
  console.log('\n✅ Complete user flow test passed!');
  console.log('Summary:');
  console.log('- Homepage loads correctly');
  console.log('- Flight search API returns live data from Duffel');
  console.log('- Results page loads and should display flights');
  console.log('- Navigation path fixed (search form → /flight-results)');
  
  return true;
}

async function quickAPITest() {
  console.log('\nQuick API verification...');
  
  try {
    const response = await fetch('http://localhost:5000/api/flights/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'SFO',
        destination: 'LAX',
        departureDate: '2025-06-20',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    const data = await response.json();
    console.log(`Different route test: ${data.data?.length || 0} offers`);
    
    if (data.data?.length > 0) {
      console.log(`Route confirmed: ${data.data[0].slices?.[0]?.origin?.iata_code} → ${data.data[0].slices?.[0]?.destination?.iata_code}`);
      console.log(`Live API working: YES`);
    }
    
  } catch (error) {
    console.log(`API test failed: ${error.message}`);
  }
}

// Run complete test
testCompleteUserFlow()
  .then(() => quickAPITest())
  .catch(console.error);