/**
 * Comprehensive Diagnostic Test - Using multiple approaches to identify issues
 */

async function runDiagnostics() {
  console.log("Running comprehensive diagnostics...\n");

  // 1. Test server responsiveness
  console.log("1. Server Health Check:");
  try {
    const healthCheck = await fetch('http://localhost:5000/api/health', {
      method: 'GET',
      timeout: 5000
    });
    console.log(`   Server status: ${healthCheck.status}`);
  } catch (error) {
    console.log(`   Server error: ${error.message}`);
  }

  // 2. Test homepage accessibility
  console.log("\n2. Homepage Analysis:");
  try {
    const homeResponse = await fetch('http://localhost:5000/');
    const homeContent = await homeResponse.text();
    
    console.log(`   Status: ${homeResponse.status}`);
    console.log(`   Content size: ${homeContent.length} bytes`);
    console.log(`   Has React root: ${homeContent.includes('id="root"')}`);
    console.log(`   Has navigation: ${homeContent.includes('nav') || homeContent.includes('TravalSearch')}`);
    console.log(`   Has search form: ${homeContent.includes('input') && homeContent.includes('form')}`);
  } catch (error) {
    console.log(`   Homepage error: ${error.message}`);
  }

  // 3. Test flight results page directly
  console.log("\n3. Flight Results Page Analysis:");
  try {
    const resultsUrl = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
    const resultsResponse = await fetch(resultsUrl);
    const resultsContent = await resultsResponse.text();
    
    console.log(`   Status: ${resultsResponse.status}`);
    console.log(`   Content size: ${resultsContent.length} bytes`);
    console.log(`   Page type: ${resultsContent.includes('<!DOCTYPE html>') ? 'HTML' : 'Other'}`);
    console.log(`   Has React: ${resultsContent.includes('react')}`);
    console.log(`   Has flight results: ${resultsContent.includes('Flight Results')}`);
    console.log(`   Contains 404: ${resultsContent.includes('404') || resultsContent.includes('Not Found')}`);
    console.log(`   Contains error: ${resultsContent.includes('error') || resultsContent.includes('Error')}`);
  } catch (error) {
    console.log(`   Results page error: ${error.message}`);
  }

  // 4. Test API endpoints
  console.log("\n4. API Endpoint Tests:");
  
  // Test flight search API
  try {
    const apiResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    console.log(`   Flight search API: ${apiResponse.status}`);
    
    if (apiResponse.ok) {
      const apiData = await apiResponse.json();
      console.log(`   Flights returned: ${apiData.data?.length || 0}`);
      if (apiData.data?.length > 0) {
        console.log(`   Sample price: ${apiData.data[0].total_currency} ${apiData.data[0].total_amount}`);
        console.log(`   Sample airline: ${apiData.data[0].owner?.name || 'Unknown'}`);
      }
    } else {
      const errorText = await apiResponse.text();
      console.log(`   API error: ${errorText.substring(0, 200)}`);
    }
  } catch (error) {
    console.log(`   API request failed: ${error.message}`);
  }

  // 5. Test other endpoints
  const endpoints = ['/api/flights', '/api/hotels', '/api/destinations', '/api/packages'];
  
  for (const endpoint of endpoints) {
    try {
      const response = await fetch(`http://localhost:5000${endpoint}`);
      console.log(`   ${endpoint}: ${response.status} (${response.statusText})`);
    } catch (error) {
      console.log(`   ${endpoint}: Failed - ${error.message}`);
    }
  }

  // 6. Test routing configuration
  console.log("\n5. Routing Test:");
  const routes = ['/', '/flight-results', '/hotels', '/packages', '/nonexistent'];
  
  for (const route of routes) {
    try {
      const response = await fetch(`http://localhost:5000${route}`);
      console.log(`   ${route}: ${response.status}`);
    } catch (error) {
      console.log(`   ${route}: Failed - ${error.message}`);
    }
  }

  // 7. Test with different search parameters
  console.log("\n6. Search Variations Test:");
  const searchTests = [
    { origin: 'MIA', destination: 'LAX', name: 'MIA→LAX' },
    { origin: 'BOS', destination: 'DEN', name: 'BOS→DEN' },
    { origin: 'SFO', destination: 'NYC', name: 'SFO→NYC' }
  ];

  for (const test of searchTests) {
    try {
      const response = await fetch('http://localhost:5000/api/flight-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: test.origin,
          destination: test.destination,
          departureDate: '2025-06-17',
          adults: 1,
          children: 0,
          infants: 0,
          cabin_class: 'economy'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log(`   ${test.name}: ${data.data?.length || 0} flights`);
      } else {
        console.log(`   ${test.name}: ${response.status} error`);
      }
    } catch (error) {
      console.log(`   ${test.name}: Failed - ${error.message}`);
    }
  }

  console.log("\n=== DIAGNOSTIC SUMMARY ===");
  console.log("Check the results above to identify specific issues.");
}

runDiagnostics().catch(console.error);