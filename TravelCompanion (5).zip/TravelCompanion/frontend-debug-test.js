/**
 * Frontend Debug Test - Simulates frontend API call to debug display issues
 */

async function testFrontendAPI() {
  console.log("Testing frontend API integration...");
  
  // Test the exact URL the frontend would use
  const testUrl = 'http://localhost:5000/flight-results?origin=LAX&destination=JFK&departureDate=2025-06-17&adults=1&children=0&infants=0&cabin_class=economy';
  
  console.log("1. Accessing flight results page...");
  
  try {
    const response = await fetch(testUrl);
    const html = await response.text();
    
    // Check if the page loaded
    console.log(`Page status: ${response.status}`);
    console.log(`Page size: ${html.length} characters`);
    
    // Look for specific React states
    const pageAnalysis = {
      hasReactRoot: html.includes('id="root"'),
      hasViteScripts: html.includes('/@vite/client'),
      hasFlightResultsComponent: html.includes('flight-results'),
      hasConsoleLog: html.includes('console.log'),
      hasErrorBoundary: html.includes('Error'),
      hasSearchData: html.includes('searchData'),
      hasReactQuery: html.includes('useQuery'),
      hasAPICall: html.includes('/api/flight-search')
    };
    
    console.log("2. Page analysis:", pageAnalysis);
    
    // Now test the API call that the frontend should make
    console.log("\n3. Testing API call that frontend should make...");
    
    const apiResponse = await fetch('http://localhost:5000/api/flight-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'LAX',
        destination: 'JFK',
        departureDate: '2025-06-17',
        adults: 1,
        children: 0,
        infants: 0,
        cabin_class: 'economy'
      })
    });
    
    if (apiResponse.ok) {
      const apiData = await apiResponse.json();
      console.log(`API call successful: ${apiData.data?.length || 0} flights returned`);
      
      if (apiData.data && apiData.data.length > 0) {
        const firstFlight = apiData.data[0];
        console.log("Sample flight data:", {
          id: firstFlight.id,
          price: `${firstFlight.total_currency} ${firstFlight.total_amount}`,
          airline: firstFlight.owner?.name,
          route: `${firstFlight.slices?.[0]?.origin?.iata_code} → ${firstFlight.slices?.[0]?.destination?.iata_code}`
        });
      }
    } else {
      console.log(`API call failed: ${apiResponse.status}`);
    }
    
    console.log("\n4. Summary:");
    console.log(`- Frontend page loads: ${response.ok ? 'Yes' : 'No'}`);
    console.log(`- API returns data: ${apiResponse.ok ? 'Yes' : 'No'}`);
    console.log(`- React app structure: ${pageAnalysis.hasReactRoot ? 'Present' : 'Missing'}`);
    
    if (response.ok && apiResponse.ok && pageAnalysis.hasReactRoot) {
      console.log("✅ All components working - issue likely in React rendering logic");
    } else {
      console.log("❌ Found infrastructure issues that need fixing");
    }
    
  } catch (error) {
    console.error("Test failed:", error.message);
  }
}

testFrontendAPI().catch(console.error);