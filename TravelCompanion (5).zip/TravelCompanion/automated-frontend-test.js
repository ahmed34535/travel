/**
 * Automated Frontend Testing System
 * Tests the flight search functionality by simulating user interactions
 */

import puppeteer from 'puppeteer';

async function testFlightSearch() {
  let browser;
  
  try {
    console.log('🚀 Starting automated frontend test...');
    
    // Launch browser
    browser = await puppeteer.launch({ 
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    
    // Enable console logging from the page
    page.on('console', msg => {
      const text = msg.text();
      if (text.includes('📦') || text.includes('✈️') || text.includes('🎯') || text.includes('📊') || text.includes('❌')) {
        console.log('🌐 Frontend Log:', text);
      }
    });
    
    // Navigate to the website
    console.log('📍 Navigating to website...');
    await page.goto('http://localhost:5000', { waitUntil: 'networkidle0' });
    
    // Wait for the page to load
    await page.waitForSelector('[data-testid="flight-search-form"], .flight-search, form', { timeout: 10000 });
    
    console.log('✅ Page loaded successfully');
    
    // Fill out the flight search form
    console.log('📝 Filling flight search form...');
    
    // Try multiple selectors for origin input
    const originSelectors = [
      'input[placeholder*="From"]',
      'input[placeholder*="Origin"]', 
      'input[name="origin"]',
      '#origin',
      '[data-testid="origin-input"]'
    ];
    
    let originInput = null;
    for (const selector of originSelectors) {
      try {
        await page.waitForSelector(selector, { timeout: 2000 });
        originInput = await page.$(selector);
        if (originInput) {
          console.log(`Found origin input with selector: ${selector}`);
          break;
        }
      } catch (e) {
        // Continue to next selector
      }
    }
    
    if (originInput) {
      await page.focus(originSelectors.find(s => originInput));
      await page.type(originSelectors.find(s => originInput), 'NRT');
      await page.waitForTimeout(1000); // Wait for autocomplete
    }
    
    // Try multiple selectors for destination input
    const destSelectors = [
      'input[placeholder*="To"]',
      'input[placeholder*="Destination"]',
      'input[name="destination"]', 
      '#destination',
      '[data-testid="destination-input"]'
    ];
    
    let destInput = null;
    for (const selector of destSelectors) {
      try {
        await page.waitForSelector(selector, { timeout: 2000 });
        destInput = await page.$(selector);
        if (destInput) {
          console.log(`Found destination input with selector: ${selector}`);
          break;
        }
      } catch (e) {
        // Continue to next selector
      }
    }
    
    if (destInput) {
      await page.focus(destSelectors.find(s => destInput));
      await page.type(destSelectors.find(s => destInput), 'SYD');
      await page.waitForTimeout(1000);
    }
    
    // Set departure date
    const dateSelectors = [
      'input[type="date"]',
      'input[placeholder*="Departure"]',
      'input[name="departureDate"]',
      '#departureDate'
    ];
    
    for (const selector of dateSelectors) {
      try {
        const dateInput = await page.$(selector);
        if (dateInput) {
          await page.focus(selector);
          await page.evaluate(() => {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 7);
            document.querySelector('input[type="date"]').value = tomorrow.toISOString().split('T')[0];
          });
          console.log('Set departure date');
          break;
        }
      } catch (e) {
        // Continue
      }
    }
    
    // Click search button
    console.log('🔍 Clicking search button...');
    
    const searchSelectors = [
      'button[type="submit"]',
      'button:contains("Search")',
      '.search-button',
      '[data-testid="search-button"]',
      'button[class*="search"]'
    ];
    
    let searchClicked = false;
    for (const selector of searchSelectors) {
      try {
        const searchBtn = await page.$(selector);
        if (searchBtn) {
          await searchBtn.click();
          searchClicked = true;
          console.log(`Clicked search with selector: ${selector}`);
          break;
        }
      } catch (e) {
        // Continue
      }
    }
    
    if (!searchClicked) {
      // Try clicking any button that might be a search button
      const buttons = await page.$$('button');
      for (const button of buttons) {
        const text = await page.evaluate(el => el.textContent, button);
        if (text.toLowerCase().includes('search') || text.toLowerCase().includes('find')) {
          await button.click();
          searchClicked = true;
          console.log(`Clicked search button with text: ${text}`);
          break;
        }
      }
    }
    
    if (searchClicked) {
      console.log('⏳ Waiting for search results...');
      
      // Wait for either results or error
      try {
        await page.waitForFunction(
          () => {
            return document.querySelector('.flight-offer, .flight-result, [data-testid="flight-offer"]') ||
                   document.querySelector('.error, .no-results') ||
                   document.querySelector('h1').textContent.includes('Flight Results');
          },
          { timeout: 15000 }
        );
        
        // Check for results
        const offers = await page.$$('.flight-offer, .flight-result, [data-testid="flight-offer"]');
        const resultsHeader = await page.$('h1');
        const headerText = resultsHeader ? await page.evaluate(el => el.textContent, resultsHeader) : '';
        
        if (offers.length > 0) {
          console.log(`✅ SUCCESS: Found ${offers.length} flight offers displayed`);
          
          // Log first offer details
          const firstOffer = offers[0];
          const offerText = await page.evaluate(el => el.textContent, firstOffer);
          console.log('🎯 First offer preview:', offerText.substring(0, 200) + '...');
          
        } else if (headerText.includes('Flight Results')) {
          console.log('✅ SUCCESS: Reached flight results page');
          
          // Check for "No flights found" message
          const noResultsMsg = await page.$eval('body', el => el.textContent.includes('No flights found'));
          if (noResultsMsg) {
            console.log('ℹ️  No flights found message displayed (this might indicate backend data issue)');
          }
          
        } else {
          console.log('⚠️  Search completed but results unclear');
        }
        
        // Capture page content for debugging
        const pageContent = await page.content();
        if (pageContent.includes('flight') || pageContent.includes('offer')) {
          console.log('✅ Page contains flight-related content');
        }
        
      } catch (waitError) {
        console.log('⚠️  Timeout waiting for results - checking page state...');
        
        const currentUrl = page.url();
        const pageTitle = await page.title();
        console.log(`Current URL: ${currentUrl}`);
        console.log(`Page title: ${pageTitle}`);
        
        // Check if we're on a results page anyway
        if (currentUrl.includes('flight-results') || pageTitle.includes('Results')) {
          console.log('✅ Successfully navigated to results page');
        }
      }
    } else {
      console.log('❌ Could not find or click search button');
      
      // Log all buttons for debugging
      const buttons = await page.$$('button');
      console.log(`Found ${buttons.length} buttons on page`);
      for (let i = 0; i < Math.min(buttons.length, 5); i++) {
        const text = await page.evaluate(el => el.textContent, buttons[i]);
        console.log(`Button ${i + 1}: "${text}"`);
      }
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
    console.log('🏁 Test completed');
  }
}

// Fallback: Direct API test if browser test fails
async function testAPIDirectly() {
  console.log('\n🔄 Running direct API test as fallback...');
  
  try {
    const response = await fetch('http://localhost:5000/api/flights/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin: 'NRT',
        destination: 'SYD', 
        departureDate: '2025-08-20',
        passengers: { adults: 1, children: 0, infants: 0 },
        cabinClass: 'economy'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log(`✅ API returns ${data.data?.length || 0} offers`);
      
      if (data.data && data.data.length > 0) {
        const firstOffer = data.data[0];
        console.log(`First offer: ${firstOffer.slices[0].origin.iata_code} → ${firstOffer.slices[0].destination.iata_code}`);
        console.log(`Price: ${firstOffer.total_amount} ${firstOffer.total_currency}`);
      }
    } else {
      console.log(`❌ API error: ${response.status}`);
    }
  } catch (error) {
    console.error('❌ API test failed:', error.message);
  }
}

// Run the test
async function runTest() {
  await testFlightSearch();
  await testAPIDirectly();
}

runTest();